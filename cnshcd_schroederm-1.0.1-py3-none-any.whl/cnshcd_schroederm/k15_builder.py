from .helpers import *
from .global_ import *
from .combine_paths_and_parts import *
from .checkers import *


            
                








# Function: build_k_fifteen_by_power_of_two
#
# Inputs: a positive integer exp at least 2
#
# Output: This routine produces a cyclic,
#         2^exp symmetric HCD of K_{15x2^exp}.

def build_k_fifteen_by_power_of_two( exp ):
    base_paths = []
    
    base_path = []
    
    x_coords = []

    for i in range( 15 ):
        if( i % 2 == 0 ):
            x_coords.append( i // 2 )
        else:
            x_coords.append( -( i + 1 ) // 2 )

    x_coords.append( 0 )
    y_coords = [0] * 16
    y_coords[8]  = 2**(exp-1)
    y_coords[10] = 2**(exp-1)
    y_coords[12] = 2**(exp-1)
    y_coords[14] = 2**(exp-1)
    y_coords[15] = 2**(exp-1)-1
    
    for i in range( 16 ):
        base_path.append( ( x_coords[i], y_coords[i] ) )
        
    base_paths.append( combined_base_path( base_path, 15, 2**exp ) )
    
    for i in range( 2**(exp-1) ):
        if( i % 2 == 1 ):
            base_paths.append( combined_base_path( [(0,0), (3,i), (12,0), (6,i), (9,0), (10,i)], 15, 2**exp ) )
            base_paths.append( combined_base_path( [(0,0), (5,i), (10,0), (12,i)], 15, 2**exp ) )
        
    used_differences = [0] * ( 15 * 2**exp )
    
    for i in range( len( base_paths ) ):
        for j in range( 1, len( base_paths[i] ) ):
            used_differences[ (base_paths[i][j] - base_paths[i][j-1]) % ( 15 * (2**exp) ) ] += 1
            used_differences[ (base_paths[i][j-1] - base_paths[i][j]) % ( 15 * (2**exp) ) ] += 1

    unused_differences = []
    
    for i in range( 15 * ( 2 ** exp ) ):
        if( gcd( i, 15 * (2**exp) ) == 1 and used_differences[i] == 0 ):
            unused_differences.append( i ) 

    if( verbose == 1 ): print( unused_differences )
    counter = 0
    for d in range( 2 ** (exp-1) ):
        if( d % 2 == 0 and not( d == 0 ) ):
            u = unused_differences[counter] % 15
            base_path = []
            for i in range( 15 ):
                if( i % 2 == 0 ):
                    base_path.append( ( i * u, 0 ) )
                else:
                    base_path.append( ( -( i + 1 ) * u, d ) )
            base_path.append( ( 0, unused_differences[counter] % (2**exp) ) )

            base_paths.append( combined_base_path( base_path, 15, 2**exp ) )
            if( verbose == 1 ): print( "counter: " + str(counter) + " unused_differences: " + str(unused_differences[counter]) + "(u,v): (" + str(u) + "," + str(unused_differences[counter] % (2**exp)) + ")" )
            counter += 1
    
    add_unit_base_paths( base_paths, 15 * 2**exp )
    
    return base_paths


            
                








# Function: build_k_fifteen_by_power_of_three
#
# Inputs: a positive integer t at least 1
#
# Output: This routine produces a cyclic,
#         3^exp symmetric HCD of K_{15x3^t}.

def build_k_fifteen_by_power_of_three( t ):
    exp = t + 1
    
    base_paths = []
    
    for i in range( 3 ** t ):
        base_path = [ ( 0, 0 ) ]
        base_path.append( ( 0, 1 + 3 * i ) )
        base_path.append( ( 1, 2 + 6 * i ) )
        base_path.append( ( 3, 3 + 9 * i ) ) 
        base_paths.append( combined_base_path( base_path, 5, 3**exp ) )
        
    base_path = [ (0,0) ]
    
    base_path.append( ( 4,  0 ) )
    base_path.append( ( 1,  0 ) )
    base_path.append( ( 3, -1 ) )
    base_path.append( ( 2,  0 ) )
    base_path.append( ( 0,  4 ) )

    base_paths.append( combined_base_path( base_path, 5, 3**exp ) )
    
    used_differences = [0] * ( 15 * 3**t )
    
    for i in range( len( base_paths ) ):
        for j in range( 1, len( base_paths[i] ) ):
            used_differences[ (base_paths[i][j] - base_paths[i][j-1]) % ( 15 * (3**t) ) ] += 1
            used_differences[ (base_paths[i][j-1] - base_paths[i][j]) % ( 15 * (3**t) ) ] += 1

    unused_differences = []
    
    for i in range( ( 15 * ( 3 ** t ) + 1 ) // 2 ):
        if( gcd( i, 15 ) == 1 and used_differences[i] == 0 ):
            unused_differences.append( i ) 

    if( verbose == 1 ): print( unused_differences )
    counter = 0

    for d in range( ( 3 ** exp - 1 ) // 2 ):
        if( d % 3 == 0 and not d == 0 ):
            u = unused_differences[counter] % 5
            v = unused_differences[counter] % (3 ** exp)
            base_path = []
            for i in range( 5 ):
                if( i % 2 == 0 ):
                    base_path.append( ( i * u, 0 ) )
                else:
                    base_path.append( ( -( i + 1 ) * u, d ) )
            base_path.append( ( 0, v ) )
            base_paths.append( combined_base_path( base_path, 5, 3**exp ) )
            if( verbose == 1 ): print( "counter: " + str(counter) + " unused_differences: " + str(unused_differences[counter]) + "(v,y): (" + str(v) + "," + str(y) + ")" )
            counter += 1
    
    add_unit_base_paths( base_paths, 5 * 3**exp )
    
    return base_paths


            
                








# Function: build_k_fifteen_by_power_of_five
#
# Inputs: a positive integer t at least 1
#
# Output: This routine produces a cyclic,
#         3^exp symmetric HCD of K_{15x5^t}.

def build_k_fifteen_by_power_of_five( t ):
    exp = t + 1
    
    base_paths = []
    
    for k in range( 5**(exp-1) ):
        base_path = [ (0,0) ]
        base_path.append( ( 0, ( 1+ 5*k) % (5**exp) ) )
        base_path.append( ( 0, (-1- 5*k) % (5**exp) ) )
        base_path.append( ( 1, ( 2+10*k) % (5**exp) ) )
        base_path.append( ( 0, (-2-10*k) % (5**exp) ) )
        base_path.append( ( 1, 5 ) )
        base_paths.append( combined_base_path( base_path, 3, 5**exp ) )
        
    base_path = [ (0,0) ]
    
    x_coords = [ 0, 1, 2, 0 ]
    for d in range( 1, ( 5 ** t + 1 ) // 2 ):
        base_path = [ (0,0) ]
        base_path.append( ( 1, 5*d ) )
        base_path.append( ( 2, 0 ) )
        base_path.append( ( 0, 6 + 5*d ) )
        base_paths.append( combined_base_path( base_path, 3, 5**exp ) )
    
    base_path = [ (0,0) ]
    base_path.append( ( 1, 0 ) )
    base_path.append( ( 2, 1 ) )
    base_path.append( ( 0, 7 ) )

    base_paths.append( combined_base_path( base_path, 3, 5**exp ) )
    
    add_unit_base_paths( base_paths, 3 * 5**exp )
    
    return base_paths


            
                








# Function: build_k_fifteen_by_power_of_other_prime_power
#
# Inputs: a prime power which is not divisible by 2, 3, or 5
#
# Output: This routine produces a cyclic,
#         p-symmetric HCD of K_{15x p}.

def build_k_fifteen_by_power_of_other_prime_power( p ):
    base_paths = []
    
    base_path = []
    
    x_coords = [0,14,1,13,2,12,3,11,7,8,5,10,4,9,6,0]
    y_coords = [0,0,0,0,0,0,0,0,1,2,3,4,5,4,3,2]
    
    for i in range( 16 ):
        base_path.append( ( x_coords[i], y_coords[i] ) )
    
    base_paths.append( combined_base_path( base_path, 15, p ) )
    
    x1_coords = [0,3,12,6,9,10]
    x2_coords = [0,5,10,12]
    
    small_units_of_Zp = []
    small_non_units_of_Zp = []
    
    for i in range( 2, ( p + 1 ) // 2 ):
        if( gcd( p, i ) == 1 ):
            small_units_of_Zp.append( i )
        else:
            small_non_units_of_Zp.append( i )
            
    for u in small_units_of_Zp:
        base_path = []
        for i in range( 6 ):
            if i % 2 == 0:
                base_path.append( ( x1_coords[i], 0 ) )
            else:
                base_path.append( ( x1_coords[i], u ) )
                
        base_paths.append( combined_base_path( base_path, 15, p ) )

        base_path = []
        for i in range( 4 ):
            if i % 2 == 0:
                base_path.append( ( x2_coords[i], 0 ) )
            else:
                base_path.append( ( x2_coords[i], u ) )
                
        base_paths.append( combined_base_path( base_path, 15, p ) )
        
    used_differences = [0] * ( 15 * p )
    
    for i in range( len( base_paths ) ):
        for j in range( 1, len( base_paths[i] ) ):
            used_differences[ (base_paths[i][j] - base_paths[i][j-1]) % ( 15 * p ) ] += 1
            used_differences[ (base_paths[i][j-1] - base_paths[i][j]) % ( 15 * p ) ] += 1

    unused_differences = []
    
    for i in range( 15 * p ):
        if( gcd( i, 15 * p ) == 1 and used_differences[i] == 0 ):
            unused_differences.append( i ) 


    for d in small_non_units_of_Zp:
        unit_to_use = unused_differences.pop()
        u = unit_to_use % 15
        v = unit_to_use % p
        base_path = []
        for i in range( 15 ):
            if( i % 2 == 0 ):
                base_path.append( ( u * i, 0 ) )
            else:
                base_path.append( ( -( i + 1 ) * u, d ) )
        base_path.append( ( 0, v ) )
        base_paths.append( combined_base_path( base_path, 15, p ) )

    add_unit_base_paths( base_paths, 15 * p )
    
    return base_paths
    









# Function: build_k_fifteen_base_paths
#
# Inputs: a positive integer n >= 3.
#
# Output: This routine builds the base paths for 
#         K_{15 x n}
#
# To build a set of base paths for K_{15 x n}, we must
# determine if n is even, a multiple of 3, and/or a multiple of 5
# 
# First we find the smallest prime p which divides n.
# If n = p^t for some t, then we build base paths for K_{15 x p^t},
#   using four separate techniques for when n = 2, 3, 5, or other.
#
# If n has a prime power divisor that is not 3 and 5, expand the base paths
# already built with respect to those divisors, consecutively.
#
# If n has 3 or 5 as a divisor and the base paths do not reflect those 
# prime powers yet, expand the base paths to include them as well.


def build_k_fifteen_base_paths( n ):
    P = prime_factorization( n )
    P.sort()
    current_order = 1
    base_paths = []
    
    two_power = 0
    three_power = 0
    five_power = 0
    other_powers = []
    
    for i in range( len( P ) ):
        if( P[i] % 2 == 0 ):
            two_power = largest_prime_power( n, 2 )
        elif( P[i] % 3 == 0 ):
            three_power = largest_prime_power( n, 3 )
        elif( P[i] % 5 == 0 ):
            five_power = largest_prime_power( n, 5 )
        else:
            other_powers.append( i )

    initial_paths_made = False
    
    if( two_power > 0 ):
        if( verbose == 1 ): print( "n has a power of 2" )
        base_paths = build_k_fifteen_by_power_of_two( two_power )
        initial_paths_made = True
        current_order *= ( 2 ** two_power ) 
        check_base_paths( base_paths, 15, current_order )
    
    for i in other_powers:
        if( initial_paths_made ):
            base_paths = combine_paths_and_partition( base_paths, 15 * current_order, 3, P[i] ) 

        else:
            base_paths = build_k_fifteen_by_power_of_other_prime_power( P[i] )
            initial_paths_made = True

        current_order *= P[i]
        check_base_paths( base_paths, 15, current_order )
    
    if( three_power > 0 ):
        if( initial_paths_made ):
            base_paths = combine_paths_with_prime_divisors( base_paths, 15, current_order, 3, three_power )
        else:
            base_paths = build_k_fifteen_by_power_of_three( three_power )
            initial_paths_made = True
        current_order *= ( 3 ** three_power ) 
        check_base_paths( base_paths, 15, current_order )

    if( five_power > 0 ):
        if( initial_paths_made ):
            base_paths = combine_paths_with_prime_divisors( base_paths, 15, current_order, 5, five_power )
        else:
            base_paths = build_k_fifteen_by_power_of_five( five_power )
            initial_paths_made = True
        current_order *= ( 5 ** five_power ) 
        check_base_paths( base_paths, 15, current_order )
            
    add_unit_base_paths( base_paths, 15 * n )

    return base_paths
        
        

