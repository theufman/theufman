from .helpers import *
from .set_partition import *
from .global_ import *








# Function: combine_path_and_part_divisible
#
# Inputs: base path S in K_{m}
#         integer m
#         part in a partition of Z_n
#         integer n
#
# Output: This routine constructs a set of 
#         base paths which belong to K_{m x n}

def combine_path_and_part_divisible( S, m, P, n ): 
    new_paths = []
    
    d = len( S ) - 1
    
    if( verbose == 1 ): print( "d = " + str(d) )
    
    p = len( P )
    
    if( verbose == 1 ): print( "p = " + str(p) )
    
    Z = [[0 for x in range(p)] for y in range(d)]
    
    for k in range( p ):
        Z[0][k] = P[k]
        for i in range( 1,d ):
            Z[i][k] = Z[i-1][k] + P[( i + k ) % p] % n
            
    if( verbose == 1 ): 
        for i in range( d ):
            print( Z[i] )

    for k in range( p ):
        new_path = [(0,0)]
        for i in range( 1, d + 1 ):
            new_path.append( ( S[i], Z[i-1][k] ) )
        # print( "Test path: " + str(new_path) )    
        new_paths.append( combined_base_path( new_path, m, n ) )
    
    return new_paths







# Function: combine_path_and_part_relatively_prime
#
# Inputs: base path S in K_{m}
#         integer m
#         part in a partition of Z_n
#         integer n
#
# Output: This routine constructs a  
#         base path which belongs to K_{m x n}

def combine_path_and_part_relatively_prime( S, m, P, n ): 
    new_path = [(0,0)]
    
    d = len( S ) - 1
    
    p = len( P )
    
    Z = [0] * p
    
    Z[0] = P[0]
    
    if( verbose == 1 ): print( "d = " + str(d) + " : p = " + str(p) )
    
    for i in range( 1, p ):
        Z[i] = Z[i-1] + P[i]

    q  = [0] * (p*d + 1 )
    r  = [0] * (p*d + 1 )
    qp = [0] * (p*d + 1 )
    rp = [0] * (p*d + 1 )

    for k in range( p*d + 1 ):
        q[k] = (k-1) // d
        r[k] = ( ( k - 1) % d ) + 1 
        qp[k] = (k-1) // p
        rp[k] = ( ( k - 1) % p ) + 1 
        
    for k in range( 1, p*d + 1 ):
        if( verbose == 1 ): print(k)
        if( verbose == 1 ): print( k, q[k], r[k], qp[k], rp[k], S, Z )
        new_path.append( ( ( S[r[k]] + q[k] * S[d] ) % m, ( Z[rp[k-1]%p] + qp[k] * Z[p-1] ) % n ) )
        if( verbose == 1 ): print( k, q[k], r[k], qp[k], rp[k] )
    
    return combined_base_path( new_path, m, n )
    






# Function: combine_path_and_unit
#
# Inputs: base path S in K_{m}
#         integer m
#         a unit of Z_n
#         integer n
#
# Output: This routine constructs a  
#         base path which belongs to K_{m x n}

def combine_path_and_unit( S, m, u, n ): 
    new_path = []
    
    for i in range( len(S) ):
        new_path.append( ( S[i], ( i * u ) % n ) )
    
    return combined_base_path( new_path, m, n )
 






# Function: combine_paths_and_partition
#
# Inputs: base paths S in K_{m}
#         integer m
#         integer n relatively prime to m
#         assume that Z_n is {1,p} unitizable
#
# Output: This routine builds a valid set of base paths 
#         for a decomposition of K_{m x n} from a set of 
#         base paths of K_m and a partition of Z_n.

def combine_paths_and_partition( S, m, p, n ):

    if( n == 1 ):
        return S
    
    # r = smallest_factor( n )
    # a = largest_prime_power( n, r )
    # print(p, r, a)
    # P = set_partition( p, r, a )
    P = set_partition_general( p, n )

    new_paths = []
    
    for i in range( len( S ) ):
        for j in range( len( P ) ):
            if( len( P[j] ) > 1 ):
                if( verbose == 1 ): print( str(len(S[i])) + " : " + str(len( P[j])) )
                if( len( S[i] ) % len( P[j] ) == 1 ):
                    if( verbose == 1 ): print( "Inside: " + str(len(S[i])) + " : " + str(len( P[j])) )
                    temp = combine_path_and_part_divisible( S[i], m, P[j], n )
                    for k in range( len( temp ) ):
                        new_paths.append( temp[k] )
                else:
                    new_paths.append( combine_path_and_part_relatively_prime( S[i], m, P[j], n ) )
            else:
                new_paths.append( combine_path_and_unit( S[i], m, P[j][0], n ) )
            # print()
            # print( "New Paths:" )
            # for x in new_paths:
                # print( x )
                 
    return new_paths







# Function: combine_paths_with_prime_divisors
#
# Inputs: base paths S in K_{m x n}
#         (assumes all appropriate edge lengths used)
#         integer m
#         prime divisor p of m
#         integer exponent t
#         assume that p does not divide n
#
# Output: This routine builds the base paths for 
#         K_{m x np^t}

def combine_paths_with_prime_divisors( S, m, n, p, t ):

    new_paths = []

    a = largest_prime_power( m, p )
    
    oS = ordered_pair_paths( S, p**a, (m*n) // (p**a) )

    for i in range( len( oS ) ):

        # We only need to worry about non-unit edge lengths, so 
        # We just need to focus on base baths with length at least 2
        d = len( oS[i] ) - 1
        if( d > 1 ):
            if( d % (p**a) == 0 ):
                for j in range( p**t ):
                    new_path = []
                    for k in range( len( oS[i] ) ):
                        new_path.append( oS[i][k] )
                        
                    for k in range( 1, d ):
                        tempx = new_path[k][0] + j * k * p**a
                        new_path[k] = ( tempx, new_path[k][1] )
                    new_path[d] = ( p**a, new_path[d][1] )

                    new_paths.append( new_path )

            else:
                for j in range( p**t ):

                    new_path = [(0,0)]
                    
                    for k in range( 1,d+1 ):
                        new_path.append( ( oS[i][k][0] + k * j * p**a % p**(a+t), oS[i][k][1]) )
                        
                    new_paths.append( new_path )

    return combined_base_paths( new_paths, p**(a+t), (m*n) // (p**a) )

