from .global_ import *
from .helpers import *








# Function: build_rho
#
# Inputs: an odd integer m and prime power q
#         m and q are assumed relatively prime
#
# Output: builds the rho vector as outlined in
#         construction by Jordon and Morris

def build_rho( m, q ):

    p = smallest_factor( q ) 
    
    rho = [0]
    for j in range( 1, p ):
        sum = 0
        for i in range( 1, p ):
            sum += (-1)**i * ( ( i * j ) % p )
        rho.append( sum % q )
        
    return rho








# Function: build_U
#
# Inputs: an odd integer m and prime power q
#         m and q are assumed relatively prime
#
# Output: builds the three subsets U_0, U_1, U_2, and U_3
#         which are used as endpoints for the base paths
#         in the construction by Jordon and Morris

def build_U( m, q ):

    p = smallest_factor( q ) 
    
    rho = build_rho( m, q )
        
    W = []
    W.append( combined_tuple( [1,1,1], [2,m,q] ) )
    W.append( combined_tuple( [1,1,-1], [2,m,q] ) )

    i = 0

    U_1_filled = ( q == p )
    U_2_filled = False
    U_3_filled = False
    
    U_length = [0,0,0,0]
    
    U = [[],[],[],[]]
    
    while i < m and not( U_3_filled ):
        if( gcd( i, m ) == 1 ):
            j = 0
            while j <= ( q - 1 ) // 2 and not( U_3_filled ):
                if( ( q == p or not( ( j % ( p * p ) ) in rho ) ) and (i,j) != (1,1) and (i,j) != (m-1,1) and j % p > 0 ):
                    if( not( U_1_filled ) ):
                        U[1].append( combined_tuple( [1,i,j], [2,m,q] ) )
                        U_length[1] += 1
                        if( U_length[1] == ( q // p - 1 ) // 2 ):
                            U_1_filled = True
                            # print( "Filled U_1." )
                    elif( not( U_2_filled ) ):
                        U[2].append( combined_tuple( [1,i,j], [2,m,q] ) )
                        U_length[2] += 1
                        if( U_length[2] == ( m - 1 ) // 2 ):
                            U_2_filled = True
                            # print( "Filled U_2." )
                    elif( not( U_3_filled ) ):
                        U[3].append( combined_tuple( [1,i,j], [2,m,q] ) )
                        U_length[3] += 1
                        if( U_length[3] == q * ( m - phi( m ) - 1 ) // 2 ):
                            U_3_filled = True
                            # print( "Filled U_3." )
                j += 1
        i += 1
    
    return U 








# Function: build_F0
#
# Inputs: an odd integer m and prime power q
#         m and q are assumed relatively prime
#
# Output: builds the set of base paths in F_0 as defined
#         in the construction by Jordon and Morris

def build_F0( m, q ):

    base_paths = [] 
    
    base_path = [ [0,0,0] ]
    
    for i in range( 1, m ):
        if( i <= ( m - 1 ) // 2 ):
            base_path.append( [ ( base_path[i-1][0] + (-1)**(i+1) * ( 0 ) ) % 2, ( base_path[i-1][1] + (-1)**(i+1) * ( -2 * i ) ) % m, ( base_path[i-1][2] + (-1)**(i+1) * ( 0 ) ) % q ] )
        if( i >  ( m - 1 ) // 2 ):
            base_path.append( [ ( base_path[i-1][0] + (-1)**(i+1) * ( 1 ) ) % 2, ( base_path[i-1][1] + (-1)**(i+1) * ( -2 * i ) ) % m, ( base_path[i-1][2] + (-1)**(i+1) * ( 0 ) ) % q ] )
    
    base_path.append( [1,0,1] )
    
    base_paths.append( combined_tuple_path( base_path, [2,m,q] ) )
    
    base_path = [ [0,0,0] ]
    
    for i in range( 1, q ):
        if( i <= ( q - 1 ) // 2 ):
            base_path.append( [ ( base_path[i-1][0] + (-1)**(i+1) * ( 0 ) ) % 2, ( base_path[i-1][1] + (-1)**(i+1) * ( 0 ) ) % m, ( base_path[i-1][2] + (-1)**(i+1) * ( 2 * i ) ) % q ] )
        if( i >  ( q - 1 ) // 2 ):
            base_path.append( [ ( base_path[i-1][0] + (-1)**(i+1) * ( 1 ) ) % 2, ( base_path[i-1][1] + (-1)**(i+1) * ( 0 ) ) % m, ( base_path[i-1][2] + (-1)**(i+1) * ( 2 * i ) ) % q ] )
    
    base_path.append( [1,1,0] )
    
    base_paths.append( combined_tuple_path( base_path, [2,m,q] ) )
    
    return base_paths








# Function: build_F1
#
# Inputs: an odd integer m and prime power q
#         m and q are assumed relatively prime
#
# Output: builds the set of base paths in F_1 as defined
#         in the construction by Jordon and Morris

def build_F1( m, q, U_1 ):

    p = smallest_factor( q )
    
    base_paths = []
    
    for y in range( 1, ( q // p + 1 ) // 2 ):
        # print( "In the first for loop." )
        base_path = [ [0,0,0] ]
        
        for i in range( 1, m ):
            # print( "In the second for loop." )
            base_path.append( [ ( base_path[i-1][0] + (-1)**(i+1) * ( 0 ) ) % 2, ( base_path[i-1][1] + (-1)**(i+1) * ( -2 * i * U_1[y-1] ) ) % m, ( base_path[i-1][2] + (-1)**(i+1) * ( y * p ) ) % q ] )
        
        base_path.append( [ 1, 0, U_1[y-1] % q ] )
        
        base_paths.append( combined_tuple_path( base_path, [2,m,q] ) )
        
    return base_paths








# Function: build_F2
#
# Inputs: an odd integer m and prime power q
#         m and q are assumed relatively prime
#
# Output: builds the set of base paths in F_2 as defined
#         in the construction by Jordon and Morris

def build_F2( m, q, U_2 ):

    p = smallest_factor( q )
    
    base_paths = []
    
    for x in range( 1, ( m + 1 ) // 2 ):
        base_path = [ [0,0,0] ]
        
        for i in range( 1, q ):
            if( i % p == 0 ):
                base_path.append( [ ( base_path[i-1][0] + (-1)**(i+1) * ( 1 ) ) % 2, ( base_path[i-1][1] + (-1)**(i+1) * ( x ) ) % m, ( base_path[i-1][2] + (-1)**(i+1) * ( -2 * i * U_2[x-1] ) ) % q ] )
            else:
                if( m % 4 == 3 and x == 1 and  ( ( -2 * i * U_2[x-1] ) % q ) == 1 ):
                    base_path.append( [ ( base_path[i-1][0] + (-1)**(i+1) * ( 1 ) ) % 2, ( base_path[i-1][1] + (-1)**(i+1) * ( x ) ) % m, ( base_path[i-1][2] + (-1)**(i+1) * ( -2 * i * U_2[x-1] ) ) % q ] )
                elif( m % 4 == 3 and x == 1 and  ( ( -2 * i * U_2[x-1] ) % q ) == q - 1 ):
                    base_path.append( [ ( base_path[i-1][0] + (-1)**(i+1) * ( 1 ) ) % 2, ( base_path[i-1][1] + (-1)**(i+1) * ( x ) ) % m, ( base_path[i-1][2] + (-1)**(i+1) * ( -2 * i * U_2[x-1] ) ) % q ] )
                else:
                    base_path.append( [ ( base_path[i-1][0] + (-1)**(i+1) * ( 0 ) ) % 2, ( base_path[i-1][1] + (-1)**(i+1) * ( x ) ) % m, ( base_path[i-1][2] + (-1)**(i+1) * ( -2 * i * U_2[x-1] ) ) % q ] )
        
        base_path.append( [ 1, U_2[x-1] % m, 0 ] )
        
        base_paths.append( combined_tuple_path( base_path, [2,m,q] ) )
        
    return base_paths








# Function: build_F3
#
# Inputs: an odd integer m and prime power q
#         m and q are assumed relatively prime
#
# Output: builds the set of base paths in F_3 as defined
#         in the construction by Jordon and Morris

def build_F3( m, q, U_3 ):

    p = smallest_factor( q )
    
    rho = build_rho( m, q )
    
    
    rho_reduced = []
    
    for x in rho:
        rho_reduced.append( x % p )
    
    
    base_paths = []
    
    counter = 0
    for x in range( 1, ( m + 1 ) // 2 ):

        if( gcd( x, m ) > 1 ):

            for h in range( q // p ):
            
                j = rho_reduced.index( U_3[counter] % p )

                v = ( ( U_3[counter] - rho[j] ) % q ) // p
                
                base_path = [ [0,0,0] ]
                
                for i in range( 1, p ):
                    base_path.append( [ ( base_path[i-1][0] + (-1)**(i+1) * ( 1 ) ) % 2, ( base_path[i-1][1] + (-1)**(i+1) * ( x ) ) % m, ( base_path[i-1][2] + (-1)**(i+1) * ( h * p + ( ( i * j ) % p ) ) ) % q ] )
                
                base_path.append( [ 1, U_3[counter] % m, p * v ] )
                
                base_paths.append( combined_tuple_path( base_path, [2,m,q] ) )
                
                counter += 1
                
    return base_paths








# Function: build_km2
#
# Inputs: an odd integer n meeting some 
#         necessary numerical conditions
#
# Output: builds the sufficient set of base paths 
#         for a cyclic 2-symmetric HCD of K_{m x 2} using
#         in the construction by Jordon and Morris

def build_km2( n ):

    P = prime_factorization( n )
    
    q = P[0]
    
    m = n // q
    
    U = build_U( m, q )
    
    return build_F0( m, q ) + build_F1( m, q, U[1] ) + build_F2( m, q, U[2] ) + build_F3( m, q, U[3] )
