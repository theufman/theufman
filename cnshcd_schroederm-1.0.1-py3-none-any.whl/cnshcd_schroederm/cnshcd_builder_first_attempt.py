# python cnshcd_builder.py

from helpers import *
from set_partition import *
from checkers import *
from km_builder import *
from global_ import *
from k15_builder import *
from combine_paths_and_parts import *
from k_mxn_small import *
from pn_builder import *
from km2_builder import *

import sys




# Function: cnshcd_builder
#
# Inputs: positive integers m and n
#         level of verbosity (defaulted to true)
#
# Output: a cyclic, n-symmetric HCD of K_{mxn}, if
#         the necessary numerical conditions are met.

def cnshcd_builder( m, n, all_print, vb = True ):
    M = prime_factorization( m )
    N = prime_factorization( n )
    list_of_primes_for_m = []
    list_of_primes_for_n = []
    p = smallest_factor( m )

    set_type = [ 'sufficient', 'complete' ]
    
    if( vb ): print() 
    
    for q in M:
        list_of_primes_for_m.append( smallest_factor( q ) )
    for q in N:
        list_of_primes_for_n.append( smallest_factor( q ) )

    if( m % 4 == 3 and n % 4 == 2 ):
        if( vb ): print( "K_{%dx%d} does not have an n-symmetric HCD as %d = 3 mod 4 and %d = 2 mod 4. [Schroeder 2015]\n" % ( m, n, m, n ) )
        return []
        
    if( m == 15 and n == 1 ):
        if( vb ): print( "K_{15} = K_{15x1} does not have a cyclic HCD. [Buratti and Del Fra, 2004]\n" )
        return []
    
    if( len( M ) == 1 and M[0] != list_of_primes_for_m[0] and n == 1 ):
        if( vb ): print( "K_{%d} = K_{%d x 1} does not have a cyclic HCD since %d is a composite prime power. [Buratti and Del Fra, 2004]\n" % ( m, m, m ) )
        return []
        
    if( len( M ) == 1 and n == 2 ):
        if( vb ): print( "K_{%d}-F = K_{%d x 2} does not have a cyclic HCD since %d is a prime power. [Jordan and Morris, 2008]\n" % ( 2 * m, m, m ) )
        return []
        
    if( n == 1 ):
        if( vb ): print( "All HCDs are 1-symmetric, and K_{%d} = K_{%dx1} has a cyclic HCD since %d is not 15 nor a composite prime power. [Buratti and Del Fra, 2004]\n" % ( m, m, m ) )
        S = base_paths_of_km( m )
        S = add_unit_base_paths( S, m*n ) 
        print_base_paths( S, m, n, all_print )
        print_non_units( m, n )

        return S
        
    if( n == 2 ):
        if( vb ): print( "K_{%d}-F = K_{%dx2} has a cyclic, 2-symmetric HCD as %d is not a prime power. [Jordon and Morris, 2008]\n" % ( 2 * m, m, m ) )
        S = build_km2( m )
        S = add_unit_base_paths( S, m*n ) 
        if( vb ): print( "     The following set of base paths for K_{%dx%d} are given using Z_{%d} x Z_{%d} as the vertex set.\n" % ( m, n, m, n ) )
        print_base_paths( S, m, n, all_print )
        print_non_units( m, n, n )
        if( vb ): print( "     The following set of base paths for K_{%dx%d} are given using Z_{%d} as the vertex set.\n" % ( m, n, m * n ) )
        print_base_paths( S, m * n, 1, all_print )
        print_non_units( m, n )
        return S
        
    # if( vb ): print( "The necessary conditions are met for the existence of such a decomposition." )
    
    common_primes = []
    common_prime_powers = []
    common_prime_exponents = []
    
    A = 1
    B = 1
    
    
    for i in range( len( N ) ):
        if( list_of_primes_for_n[i] in list_of_primes_for_m ):
            common_primes.append( list_of_primes_for_n[i] )
            common_prime_powers.append( N[i] )
            common_prime_exponents.append( largest_prime_power( n, list_of_primes_for_n[i] ) )
        
        elif( list_of_primes_for_n[i] < p ):
            A *= N[i]
        else:
            B *= N[i]

    if( vb ): print()
    if( vb ): print( "Smallest prime of m: " + str(p) )
    if( vb ): print()
    if( vb ): print( "The factorization of n: " )
    if( vb ): print( "   A = " + str(A) )
    if( vb ): print( "   B = " + str(B) )
    
    if( len( common_primes ) == 0 ):
        if( vb ): print( "   There are no common primes." )
    for i in range( len( common_primes ) ):
        if( vb ): print( "   Common prime power: %2d^%d" % ( common_primes[i], common_prime_exponents[i] ) )

    print()
        
    if( m != 15 and not( len( M ) == 1 and M[0] != p ) and ( not( m == p ) or n % 4 != 2 ) ):

        
        if( A == 2 ):
            print( "Use Theorem 2.2 to build a cyclic, 2-symmetric HCD for K_{%dx2}.\n" % m )
        elif( m == 21 and len( prime_factorization( A ) ) == 1 and A % 2 == 0 ):
            print( "Use Lemma 3.9 to build a cyclic, %d-symmetric HCD for K_{%dx%d}.\n" % ( A, m, A ) )
        elif( A == 1 ):
            print( "Use Theorem 2.2 to build a cyclic, 1-symmetric HCD for K_{%d}.\n" % m )
            print( "\n\n     The following base paths give a cyclic HCD of K_{%d} using Theorem 2.2.\n" % ( m ) )
            S = base_paths_of_km( m )
            S = add_unit_base_paths( S, m ) 
            print_base_paths( S, m, 1, all_print )
        else:
            print( "Use Theorem 2.2 to build a cyclic, 1-symmetric HCD for K_{%d}." % m )
            if( A == 3 ):
                print( "Then use Lemma 3.8 to build a cyclic, 3-symmetric HCD of K_{%dx3}.\n" % m )
            else:
                print( "Then use Lemma 3.7 to build a cyclic, %d-symmetric HCD of K_{%dx%d}.\n" % ( A, m, A ) )
            print( "\n\n     The following base paths give a cyclic HCD of K_{%d} using Theorem 2.2.\n" % ( m ) )
            S = base_paths_of_km( m )
            S = add_unit_base_paths( S, m ) 
            print_base_paths( S, m, 1, all_print )
            print_non_units( m, 1 )
        
        S = build_initial_base_paths( m, A )
        S = add_unit_base_paths( S, m*A )

        print( "\n\n     Below is a " + set_type[all_print] + " set of base paths of K_{%dx%d} using vertex set Z_{%d} x Z_{%d}.\n" % ( m, A, m, A ) )
        print_base_paths( S, m, A, all_print )
        print_non_units( m, A, A )

        print( "\n\n     Below is a " + set_type[all_print] + " set of base paths of K_{%dx%d} using vertex set Z_{%d}.\n" % ( m, A, m*A ) )
        print_base_paths( S, m * A, 1, all_print )
        print_non_units( m, A )
        
        # print_base_paths( S, m, A, all_print )

        if( B > 1 ):
            print( "Use Corollary 4.4 to build a {1,%d}-unitized partition of Z_{%d}." % ( p, B ) )
            print( "Using the base paths for a cyclic, %d-symmetric HCD of K_{%dx%d} and a {1,%d}-unitized partition of Z_{%d}, we build the following cyclic, %d-symmetric HCD of K_{%dx%d} using Corollary 4.9.\n" % ( A, m, A, p, B, A*B, m, A*B ) )
            PP = set_partition_general( p, B )
            print( "     The following are the parts of size %d in a {1,%d}-unitized partition of Z_{%d}.\n" % (p, p, B) )
            counter = 0
            for i in  PP:
                if( len( i ) > 1 ):
                    print( "     Part %2d: " % counter, end = '' )
                    counter += 1
                    print( i )
            print( )
            print( "     The following are the units of a {1,%d}-unitized partition of Z_{%d}.\n" % ( p, B) )
            counter = 0
            for i in PP:
                if( len( i ) == 1 ):
                    if( counter == 0 ):
                        print( "     { ", end = '' )
                    else:
                        print( ", ", end = '' )
                    print( "%d" % i[0], end = '' )
                    counter += 1
            print( "}\n" )
                    
        
        S = combine_paths_and_partition( S, m*A, p, B )

        current_modulus = A * B

        if( B > 1 ):
            
            print( "\n\n     Below is a " + set_type[all_print] + " set of base paths of K_{%dx%d} using vertex set Z_{%d} x Z_{%d}.\n" % ( m, A*B, m, A*B ) )
            print_base_paths( S, m, current_modulus, all_print )
            print_non_units( m, current_modulus, current_modulus )

            print( "\n\n     Below is a " + set_type[all_print] + " set of base paths of K_{%dx%d} using vertex set Z_{%d}.\n" % ( m, A*B, m*A*B ) )
            print_base_paths( S, m * current_modulus, 1, all_print )
            print_non_units( m, current_modulus )

        for i in range( len( common_prime_powers ) ):
            print( "Using the base paths for a cyclic, %d-symmetric HCD of K_{%dx%d}, we build the following cyclic, %d-symmetric HCD of K_{%dx%d} using Theorem 4.11.\n" % ( current_modulus, m, current_modulus, current_modulus*common_primes[i]**common_prime_exponents[i], m, current_modulus*common_primes[i]**common_prime_exponents[i] ) )

            S = combine_paths_with_prime_divisors( S, m, current_modulus, common_primes[i], common_prime_exponents[i] )

            q = largest_prime_power( m, common_primes[i] )
            
            # print(m, q, current_modulus, common_prime_powers[i], m * current_modulus // (common_primes[i] ** q), (common_primes[i] ** q) * common_prime_powers[i] )
            print( "\n\n     Below is a " + set_type[all_print] + " set of base paths of K_{%dx%d} using vertex set Z_{%d} x Z_{%d}.\n" % ( m, current_modulus* common_prime_powers[i], m * current_modulus // (common_primes[i] ** q), (common_primes[i] ** q) * common_prime_powers[i] ) )
            print_base_paths( S, m * current_modulus // (common_primes[i] ** q), (common_primes[i] ** q) * common_prime_powers[i], all_print )
            print_non_units( m, current_modulus*common_prime_powers[i], (common_primes[i] ** q) * common_prime_powers[i] )

            current_modulus *= common_prime_powers[i]
        
            print( "\n\n     Below is a " + set_type[all_print] + " set of base paths of K_{%dx%d} using vertex set Z_{%d}.\n" % ( m, current_modulus, m*current_modulus ) )
            print_base_paths( S, m * current_modulus, 1, all_print )
            print_non_units( m, current_modulus )

    elif( m == 15 ):
        if( A > 1 ):
            print( "Use Lemma 3.12 to build a cyclic, %d-symmetric HCD for K_{%dx%d}.\n" % ( A, 15, A ) )
            S = build_k_fifteen_by_power_of_two( largest_prime_power( A, 2 ) )
            S = add_unit_base_paths( S, m*A )
            print( "\n\n     Below is a " + set_type[all_print] + " set of base paths of K_{%dx%d} using vertex set Z_{%d} x Z_{%d}.\n" % ( 15, A, 15, A ) )
            print_base_paths( S, 15, A, all_print )
            print_non_units( 15, A, A )
            print( "\n\n     Below is a " + set_type[all_print] + " set of base paths of K_{%dx%d} using vertex set Z_{%d}.\n" % ( 15, A, 15*A ) )
            print_base_paths( S, 15*A, 1, all_print )
            print_non_units( 15, A )

            if( B > 1 ):
                print( "Use Corollary 4.4 to build a {1,%d}-unitized partition of Z_{%d}." % ( p, B ) )
                print( "Using the base paths for a cyclic, %d-symmetric HCD of K_{%dx%d} and a {1,%d}-unitized partition of Z_{%d}, we build the following cyclic, %d-symmetric HCD of K_{%dx%d} using Corollary 4.9.\n" % ( A, m, A, p, B, A*B, m, A*B ) )
                PP = set_partition_general( p, B )
                print( "     The following are the parts of size %d in a {1,%d}-unitized partition of Z_{%d}.\n" % (p, p, B) )
                counter = 0
                for i in  PP:
                    if( len( i ) > 1 ):
                        print( "     Part %2d: " % counter, end = '' )
                        counter += 1
                        print( i )
                print( )
                print( "     The following are the units of a {1,%d}-unitized partition of Z_{%d}.\n" % ( p, B) )
                counter = 0
                for i in PP:
                    if( len( i ) == 1 ):
                        if( counter == 0 ):
                            print( "     { ", end = '' )
                        else:
                            print( ", ", end = '' )
                        print( "%d" % i[0], end = '' )
                        counter += 1
                print( "}\n" )
                    
        
            S = combine_paths_and_partition( S, m*A, p, B )
            current_modulus = A * B

            if( B > 1 ):
                
                print( "\n\n     Below is a " + set_type[all_print] + " set of base paths of K_{%dx%d} using vertex set Z_{%d} x Z_{%d}.\n" % ( m, A*B, m, A*B ) )
                print_base_paths( S, m, current_modulus, all_print )
                print_non_units( m, current_modulus, current_modulus )

                print( "\n\n     Below is a " + set_type[all_print] + " set of base paths of K_{%dx%d} using vertex set Z_{%d}.\n" % ( m, A*B, m*A*B ) )
                print_base_paths( S, m * current_modulus, 1, all_print )
                print_non_units( m, current_modulus )


            for i in range( len( common_prime_powers ) ):
                print( "Using the base paths for a cyclic, %d-symmetric HCD of K_{%dx%d}, we build the following cyclic, %d-symmetric HCD of K_{%dx%d} using Theorem 4.11.\n" % ( current_modulus, m, current_modulus, current_modulus*common_primes[i]**common_prime_exponents[i], m, current_modulus*common_primes[i]**common_prime_exponents[i] ) )
                S = combine_paths_with_prime_divisors( S, m, current_modulus, common_primes[i], common_prime_exponents[i] )
                q = largest_prime_power( m, common_primes[i] )
                
                # print(m, q, current_modulus, common_prime_powers[i], m * current_modulus // (common_primes[i] ** q), (common_primes[i] ** q) * common_prime_powers[i] )
                print( "\n\n     Below is a " + set_type[all_print] + " set of base paths of K_{%dx%d} using vertex set Z_{%d} x Z_{%d}.\n" % ( m, current_modulus* common_prime_powers[i], m * current_modulus // (common_primes[i] ** q), (common_primes[i] ** q) * common_prime_powers[i] ) )
                print_base_paths( S, m * current_modulus // (common_primes[i] ** q), (common_primes[i] ** q) * common_prime_powers[i], all_print )
                print_non_units( m, current_modulus*common_prime_powers[i], (common_primes[i] ** q) * common_prime_powers[i] )

                current_modulus *= common_prime_powers[i]
            
                print( "\n\n     Below is a " + set_type[all_print] + " set of base paths of K_{%dx%d} using vertex set Z_{%d}.\n" % ( m, current_modulus, m*current_modulus ) )
                print_base_paths( S, m * current_modulus, 1, all_print )
                print_non_units( m, current_modulus )
        elif( B > 1 ):
            r = smallest_factor( B )
            exp = largest_prime_power( B, r )
            C = B // ( r ** exp )
            print( "Use Lemma 3.12 to build a cyclic, %d-symmetric HCD for K_{%dx%d}.\n" % ( r ** exp, 15, r ** exp ) )
            S = build_k_fifteen_by_power_of_other_prime_power( r ** exp )
            S = add_unit_base_paths( S, m * r ** exp )

            print( "\n\n     Below is a " + set_type[all_print] + " set of base paths of K_{%dx%d} using vertex set Z_{%d} x Z_{%d}.\n" % ( 15, r ** exp, 15, r ** exp ) )
            print_base_paths( S, 15, r ** exp, all_print )
            print_non_units( 15, r ** exp, r ** exp )
            print( "\n\n     Below is a " + set_type[all_print] + " set of base paths of K_{%dx%d} using vertex set Z_{%d}.\n" % ( 15, r ** exp, 15*r ** exp ) )
            print_base_paths( S, 15*r ** exp, 1, all_print )
            print_non_units( 15, r ** exp )

            if( C > 1 ):
                print( "Use Corollary 4.4 to build a {1,%d}-unitized partition of Z_{%d}." % ( p, C ) )
                print( "Using the base paths for a cyclic, %d-symmetric HCD of K_{%dx%d} and a {1,%d}-unitized partition of Z_{%d}, we build the following cyclic, %d-symmetric HCD of K_{%dx%d} using Corollary 4.9.\n" % ( r ** exp, m, r ** exp, p, C, B, m, B ) )
                PP = set_partition_general( p, C )
                print( "     The following are the parts of size %d in a {1,%d}-unitized partition of Z_{%d}.\n" % (p, p, C) )
                counter = 0
                for i in  PP:
                    if( len( i ) > 1 ):
                        print( "     Part %2d: " % counter, end = '' )
                        counter += 1
                        print( i )
                print( )
                print( "     The following are the units of a {1,%d}-unitized partition of Z_{%d}.\n" % ( p, C) )
                counter = 0
                for i in PP:
                    if( len( i ) == 1 ):
                        if( counter == 0 ):
                            print( "     { ", end = '' )
                        else:
                            print( ", ", end = '' )
                        print( "%d" % i[0], end = '' )
                        counter += 1
                print( "}\n" )
 

            S = combine_paths_and_partition( S, m*A*r**exp, p, C )
            current_modulus = A * B

            if( C > 1 ):
                
                print( "\n\n     Below is a " + set_type[all_print] + " set of base paths of K_{%dx%d} using vertex set Z_{%d} x Z_{%d}.\n" % ( m, A*B, m, A*B ) )
                print_base_paths( S, m, current_modulus, all_print )
                print_non_units( m, current_modulus, current_modulus )

                print( "\n\n     Below is a " + set_type[all_print] + " set of base paths of K_{%dx%d} using vertex set Z_{%d}.\n" % ( m, A*B, m*A*B ) )
                print_base_paths( S, m * current_modulus, 1, all_print )
                print_non_units( m, current_modulus )


            for i in range( len( common_prime_powers ) ):

                print( "Using the base paths for a cyclic, %d-symmetric HCD of K_{%dx%d}, we build the following cyclic, %d-symmetric HCD of K_{%dx%d} using Theorem 4.11.\n" % ( current_modulus, m, current_modulus, current_modulus*common_primes[i]**common_prime_exponents[i], m, current_modulus*common_primes[i]**common_prime_exponents[i] ) )
                S = combine_paths_with_prime_divisors( S, m, current_modulus, common_primes[i], common_prime_exponents[i] )
                S = add_unit_base_paths( S, m * current_modulus * common_prime_powers[i] )
                q = largest_prime_power( m, common_primes[i] )
                
                # print(m, q, current_modulus, common_prime_powers[i], m * current_modulus // (common_primes[i] ** q), (common_primes[i] ** q) * common_prime_powers[i] )
                print( "\n\n     Below is a " + set_type[all_print] + " set of base paths of K_{%dx%d} using vertex set Z_{%d} x Z_{%d}.\n" % ( m, current_modulus* common_prime_powers[i], m * current_modulus // (common_primes[i] ** q), (common_primes[i] ** q) * common_prime_powers[i] ) )
                print_base_paths( S, m * current_modulus // (common_primes[i] ** q), (common_primes[i] ** q) * common_prime_powers[i], all_print )
                print_non_units( m, current_modulus*common_prime_powers[i], (common_primes[i] ** q) * common_prime_powers[i] )

                current_modulus *= common_prime_powers[i]
            
                print( "\n\n     Below is a " + set_type[all_print] + " set of base paths of K_{%dx%d} using vertex set Z_{%d}.\n" % ( m, current_modulus, m*current_modulus ) )
                print_base_paths( S, m * current_modulus, 1, all_print )
                print_non_units( m, current_modulus )



                # S = combine_paths_with_prime_divisors( S, m, current_modulus, common_primes[i], common_prime_exponents[i] )
                # current_modulus *= common_prime_powers[i]
        elif( common_primes[0] == 3 ):

            r = 3
            exp = common_prime_exponents[0]
            
            print( "Use Lemma 4.12 to build a cyclic, %d-symmetric HCD for K_{%dx%d}.\n" % ( r ** exp, 15, r ** exp ) )
            S = build_k_fifteen_by_power_of_three( common_prime_exponents[0] )
            S = add_unit_base_paths( S, m * r ** exp )

            print( "\n\n     Below is a " + set_type[all_print] + " set of base paths of K_{%dx%d} using vertex set Z_{%d} x Z_{%d}.\n" % ( 15, r ** exp, 15, r ** exp ) )
            print_base_paths( S, 5, 3*r ** exp, all_print )
            print_non_units( 5, 3*r ** exp, r ** exp )
            print( "\n\n     Below is a " + set_type[all_print] + " set of base paths of K_{%dx%d} using vertex set Z_{%d}.\n" % ( 15, r ** exp, 15*r ** exp ) )
            print_base_paths( S, 15*r ** exp, 1, all_print )
            print_non_units( 15, r ** exp )



            if( len( common_primes ) > 1 ):

                print( "Using the base paths for a cyclic, %d-symmetric HCD of K_{%dx%d}, we build the following cyclic, %d-symmetric HCD of K_{%dx%d} using Theorem 4.11.\n" % ( r ** exp, m, r ** exp, n, m, n ) )
                S = combine_paths_with_prime_divisors( S, m, common_prime_powers[0], common_primes[1], common_prime_exponents[1] )
                S = add_unit_base_paths( S, m * n )
                q = largest_prime_power( m, common_primes[i] )
                
                # print(m, q, current_modulus, common_prime_powers[i], m * current_modulus // (common_primes[i] ** q), (common_primes[i] ** q) * common_prime_powers[i] )
                print( "\n\n     Below is a " + set_type[all_print] + " set of base paths of K_{%dx%d} using vertex set Z_{%d} x Z_{%d}.\n" % ( m, n, m * n // ( 5 ** largest_prime_power( m * n, 5 ) ), ( 5 ** largest_prime_power( m * n, 5 ) ) ) )
                print_base_paths( S, m * n // ( 5 ** largest_prime_power( m * n, 5 ) ), 5 ** largest_prime_power( m * n, 5 ), all_print )
                print_non_units( m, n, 5 ** largest_prime_power( m * n, 5 ) )

                print( "\n\n     Below is a " + set_type[all_print] + " set of base paths of K_{%dx%d} using vertex set Z_{%d}.\n" % ( m, n, m*n ) )
                print_base_paths( S, m * n, 1, all_print )
                print_non_units( m, n )


                # S = combine_paths_with_prime_divisors( S, m, common_prime_powers[0], common_primes[1], common_prime_exponents[1] )
        else: 
            print( "Use Lemma 4.13 to build a cyclic, %d-symmetric HCD for K_{%dx%d}.\n" % ( n, 15, n ) )

            S = build_k_fifteen_by_power_of_five( common_prime_exponents[0] )
            S = add_unit_base_paths( S, m * n )

            print( "\n\n     Below is a " + set_type[all_print] + " set of base paths of K_{%dx%d} using vertex set Z_{%d} x Z_{%d}.\n" % ( 15, n, 3, 5*n ) )
            print_base_paths( S, 3, 5*n, all_print )
            print_non_units( 15, n, 5*n )
            print( "\n\n     Below is a " + set_type[all_print] + " set of base paths of K_{%dx%d} using vertex set Z_{%d}.\n" % ( 15, n, 15*n ) )
            print_base_paths( S, 15*n, 1, all_print )
            print_non_units( 15, n )


    
    elif( len( M ) == 1 and n % 4 == 2 ):
        mexp = largest_prime_power( m, p )
        if( A >= 3 ):
            if( m == p ):
                print( "Use Corollary 3.10 to build a cyclic, %d-symmetric HCD for K_{%dx%d}.\n" % ( A, m, A ) )
                S = build_initial_base_paths( m, A )
                S = add_unit_base_paths( S, m * A )

                print( "\n\n     Below is a " + set_type[all_print] + " set of base paths of K_{%dx%d} using vertex set Z_{%d} x Z_{%d}.\n" % ( m, A, m, A ) )
                print_base_paths( S, m, A, all_print )
                print_non_units( m, A, A )
                print( "\n\n     Below is a " + set_type[all_print] + " set of base paths of K_{%dx%d} using vertex set Z_{%d}.\n" % ( m, A, m*A ) )
                print_base_paths( S, m*A, 1, all_print )
                print_non_units( m, A )
                
            else:

                print( "Use Theorem 3.19 to build a cyclic, %d-symmetric HCD for K_{%dx%d}.\n" % ( A, m, A ) )
                S = new_build_pa_by_n( p, mexp, A )
                S = add_unit_base_paths( S, m * A )

                print( "\n\n     Below is a " + set_type[all_print] + " set of base paths of K_{%dx%d} using vertex set Z_{%d} x Z_{%d}.\n" % ( m, A, m, A ) )
                print_base_paths( S, m, A, all_print )
                print_non_units( m, A, A )
                print( "\n\n     Below is a " + set_type[all_print] + " set of base paths of K_{%dx%d} using vertex set Z_{%d}.\n" % ( m, A, m*A ) )
                print_base_paths( S, m*A, 1, all_print )
                print_non_units( m, A )

            # S = add_unit_base_paths( S, m * A )

            if( B > 1 ):
                print( "Use Corollary 4.4 to build a {1,%d}-unitized partition of Z_{%d}." % ( p, B ) )
                print( "Using the base paths for a cyclic, %d-symmetric HCD of K_{%dx%d} and a {1,%d}-unitized partition of Z_{%d}, we build the following cyclic, %d-symmetric HCD of K_{%dx%d} using Corollary 4.9.\n" % ( A, m, A, p, B, A*B, m, A*B ) )
                PP = set_partition_general( p, B )
                print( "     The following are the parts of size %d in a {1,%d}-unitized partition of Z_{%d}.\n" % (p, p, B) )
                counter = 0
                for i in  PP:
                    if( len( i ) > 1 ):
                        print( "     Part %2d: " % counter, end = '' )
                        counter += 1
                        print( i )
                print( )
                print( "     The following are the units of a {1,%d}-unitized partition of Z_{%d}.\n" % ( p, B) )
                counter = 0
                for i in PP:
                    if( len( i ) == 1 ):
                        if( counter == 0 ):
                            print( "     { ", end = '' )
                        else:
                            print( ", ", end = '' )
                        print( "%d" % i[0], end = '' )
                        counter += 1
                print( "}\n" )
                    
        
            S = combine_paths_and_partition( S, m*A, p, B )
            current_modulus = A * B

            if( B > 1 ):
                
                print( "\n\n     Below is a " + set_type[all_print] + " set of base paths of K_{%dx%d} using vertex set Z_{%d} x Z_{%d}.\n" % ( m, A*B, m, A*B ) )
                print_base_paths( S, m, current_modulus, all_print )
                print_non_units( m, current_modulus, current_modulus )

                print( "\n\n     Below is a " + set_type[all_print] + " set of base paths of K_{%dx%d} using vertex set Z_{%d}.\n" % ( m, A*B, m*A*B ) )
                print_base_paths( S, m * current_modulus, 1, all_print )
                print_non_units( m, current_modulus )




            # S = combine_paths_and_partition( S, m*A, p, B )
            if( len( common_primes ) > 0 ):

                print( "Using the base paths for a cyclic, %d-symmetric HCD of K_{%dx%d}, we build the following cyclic, %d-symmetric HCD of K_{%dx%d} using Theorem 4.11.\n" % ( current_modulus, m, current_modulus, n, m, n ) )
                S = combine_paths_with_prime_divisors( S, m, A * B, p, common_prime_exponents[0] )
                S = add_unit_base_paths( S, m * n )

                print( "\n\n     Below is a " + set_type[all_print] + " set of base paths of K_{%dx%d} using vertex set Z_{%d} x Z_{%d}.\n" % ( m, n, current_modulus, m * n // current_modulus ) )
                print_base_paths( S, current_modulus, m * n // current_modulus, all_print )
                print_non_units( m, n, m * n // current_modulus )

                print( "\n\n     Below is a " + set_type[all_print] + " set of base paths of K_{%dx%d} using vertex set Z_{%d}.\n" % ( m, n, m*n ) )
                print_base_paths( S, m * n, 1, all_print )
                print_non_units( m, n )



                # LEFT OFF HERE
                
        elif( A == 2 and B > 1 ):
            r = smallest_factor( B )
            exp = largest_prime_power( B, r )
            C = B // ( r ** exp )
            if( m == p ):

                print( "Use Corollary 3.10 to build a cyclic, %d-symmetric HCD for K_{%dx%d}.\n" % ( A * r ** exp, m, A * r ** exp ) )
                S = build_initial_base_paths( m, A * r ** exp )
                S = add_unit_base_paths( S, m * A * r ** exp )

                print( "\n\n     Below is a " + set_type[all_print] + " set of base paths of K_{%dx%d} using vertex set Z_{%d} x Z_{%d}.\n" % ( m, A, m, A ) )
                print_base_paths( S, m, A, all_print )
                print_non_units( m, A, A )
                print( "\n\n     Below is a " + set_type[all_print] + " set of base paths of K_{%dx%d} using vertex set Z_{%d}.\n" % ( m, A, m*A ) )
                print_base_paths( S, m*A, 1, all_print )
                print_non_units( m, A )



                # S = build_initial_base_paths( m, A * r ** exp )
            else:

                print( "Use Theorem 3.19 to build a cyclic, %d-symmetric HCD for K_{%dx%d}.\n" % ( A, m, A ) )
                S = new_build_pa_by_n( p, mexp, A * r ** exp )
                S = add_unit_base_paths( S, m * A * r ** exp )

                print( "\n\n     Below is a " + set_type[all_print] + " set of base paths of K_{%dx%d} using vertex set Z_{%d} x Z_{%d}.\n" % ( m, A * r ** exp, m, A * r ** exp ) )
                print_base_paths( S, m, A * r ** exp, all_print )
                print_non_units( m, A * r ** exp, A * r ** exp )
                print( "\n\n     Below is a " + set_type[all_print] + " set of base paths of K_{%dx%d} using vertex set Z_{%d}.\n" % ( m, A * r ** exp, m*A * r ** exp ) )
                print_base_paths( S, m*A * r ** exp, 1, all_print )
                print_non_units( m, A * r ** exp )


                # S = new_build_pa_by_n( p, mexp, A * r ** exp )
            # S = add_unit_base_paths( S, m * A * r ** exp )

            if( C > 1 ):
                print( "Use Corollary 4.4 to build a {1,%d}-unitized partition of Z_{%d}." % ( p, C ) )
                print( "Using the base paths for a cyclic, %d-symmetric HCD of K_{%dx%d} and a {1,%d}-unitized partition of Z_{%d}, we build the following cyclic, %d-symmetric HCD of K_{%dx%d} using Corollary 4.9.\n" % ( A * r ** exp, m, A * r ** exp, p, C, A*B, m, A*B ) )
                PP = set_partition_general( p, C )
                print( "     The following are the parts of size %d in a {1,%d}-unitized partition of Z_{%d}.\n" % (p, p, C) )
                counter = 0
                for i in  PP:
                    if( len( i ) > 1 ):
                        print( "     Part %2d: " % counter, end = '' )
                        counter += 1
                        print( i )
                print( )
                print( "     The following are the units of a {1,%d}-unitized partition of Z_{%d}.\n" % ( p, C) )
                counter = 0
                for i in PP:
                    if( len( i ) == 1 ):
                        if( counter == 0 ):
                            print( "     { ", end = '' )
                        else:
                            print( ", ", end = '' )
                        print( "%d" % i[0], end = '' )
                        counter += 1
                print( "}\n" )
                    
        
            S = combine_paths_and_partition( S, m * A * r ** exp, p, C )
            current_modulus = A * B

            if( C > 1 ):
                
                print( "\n\n     Below is a " + set_type[all_print] + " set of base paths of K_{%dx%d} using vertex set Z_{%d} x Z_{%d}.\n" % ( m, A*B, m, A*B ) )
                print_base_paths( S, m, current_modulus, all_print )
                print_non_units( m, current_modulus, current_modulus )

                print( "\n\n     Below is a " + set_type[all_print] + " set of base paths of K_{%dx%d} using vertex set Z_{%d}.\n" % ( m, A*B, m*A*B ) )
                print_base_paths( S, m * current_modulus, 1, all_print )
                print_non_units( m, current_modulus )




            # S = combine_paths_and_partition( S, m * A * r ** exp, p, C )
            if( len( common_primes ) > 0 ):
                print( "Using the base paths for a cyclic, %d-symmetric HCD of K_{%dx%d}, we build the following cyclic, %d-symmetric HCD of K_{%dx%d} using Theorem 4.11.\n" % ( current_modulus, m, current_modulus, n, m, n ) )
                S = combine_paths_with_prime_divisors( S, m, A * B, p, common_prime_exponents[0] )
                S = add_unit_base_paths( S, m * n )

                print( "\n\n     Below is a " + set_type[all_print] + " set of base paths of K_{%dx%d} using vertex set Z_{%d} x Z_{%d}.\n" % ( m, n, current_modulus, m * n // current_modulus ) )
                print_base_paths( S, current_modulus, m * n // current_modulus, all_print )
                print_non_units( m, n, m * n // current_modulus )

                print( "\n\n     Below is a " + set_type[all_print] + " set of base paths of K_{%dx%d} using vertex set Z_{%d}.\n" % ( m, n, m*n ) )
                print_base_paths( S, m * n, 1, all_print )
                print_non_units( m, n )


                    # S = combine_paths_with_prime_divisors( S, m, A * B, p, common_prime_exponents[0] )
        else:
            if( p == 3 ): print( "Use Lemma 4.18 to build a cyclic, %d-symmetric HCD for K_{%dx%d}.\n" % ( n, m, n ) )
            else:         print( "Use Lemma 4.16 to build a cyclic, %d-symmetric HCD for K_{%dx%d}.\n" % ( n, m, n ) )

            S = build_pa_by_2pb( p, mexp, common_prime_exponents[0] )
            S = add_unit_base_paths( S, m * n )
            
            print( "\n\n     Below is a " + set_type[all_print] + " set of base paths of K_{%dx%d} using vertex set Z_{%d} x Z_{%d}.\n" % ( m, n, m*n // 2, 2 ) )
            print_base_paths( S, m*n // 2, 2, all_print )
            print_non_units( m, n, 2 )
            print( "\n\n     Below is a " + set_type[all_print] + " set of base paths of K_{%dx%d} using vertex set Z_{%d}.\n" % ( m, n, m*n ) )
            print_base_paths( S, m*n, 1, all_print )
            print_non_units( m, n )

            
            
    else:
        mexp = largest_prime_power( m, p )
        if( A >= 3 ):

            if( mexp == 1 ): 
            print( "Use Corollary 3.10 to build a cyclic, %d-symmetric HCD for K_{%dx%d}.\n" % ( A, m, A ) )
            S = build_initial_base_paths( m, A * r ** exp )
            S = add_unit_base_paths( S, m * A * r ** exp )

            print( "\n\n     Below is a " + set_type[all_print] + " set of base paths of K_{%dx%d} using vertex set Z_{%d} x Z_{%d}.\n" % ( m, A, m, A ) )
            print_base_paths( S, m, A, all_print )
            print_non_units( m, A, A )
            print( "\n\n     Below is a " + set_type[all_print] + " set of base paths of K_{%dx%d} using vertex set Z_{%d}.\n" % ( m, A, m*A ) )
            print_base_paths( S, m*A, 1, all_print )
            print_non_units( m, A )





            S = new_build_pa_by_n( p, mexp, A )
            S = add_unit_base_paths( S, m * A )
            S = combine_paths_and_partition( S, m*A, p, B )
            if( len( common_primes ) > 0 ):
                S = combine_paths_with_prime_divisors( S, m, A * B, p, common_prime_exponents[0] )
        elif( A == 1 and B > 1 ):
            r = smallest_factor( B )
            exp = largest_prime_power( B, r )
            C = B // ( r ** exp )
            S = new_build_pa_by_n( p, mexp, A * r ** exp )
            S = add_unit_base_paths( S, m * A * r ** exp )
            S = combine_paths_and_partition( S, m * A * r ** exp, p, C )
            if( len( common_primes ) > 0 ):
                    S = combine_paths_with_prime_divisors( S, m, A * B, p, common_prime_exponents[0] )
        else:
            S = improved_build_pa_by_pb( p, mexp, common_prime_exponents[0] )
            
    return S
            
                








# Function: interface
#
# Inputs: none
#
# Output: an interactive program for soliciting
#         cyclic, symmetric HCDs for balanced 
#         complete multipartite graphs.

def interface():

    while True:

        print()
        print( "With this program, you may produce a cyclic, symmetric HCD of K_{m x n} for a particular m and n." )

        print()
        m = input( "Enter the value of m: " )
        n = input( "Enter the value of n: " )

        if( m == '' or n == '' ):
            print()
            return
            
        m = int( m )
        n = int( n )
        
        if( m % 2 == 0 ):
            print()
            print( "This program only builds decompositions when m is odd." )
        else:
            S = cnshcd_builder( m, n )
            check_base_paths( S, m, n )
            print()
            question = input( "Print the base paths -- complete, sufficient, or neither (c/s/n): " )
            print()

            if( question == 'c' ):
                question = input( "Would you like vertices printed as ordered pairs (y/n): ")
                if( question == 'y' ):
                    print()
                    first  = int( input( "First  ordinate modulus: " ) )
                    second = int( input( "Second ordinate modulus: " ) )
                    print( "Complete set of base paths for K_{%d x %d}: " % ( m, n ) )
                    print()
                    for i in range( len( S ) ):
                        print( "    Path %3d: " % i + str(ordered_pair_path(S[i],first, second)) )
                else:
                    print()
                    print( "Complete set of base paths for K_{%d x %d}: " % ( m, n ) )
                    print()
                    for i in range( len( S ) ):
                        print( "    Path %3d: " % i + str(S[i]) )
            elif( question == 's' ):
                question = input( "Would you like vertices printed as ordered pairs (y/n): ")
                if( question == 'y' ):
                    print()
                    first  = int( input( "First  ordinate modulus: " ) )
                    second = int( input( "Second ordinate modulus: " ) )
                    print( "Sufficient set of base paths for K_{%d x %d}: " % ( m, n ) )
                    print()
                    counter = 0
                    for i in range( len( S ) ):
                        if( len( S[i] ) > 2 ):
                            print( "    Path %3d: " % counter + str(ordered_pair_path(S[i],first, second)) )
                            counter += 1
                else:
                    print()
                    print( "Sufficient set of base paths for K_{%d x %d}: " % ( m, n ) )
                    print()
                    counter = 0
                    for i in range( len( S ) ):
                        if( len( S[i] ) > 2 ):
                            print( "    Path %3d (%3d): " % ( counter, i ) + str(S[i]) )
                            counter += 1
                
                displayDiffChart = True
                while( displayDiffChart ):
                    print()
                    question = input( "For which path would you like to see the edge length chart? " )
                    if( question == "" ):
                        displayDiffChart = False
                    else:
                        print()
                        check_diff_grid( [S[min(len(S)-1,int(question))]], m, n )
            
#Function Entrypoint
def entrypoint( m, n, question ):

   # while True:

        print()
        print( "With this program, you may produce a cyclic, symmetric HCD of K_{m x n} for a particular m and n." )

        print()
       # m = input( "Enter the value of m: " )
       # n = input( "Enter the value of n: " )

        if( m == '' or n == '' ):
            print()
            return
            
        m = int( m )
        n = int( n )
        
        if( m % 2 == 0 ):
            print()
            print( "This program only builds decompositions when m is odd." )
        else:
            S = cnshcd_builder( m, n )
            check_base_paths( S, m, n )
            print()
            # question = input( "Print the base paths -- complete, sufficient, or neither (c/s/n): " )
            print()

            if( question == 'c' ):
                question='n'
                # question = input( "Would you like vertices printed as ordered pairs (y/n): ")
                if( question == 'y' ):
                    print()
                    first  = int( input( "First  ordinate modulus: " ) )
                    second = int( input( "Second ordinate modulus: " ) )
                    print( "Complete set of base paths for K_{%d x %d}: " % ( m, n ) )
                    print()
                    for i in range( len( S ) ):
                        print( "    Path %3d: " % i + str(ordered_pair_path(S[i],first, second)) )
                else:
                    print()
                    print( "Complete set of base paths for K_{%d x %d}: " % ( m, n ) )
                    print()
                    for i in range( len( S ) ):
                        print( "    Path %3d: " % i + str(S[i]) )
            elif( question == 's' ):
                question='n'
                # question = input( "Would you like vertices printed as ordered pairs (y/n): ")
                if( question == 'y' ):
                    print()
                    first  = int( input( "First  ordinate modulus: " ) )
                    second = int( input( "Second ordinate modulus: " ) )
                    print( "Sufficient set of base paths for K_{%d x %d}: " % ( m, n ) )
                    print()
                    counter = 0
                    for i in range( len( S ) ):
                        if( len( S[i] ) > 2 ):
                            print( "    Path %3d: " % counter + str(ordered_pair_path(S[i],first, second)) )
                            counter += 1
                else:
                    print()
                    print( "Sufficient set of base paths for K_{%d x %d}: " % ( m, n ) )
                    print()
                    counter = 0
                    for i in range( len( S ) ):
                        if( len( S[i] ) > 2 ):
                            print( "    Path %3d (%3d): " % ( counter, i ) + str(S[i]) )
                            counter += 1

                print("For which path would you like to see the edge length chart?")


def displayChart(m, n, answer, S):
                #displayDiffChart=True
                #while( displayDiffChart ):
                    question=answer
                    print("Displaying edge length for Path["+question+"]:")
                    m=int(m)
                    n=int(n)
                    #question = input( "For which path would you like to see the edge length chart? " )
                 #   if( question == "" ):
                  #      displayDiffChart = False
                   # else:
                    #    print()
                    check_diff_grid( [S[min(len(S)-1,int(question))]], m, n )

# This line executes the interface.
#interface( )           

# m=7
# n=19

# S = cnshcd_builder( m, n )
# check_base_paths( S, m, n )

# for s in S:
    # print( s )

# check_diff_grid( S, m, n )

# m = 49
# n = 49*2

# S = cnshcd_builder( m, n )

# for s in S:
    # print( s )
    
# check_diffs( [S[-1]], m, n )

m = int(sys.argv[1])
n = int(sys.argv[2])
print_all = int( sys.argv[3] )

S = cnshcd_builder( m, n, print_all )


# print_base_paths(S,m,n)

# print("\n")

# print_base_paths(S,m*n,1)