from .helpers import *
from .global_ import *
from .km_builder import *
from .km2_builder import *
from .checkers import *









# Function: alpha
#
# Inputs: integers d, p
#
# Output: This is a helper function used in 
#         the function build_initial_base_paths.
#         It defines a balanced function from 
#         a set of consecutive integers into the 
#         set of units of Z_p. 
#         
#         In practice, this requires the set of 
#         small non-units to be indexed, then 
#         the inputs to this function are the
#         indices of those non-units.

def alpha( d, p ):
    return 1 + ( d % (p-1) )
    









# Function: build_initial_base_paths
#
# Inputs: integers m, n
#         m is a odd integer, not 15 or a composite prime power
#         n is a positive integer such that
#
# Output: This routine builds a valid set of 
#         base paths for the graph K_{m x n} 
#         from the base paths of K_m

def build_initial_base_paths( m, n ):
    
    if( n == 2 ):
        return build_km2( m )
        
    if( m == 21 and len( prime_factorization( n ) ) == 1 and n % 2 == 0 ):
        return build_k_21_times_power_of_2( n )
    
    S = base_paths_of_km( m )
    
    if( n == 1 ):
        return S
    
    if( verbose == 1 ):
        print()
        print( "The base paths for K_" + str(m) + ": " )
        for s in S:
            print( s )
        print()
    
    base_paths = []
    
    base_paths.append( combined_base_path( build_p0( m, n, S ), m, n ) )
    
    small_units_of_Zn = [n-1]
    small_nonunits_of_Zn = []
    
    if( n % 2 == 0 ):
        small_units_of_Zn.append( 1 )

    for i in range( 2, (n + 1 ) // 2 ):
        if( gcd( i, n ) == 1 ):
            small_units_of_Zn.append( i )
            small_units_of_Zn.append( n - i )
        else:
            small_nonunits_of_Zn.append( i )
    
    
    for u in small_units_of_Zn:
        for s in S:
            base_path = []
            for i in range( len( s ) ):
                base_path.append( ( s[i], ( i * u ) % n ) )
            base_paths.append( combined_base_path( base_path, m, n ) )
    
            
    used_differences = [0] * (m*n)
    unused_units = []
    
    for b in base_paths:
        for i in range( 1, len( b ) ):
            used_differences[ ( b[i] - b[i-1] ) % (m*n) ] += 1
            used_differences[ ( b[i-1] - b[i] ) % (m*n) ] += 1
            
    for i in range( ( m*n + 1 ) // 2 ):
        if( gcd( i, m*n ) == 1 and used_differences[i] == 0 ):
            unused_units.append( i )

    for d in small_nonunits_of_Zn:
        base_path = [(0,0)]
        y = unused_units.pop()
        v = y % n
        u = y % m
        for i in range( 1, m ):
            if( i % 2 == 1 ):
                base_path.append( ( ( - u * ( i + 1 ) ) % m, d ) )
            else:
                base_path.append( ( ( u * i ) % m, 0 ) )
        base_path.append( ( 0, v ) )

        base_paths.append( combined_base_path( base_path, m, n ) )

    return base_paths
    









# Function: render_gammas
#
# Inputs: integer m
#         m is a odd integer, not 15 or a composite prime power
#         S is a complete set of base paths for K_m
#
# Output: This routine builds an array consisting of the 
#         outputs for the gamma function in terms of S as
#         defined in the paper.

def render_gammas( S, m ):
    
    gamma_values = [0] * m
    for s in S:
        ell = len( s )
        for i in range( 1, ell ):
            diff = ( s[i] - s[i-1] ) % m
            gamma_values[ diff ] = 1
            gamma_values[ m - diff ] = -1
    for i in range( 1, (m+1) // 2 ):
        if( gamma_values[i] == 0 ):
            gamma_values[i] = 1
            gamma_values[m-i] = -1

    return gamma_values
    









# Function: build_p0
#
# Inputs: integer m
#         m is a odd integer, not 15 or a composite prime power
#         S is a complete set of base paths for K_m
#         an integer n
#
# Output: This routine builds a base path which uses all edges 
#         of K_{m x n} that has nonunit edge lengths which are 
#         congruent to 0 or n/2 modulo n
#
# Note:   We use v = 1 for this construction

def build_p0( m, n, S ):

    used_differences = [0] * m

    for s in S:
        for i in range( 1, len( s ) ):
            used_differences[ ( s[i] - s[i-1] ) % m ] += 1
            used_differences[ ( s[i-1] - s[i] ) % m ] += 1

    u = 0
    i = 1
    while u == 0:
        if( gcd( i, m ) == 1 and used_differences[i] == 0 ):
            u = i
        else:
            i += 1

    P0 = [(0,0)]
    # v = ( m - 2 ) * x % m

    k = m // 4

    x_coord = 0
    y_coord = 0

    if( n % 2 == 0 ):
        if( m % 4 == 1 ):
            for i in range( 1, m ):
                if( i % 2 == 1 ):
                    x_coord = ( -( i + 1 ) * u ) % m
                else: 
                    x_coord = ( i * u ) % m
                    
                if( i < ( m + 1 ) // 2 and i % 2 == 1 ):
                    y_coord = n // 2
                else:
                    y_coord = 0

                # if( i < 2 * k + 1 ):
                    # y_coord = 0
                # elif( i % 2 == 0 ):
                    # y_coord = 0
                # else:
                    # y_coord = n // 2

                P0.append( ( x_coord, y_coord ) )

            P0.append( ( 0, 1 ) )

        if( m % 4 == 3 ): # Then n % 4 = 0
            for i in range( 1, m ):
                if( i % 2 == 1 ):
                    x_coord = ( -( i + 1 ) * u ) % m
                else: 
                    x_coord = ( i * u ) % m
                # if( i % 2 == 1 ):
                    # x_coord = v * ( i + 1 ) // 2 % m
                # else: 
                    # x_coord = v * ( m - i // 2 ) % m
                if( i < ( m + 1 ) // 2 and i % 2 == 0 ):
                    y_coord = 0
                else:
                    y_coord = n // 2
                # if( i < 2 * k + 1 ):
                    # y_coord = 0
                # elif( i % 2 == 0 ):
                    # y_coord = n // 2
                # else:
                    # y_coord = 0
                P0.append( ( x_coord, y_coord ) )
            P0.append( ( 0, 1 + n // 2 ) )

    else:
        g = render_gammas( S, m )
        
        # This subroutine adjusts gamma in case n = 3 and 
        # we cannot otherwise find a "v" as outlined in Lemma 2.10
        
        if( n == 3 ):
            temp = 0
            for i in range( 1, ( m + 1 ) // 2 ):
                temp += (-1)**(i) * g[ 2 * u * i % m ]
                
            if( temp % 3 == 1 ):
            
                i = u + 1
                w = 0
                while w == 0:
                    if( gcd( i, m ) == 1 and used_differences[i] == 0 ):
                        w = i
                    else:
                        i += 1
                g[ w ] *= -1
                g[ m - w ] *= -1

        Gamma = [ 0 ]
        for k in range( 1, m + 1 ):
            if( k < ( m + 1 ) // 2 ):
                Gamma.append( ( Gamma[-1] + (-1)**k * g[ ( 2 * u * k ) % m ] ) % n )
            else:
                Gamma.append( Gamma[-1] )

        for i in range( 1, m ):
            if( i % 2 == 0 ):
                P0.append( ( u * i, Gamma[i] ) )
            else:
                P0.append( ( -( i + 1 ) * u, Gamma[i] ) )


        v = find_u( P0[-1][1], n )


        P0.append( ( 0, ( v + P0[-1][1] ) % n ) )
                
    return P0
    









# Function: find_u
#
# Inputs: a positive integer n
#         an element x in Z_n
#
# Output: This routine finds a unit u of Z_n
#         which is not 1 or -1 and, when added 
#         to x, also produce a unit
#
# Note:   It appears that i can be chosen to be -1.
#         This only happens when n = 3; otherwise
#         another is found, and it's okay in the n=3
#         case (and necessary) for the returned values
#         to be 2.

def find_u( x, n ):
    for i in range( 2, n ):
        if( gcd( i, n ) == 1 and gcd( i + x, n ) == 1 ):
            return i
    









# Function: build_k_21_times_power_of_2
#
# Inputs: n is a power of 2 which is at least 2
#
# Output: This routine builds a cyclic, n-symmetric
#         HCD for K_{21 x n}.

def build_k_21_times_power_of_2( n ):
    
    base_paths = []

    for i in range( n // 2 ):
        if( i % 2 == 1 ):

            base_path = [ (0,0) ]
            base_path.append( (  7, i ) )
            base_path.append( ( 14, 0 ) )
            base_path.append( ( 15, i ) )
            base_paths.append( combined_base_path( base_path, 21, n ) )
            
            base_path = [ (0,0) ]
            base_path.append( (  3, i ) )
            base_path.append( ( 18, 0 ) )
            base_path.append( (  6, i ) )
            base_path.append( ( 15, 0 ) )
            base_path.append( (  9, i ) )
            base_path.append( ( 12, 0 ) )
            base_path.append( ( 14, i ) )
            base_paths.append( combined_base_path( base_path, 21, n ) )
            
    used_differences = [0] * ( 21 * n )

    for i in range( len( base_paths ) ):
        for j in range( 1, len( base_paths[i] ) ):
            used_differences[ (base_paths[i][j] - base_paths[i][j-1]) % ( 21 * n ) ] += 1
            used_differences[ (base_paths[i][j-1] - base_paths[i][j]) % ( 21 * n ) ] += 1

    unused_units = []
    
    for i in range( 21 * n ):
        if( gcd( i, 21 * n ) == 1 and used_differences[i] == 0 ):
            unused_units.append( i )

    for j in range( 1, n // 2 ):
        if( j % 2 == 0 ):
            base_path = []
            u = unused_units.pop()

            for i in range( 21 ):
                if( i % 2 == 0 ):
                    base_path.append( ( i * u, 0 ) )
                else:
                    base_path.append( ( -( i + 1 ) * u, j ) )
            base_path.append( ( 0, u ) )
            
            base_paths.append( combined_base_path( base_path, 21, n ) )

    base_path = []
    for i in range( 21 ):
        if( i % 2  == 1 ):
            if( i <= 10 ):
                base_path.append( ( -( i + 1 ) // 2, n // 2 ) )
            else:
                base_path.append( ( -( i + 1 ) // 2, 0 ) )
        else: 
                base_path.append( ( i // 2, 0 ) )

    base_path.append( ( 0, 1 ) )
    
    base_paths.append( combined_base_path( base_path, 21, n ) )

    return base_paths
