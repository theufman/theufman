from .helpers import *
from .global_ import *
from .combine_paths_and_parts import *
from .checkers import *








# Function: new_build_pa_by_three
#
# Inputs: prime power q and positive odd integer n
#         (this works for n even as well, just not used 
#         q and n are assumed to be relatively prime
#
# Output: a sufficient set of base paths for 
#         X(Z_q x Z_n ;Z_q^* x {0,1,-1}).

def new_build_pa_by_three( q, n ):
    
    if( q % 3 == 0 ):
        return build_3a_by_0pm1( q, n )
    
    p = smallest_factor( q )
    
    base_path_x = [0]
    base_path_y = [0]
    
    for i in range( 1, q - 1 ):
        if( i % 2 == 0 ):
            if(   i > ( q - 1 ) // 2 and i % p == 1 ):
                base_path_x.append( -1 + i // 2 )
            elif( i > ( q - 1 ) // 2 and i % p == p - 1 ):
                base_path_x.append( 1 + i // 2 )
            else:
                base_path_x.append( i // 2 )
        else:
            if(   i > ( q - 1 ) // 2 and i % p == 1 ):
                base_path_x.append( q - ( i - 1 ) // 2 )
            elif( i > ( q - 1 ) // 2 and i % p == p - 1 ):
                base_path_x.append( q - ( i + 3 ) // 2 )
            else:
                base_path_x.append( q - ( i + 1 ) // 2 )

    base_path_x.append( ( q - 1 ) // 2 )
    base_path_x.append( 0 )

    if( q % 4 == 1 ):
        for i in range( 1, q ):
            if( i % 2 == 0 and i > ( q - 1 ) // 2 and i % p == 0 ):
                base_path_y.append( 2 )
            elif( i % 2 == 1 and i > ( q - 1 ) // 2 and i % p == 0 ):
                base_path_y.append( -1 )
            elif( i % 2 == 1 and i > ( q - 1 ) // 2 and i % p > 0 ):
                base_path_y.append( 1 )
            else:
                base_path_y.append( 0 )
        base_path_y.append( 1 )
    else:
        for i in range( 1, q - 1 ):
            if( i % 2 == 1 and i > ( q - 1 ) // 2 and i % p == 0 ):
                base_path_y.append( -2 )
            elif( i % 2 == 0 and i > ( q - 1 ) // 2 and i % p == 0 ):
                base_path_y.append( 1 )
            elif( i % 2 == 0 and i > ( q - 1 ) // 2 and i % p > 0 ):
                base_path_y.append( -1 )
            else:
                base_path_y.append( 0 )
        base_path_y.append( 1 )
        base_path_y.append( 2 )
    
    base_path = []
    for i in range( q + 1 ):
        base_path.append( ( base_path_x[i], base_path_y[i] ) )
        
    return [ combined_base_path( base_path, q, n ) ]








# Function: new_build_3a_by_0pm1
#
# Inputs: prime power q of 3 and positive odd integer n
#         (this works for n even as well, just not used 
#         q and n are assumed to be relatively prime
#
# Output: a sufficient set of base paths for 
#         X(Z_q x Z_n ;Z_q^* x {0,1,-1}).

def build_3a_by_0pm1( q, n ):

    base_paths = []
    
    if( q == 9 ):
        base_path = [ ( 0, 0 ) ]
        base_path.append( ( 8,  0 ) )
        base_path.append( ( 1,  0 ) )
        base_path.append( ( 7,  0 ) )
        base_path.append( ( 2,  0 ) )
        base_path.append( ( 5, -1 ) )
        base_path.append( ( 3,  0 ) )
        base_path.append( ( 6,  1 ) )
        base_path.append( ( 4,  0 ) )
        base_path.append( ( 0, -1 ) )
        base_paths.append( combined_base_path( base_path, 9, n ) )
        return base_paths


    base_path_x = [0]
    base_path_y = [0]
    
    for i in range( 1, q - 1 ):
        if( i % 2 == 0 ):
            if(   i > ( q - 1 ) // 2 and i % 9 == 1 ):
                base_path_x.append( -1 + i // 2 )
            elif( i > ( q - 1 ) // 2 and i % 9 == 8 ):
                base_path_x.append( 1 + i // 2 )
            else:
                base_path_x.append( i // 2 )
        else:
            if(   i > ( q - 1 ) // 2 and i % 9 == 1 ):
                base_path_x.append( q - ( i - 1 ) // 2 )
            elif( i > ( q - 1 ) // 2 and i % 9 == 8 ):
                base_path_x.append( q - ( i + 3 ) // 2 )
            else:
                base_path_x.append( q - ( i + 1 ) // 2 )

    base_path_x.append( ( q - 1 ) // 2 )
    base_path_x.append( 0 )

    if( q % 4 == 1 ):
        for i in range( 1, q ):
            if( i % 2 == 0 and i > ( q - 1 ) // 2 and i % 9 == 0 ):
                base_path_y.append( 2 )
            elif( i % 2 == 1 and i > ( q - 1 ) // 2 and i % 9 == 0 ):
                base_path_y.append( -1 )
            elif( i % 2 == 1 and i > ( q - 1 ) // 2 and i % 9 > 0 ):
                base_path_y.append( 1 )
            else:
                base_path_y.append( 0 )
        base_path_y.append( 1 )
    else:
        for i in range( 1, q - 1 ):
            if( i % 2 == 1 and i > ( q - 1 ) // 2 and i % 9 == 0 ):
                base_path_y.append( -2 )
            elif( i % 2 == 0 and i > ( q - 1 ) // 2 and i % 9 == 0 ):
                base_path_y.append( 1 )
            elif( i % 2 == 0 and i > ( q - 1 ) // 2 and i % 9 > 0 ):
                base_path_y.append( -1 )
            else:
                base_path_y.append( 0 )
        base_path_y.append( 1 )
        base_path_y.append( 2 )
    
    base_path = []
    for i in range( q + 1 ):
        base_path.append( ( base_path_x[i], base_path_y[i] ) )
    
    base_paths.append( combined_base_path( base_path, q, n ) )

    if( q % 4 == 1 ):
        y_coord_1 = [0,-1,0,-1,0,-1,0,-1,0,-1]
        y_coord_2 = [0,1,0,-1,-2,-1,-2,-3,-2,-1]
    else:
        y_coord_1 = [0,-1,-2,-3,-2,-1,0,1,2,3]
        y_coord_2 = [0,1,0,1,0,1,0,1,0,1]
        

    a = ( -1 ) ** ( ( q + 1 ) // 2 )

    for j in range( (q // 9 - 3 ) // 2 ):
        base_path = [ ( 0, 0 ) ]
        base_path.append( (  5 + 1 * 9 * j, y_coord_1[1] ) )
        base_path.append( (  4 + 0 * 9 * j, y_coord_1[2] ) )
        base_path.append( ( 10 + 1 * 9 * j, y_coord_1[3] ) )
        base_path.append( (  8 + 0 * 9 * j, y_coord_1[4] ) )
        base_path.append( ( 15 + 1 * 9 * j, y_coord_1[5] ) )
        base_path.append( ( 12 + 0 * 9 * j, y_coord_1[6] ) )
        base_path.append( (  2 - 1 * 9 * j, y_coord_1[7] ) )
        base_path.append( ( -2 - 2 * 9 * j, y_coord_1[8] ) )
        base_path.append( ( -9 - 3 * 9 * j, y_coord_1[9] ) )

        base_paths.append( combined_base_path( base_path, q, n ) )

    base_path = [ ( 0, 0 ) ]
    base_path.append( ( -2 - 1 * 9 * ( q // 9 - 3 ) // 2, y_coord_2[1] ) )
    base_path.append( (  1 + 0 * 9 * ( q // 9 - 3 ) // 2, y_coord_2[2] ) )
    base_path.append( (  8 + 1 * 9 * ( q // 9 - 3 ) // 2, y_coord_2[3] ) )
    base_path.append( ( 20 + 2 * 9 * ( q // 9 - 3 ) // 2, y_coord_2[4] ) )
    base_path.append( ( 15 + 1 * 9 * ( q // 9 - 3 ) // 2, y_coord_2[5] ) )
    base_path.append( ( 21 + 2 * 9 * ( q // 9 - 3 ) // 2, y_coord_2[6] ) )
    base_path.append( ( 14 + 1 * 9 * ( q // 9 - 3 ) // 2, y_coord_2[7] ) )
    base_path.append( ( 13 + 0 * 9 * ( q // 9 - 3 ) // 2, y_coord_2[8] ) )
    base_path.append( (  9 - 1 * 9 * ( q // 9 - 3 ) // 2, y_coord_2[9] ) )
    
    base_paths.append( combined_base_path( base_path, q, n ) )

    return base_paths








# Function: new_build_pa_by_four
#
# Inputs: prime power q and positive even integer n
#         q and n are assumed to be relatively prime
#
# Output: a sufficient set of base paths for 
#         X(Z_q x Z_n ;Z_q^* x {0,n/2,1,-1}).

def new_build_pa_by_four( q, n ):

    if( q % 3 == 0 ):
        return build_3a_by_0n2pm1( q, n )
        
    p = smallest_factor( q )

    base_paths = []

    base_path_x = [0]
    base_path_y = [0]
    
    counter = 0
    Z = []
    
    for k in range( ( q // p + 1 ) // 2 ):
        if ( k % p > 0 ):
            for s in [ -1, 1 ]:
                Z.append( ( k, s ) )
            
    for r in range( 1, ( q // p + 1 ) // 2 ):
        base_path_x = []
        for i in range( p ):
            if( i % 2 == 0 ):
                base_path_x.append( i // 2 )
            else:
                if( i == p - 2 ):
                    base_path_x.append( r * p - ( i + 1 ) // 2 + p )
                else: 
                    base_path_x.append( r * p - ( i + 1 ) // 2 )
                    
        base_path_x.append( Z[r-1][0] * Z[r-1][1] * p )

        base_path_y = [0, n // 2 ]
        for i in range( 2, p - 2 ):
            if( i % 2 == 0 ):
                base_path_y.append( n // 2 )
            else: 
                base_path_y.append( n // 2 + 1 )
        base_path_y.append( 0 )
        base_path_y.append( 0 )
        base_path_y.append( -Z[r-1][1] )
        
        base_path = []
        for i in range( p + 1 ):
            base_path.append( ( base_path_x[i], base_path_y[i] ) )
            
        base_paths.append( combined_base_path( base_path, q, n ) )
    
    base_path = []
    
    base_path_x = [ 0, -1 ]
    
    for i in range( 2, q - 1 ):
        if( i % 2 == 0 ):
            if( i % p == 1 ):
                base_path_x.append( -1 + i // 2 )
            elif( i % p == p - 1 ):
                base_path_x.append( 1 + i // 2 )
            else:
                base_path_x.append( i // 2 )
        else:
            if( i % p == 1 ):
                base_path_x.append( q - ( i - 1 ) // 2 )
            elif( i % p == p - 1 ):
                base_path_x.append( q - ( i + 3 ) // 2 )
            else:
                base_path_x.append( q - ( i + 1 ) // 2 )

    base_path_x.append( ( q - 1 ) // 2 )
    base_path_x.append( 0 )

    base_path_y = [ 0 ]
    
    if( q % 4 == 1 ):
        for i in range( 1, q ):
            if( i % 2 == 1 and i % p == 0 ):
                base_path_y.append( -1 )
            elif( i % 2 == 1 and i <= ( q - 1 ) // 2 and i % p > 0 ):
                base_path_y.append( n // 2 )
            elif( i % 2 == 0 and i >= ( q + 1 ) // 2 and i % p == 0 ):
                base_path_y.append( 1 )
            elif( i % 2 == 0 and i <= ( q - 1 ) // 2 and i % p == 0 ):
                base_path_y.append( n // 2 + 1 )
            else: 
                base_path_y.append( 0 )
        base_path_y.append( 1 )
    else:
        for i in range( 1, q ):
            if( i % 2 == 1 and i <= ( q - 1 ) // 2 and i % p == 0 ):
                base_path_y.append( -1 )
            elif( i % 2 == 1 and i >= ( q + 1 ) // 2 and i % p == 0 ):
                base_path_y.append( -1 + n // 2 )
            elif( i % 2 == 0 and i % p == 0 ):
                base_path_y.append( 1 + n // 2 )
            elif( i % 2 == 0 and i <= ( q - 1 ) // 2 and i % p > 0 ):
                base_path_y.append( 0 )
            else: 
                base_path_y.append( n // 2 )
        base_path_y.append( n // 2 + 1 )
    
    base_path = []
    for i in range( q + 1 ):
        base_path.append( ( base_path_x[i], base_path_y[i] ) )
        
    base_paths.append( combined_base_path( base_path, q, n ) )
    
    return base_paths














# Function: build_3a_by_0n2pm1
#
# Inputs: prime power q of 3 and positive integer n
#         q and n are assumed to be relatively prime
#
# Output: a sufficient set of base paths for 
#         X(Z_q x Z_n ;Z_q^* x {0,n/2,1,-1}).

def build_3a_by_0n2pm1( q, n ):

    base_paths = []
    
    if( q == 9 ):
        base_path = [ ( 0, 0 ) ]
        base_path.append( ( 7, n // 2 ) )
        base_path.append( ( 1, n // 2 - 1 ) )
        base_path.append( ( 8, n // 2 ) )
        base_path.append( ( 2, 0 ) )
        base_path.append( ( 5, 0 ) )
        base_path.append( ( 3, -1 ) )
        base_path.append( ( 6, 0 ) )
        base_path.append( ( 4, 0 ) )
        base_path.append( ( 0, 1 ) )
        
        base_paths.append( combined_base_path( base_path, q, n ) )
        
        base_paths.append( combined_base_path( [ (0,0), (1,0), (5,0), (6,1) ], q, n ) )
        base_paths.append( combined_base_path( [ (0,0), (1,n//2), (5,0), (6,-1) ], q, n ) )
        
        return base_paths


    for j in range( ( q // 9 - 1 ) // 2 ):
        base_path = [ ( 0, 0 ) ]
        base_path.append( (  7 +     9 * j, 0 ) )
        base_path.append( ( 17 + 2 * 9 * j, 0 ) )
        base_path.append( ( 24 + 3 * 9 * j, 1 ) )
        base_paths.append( combined_base_path( base_path, q, n ) )
    
        base_path = [ ( 0, 0 ) ]
        base_path.append( (  8 +     9 * j, n // 2 ) )
        base_path.append( ( 19 + 2 * 9 * j,  0 ) )
        base_path.append( ( 30 + 3 * 9 * j,  -1 ) )
        base_paths.append( combined_base_path( base_path, q, n ) )
    
    for j in range( ( q // 9 - 3 ) // 2 ):
        base_path = [ (0,0) ]
        base_path.append( (  -3 - 1 * 9 * j, 1 ) ) 
        base_path.append( (   4 + 0 * 9 * j, 0 ) ) 
        base_path.append( (  -1 - 1 * 9 * j, 1 ) ) 
        base_path.append( (   2 + 0 * 9 * j, 2 ) ) 
        base_path.append( (  -2 - 1 * 9 * j, 1 ) ) 
        base_path.append( (  -8 - 2 * 9 * j, 2 ) ) 
        base_path.append( ( -13 - 3 * 9 * j, 1 ) ) 
        base_path.append( ( -15 - 4 * 9 * j, 0 ) ) 
        base_path.append( (  -9 - 3 * 9 * j, 1 ) ) 
        base_paths.append( combined_base_path( base_path, q, n ) )

    base_path = [ ( 0, 0 ) ]
    base_path.append( (  -3 - 1 * 9 * ( q // 9 - 3 ) // 2,  1 ) ) 
    base_path.append( (   3 + 0 * 9 * ( q // 9 - 3 ) // 2,  0 ) ) 
    base_path.append( (   1 - 1 * 9 * ( q // 9 - 3 ) // 2, -1 ) ) 
    base_path.append( (  13 + 0 * 9 * ( q // 9 - 3 ) // 2,  0 ) ) 
    base_path.append( (  -2 - 1 * 9 * ( q // 9 - 3 ) // 2, -1 ) ) 
    base_path.append( (  14 + 0 * 9 * ( q // 9 - 3 ) // 2, -2 ) ) 
    base_path.append( (  -7 - 1 * 9 * ( q // 9 - 3 ) // 2, -1 ) ) 
    base_path.append( (  17 + 0 * 9 * ( q // 9 - 3 ) // 2, -2 ) ) 
    base_path.append( (   9 - 1 * 9 * ( q // 9 - 3 ) // 2, -3 ) ) 

    base_paths.append( combined_base_path( base_path, q, n ) )

    base_path_x = [0,-1]
    base_path_y = [0]
    
    for i in range( 2, q - 1 ):
        if( i % 2 == 0 ):
            if  ( i % 9 == 1 ):
                base_path_x.append( -1 + i // 2 )
            elif( i % 9 == 8 ):
                base_path_x.append( 1 + i // 2 )
            else:
                base_path_x.append( i // 2 )
        else:
            if  ( i % 9 == 1 ):
                base_path_x.append( q - ( i - 1 ) // 2 )
            elif( i % 9 == 8 ):
                base_path_x.append( q - ( i + 3 ) // 2 )
            else:
                base_path_x.append( q - ( i + 1 ) // 2 )

    base_path_x.append( ( q - 1 ) // 2 )
    base_path_x.append( 0 )

    if( q % 4 == 1 ):
        for i in range( 1, q ):
            if( i % 2 == 1 and i % 9 == 0 ):
                base_path_y.append( -1 )
            elif( i % 2 == 1 and i <= ( q - 1 ) // 2 and i % 9 > 0 ):
                base_path_y.append( n // 2 )
            elif( i % 2 == 0 and i >= ( q + 1 ) // 2 and i % 9 == 0 ):
                base_path_y.append( 1 )
            elif( i % 2 == 0 and i <= ( q - 1 ) // 2 and i % 9 == 0 ):
                base_path_y.append( n // 2 + 1 )
            else: 
                base_path_y.append( 0 )
        base_path_y.append( 1 )
    else:
        for i in range( 1, q ):
            if( i % 2 == 1 and i <= ( q - 1 ) // 2 and i % 9 == 0 ):
                base_path_y.append( -1 )
            elif( i % 2 == 1 and i >= ( q + 1 ) // 2 and i % 9 == 0 ):
                base_path_y.append( -1 + n // 2 )
            elif( i % 2 == 0 and i % 9 == 0 ):
                base_path_y.append( 1 + n // 2 )
            elif( i % 2 == 0 and i <= ( q - 1 ) // 2 and i % 9 > 0 ):
                base_path_y.append( 0 )
            else: 
                base_path_y.append( n // 2 )
        base_path_y.append( n // 2 + 1 )


    base_path = []
    for i in range( q + 1 ):
        base_path.append( ( base_path_x[i], base_path_y[i] ) )
    
    base_paths.append( combined_base_path( base_path, q, n ) )

    return base_paths
        
    
















# Function: base_path_with_four_units
#
# Inputs: prime p, exponent a, integer n
#         assuming p does not divide n
#         units u and v from Z_n
#
# Output: a sufficient set of base paths for 
#         X( Z_{p^a} x Z_n; Z_{p^a}^* x {u,v,-u,-v} )

def base_path_with_four_units( p, a, n, u, v ):

    if( p == 3 ):
        return build_3a_by_pmuv( p ** a, n, u, v )

    q = p ** a

    base_paths = []

    base_path = []
    
    base_path_x = [ 0, -1 ]
    
    for i in range( 2, q - 1 ):
        if( i % 2 == 0 ):
            if( i % p == 1 ):
                base_path_x.append( -1 + i // 2 )
            elif( i % p == p - 1 ):
                base_path_x.append( 1 + i // 2 )
            else:
                base_path_x.append( i // 2 )
        else:
            if( i % p == 1 ):
                base_path_x.append( q - ( i - 1 ) // 2 )
            elif( i % p == p - 1 ):
                base_path_x.append( q - ( i + 3 ) // 2 )
            else:
                base_path_x.append( q - ( i + 1 ) // 2 )

    base_path_x.append( ( q - 1 ) // 2 )
    base_path_x.append( 0 )

    base_path_y = [ 0 ]
    
    for i in range( 1, q + 1 ):
        if( i % 2 == 1 and i % p == 0 ):
            base_path_y.append( -v )
        elif( i % 2 == 1 and i % p > 0 ):
            base_path_y.append( u )
        elif( i % 2 == 0 and i % p == 0 ):
            base_path_y.append( u + v )
        else: 
            base_path_y.append( 0 )
    base_path_y.append( v )
    
    base_path = []
    for i in range( q + 1 ):
        base_path.append( ( base_path_x[i], base_path_y[i] ) )
        
    base_paths.append( combined_base_path( base_path, q, n ) )
    
    return base_paths











# Function: build_3a_by_pmuv
#
# Inputs: prime power q of 3 and positive integer n
#         q and n are assumed to be relatively prime
#         units u and v in Z_n
#
# Output: a sufficient set of base paths for 
#         X(Z_q x Z_n ;Z_q^* x {u,v,-u,-v}).

def build_3a_by_pmuv( q, n, u, v ):

    base_paths = []
    
    if( q == 9 ):
        base_path = [ ( 0, 0 ) ]
        base_path.append( ( 7, u ) )
        base_path.append( ( 1, u - v ) )
        base_path.append( ( 8, u ) )
        base_path.append( ( 2, 0 ) )
        base_path.append( ( 5, u ) )
        base_path.append( ( 3, u - v ) )
        base_path.append( ( 6, u ) )
        base_path.append( ( 4, 0 ) )
        base_path.append( ( 0, u ) )
        
        base_paths.append( combined_base_path( base_path, q, n ) )
        
        return base_paths

    base_path_x = [0,-1]
    base_path_y = [0]
    
    for i in range( 2, q - 1 ):
        if( i % 2 == 0 ):
            if  ( i % 9 == 1 ):
                base_path_x.append( -1 + i // 2 )
            elif( i % 9 == 8 ):
                base_path_x.append( 1 + i // 2 )
            else:
                base_path_x.append( i // 2 )
        else:
            if  ( i % 9 == 1 ):
                base_path_x.append( q - ( i - 1 ) // 2 )
            elif( i % 9 == 8 ):
                base_path_x.append( q - ( i + 3 ) // 2 )
            else:
                base_path_x.append( q - ( i + 1 ) // 2 )

    base_path_x.append( ( q - 1 ) // 2 )
    base_path_x.append( 0 )

    for i in range( 1, q + 1 ):
        if  ( i % 2 == 0 and i % 9 > 0 ):
            base_path_y.append( 0 )
        elif  ( i % 2 == 0 and i % 9 == 0 ):
            base_path_y.append( u + v )
        elif( i % 2 == 1 and i % 9 > 0 ):
            base_path_y.append( u )
        else:
            base_path_y.append( -v )
    
    base_path = []
    for i in range( q + 1 ):
        base_path.append( ( base_path_x[i], base_path_y[i] ) )
    
    base_paths.append( combined_base_path( base_path, q, n ) )

    good_endpoints = []
    
    for i in range( q // 9 ):
        for s in [ -v, v ]:
            # if( i % 3 > 0 and ( i, s ) != ( ( q + 9 ) // 2, v ) ):
            if( i % 3 > 0 ):
                good_endpoints.append( ( i * 9, s ) )

    for j in range( (q // 9 - 3 ) // 2 ):
        base_path = [ ( 0, 0 ) ]
        base_path.append( ( -2 - 1 * 9 * j, -v ) )
        base_path.append( (  1 + 0 * 9 * j,  0 ) )
        base_path.append( ( -1 - 1 * 9 * j,  v ) )
        base_path.append( (  2 + 0 * 9 * j,  0 ) )
        base_path.append( ( -4 - 1 * 9 * j, -v ) )
        base_path.append( (  3 + 0 * 9 * j,  0 ) )
        base_path.append( ( -3 - 1 * 9 * j,  v ) )
        base_path.append( (  4 + 0 * 9 * j,  0 ) )
        base_path.append( good_endpoints.pop() )

        base_paths.append( combined_base_path( base_path, q, n ) )

    base_path = [ ( 0, 0 ) ]
    base_path.append( (  -3 - 1 * 9 * ( q // 9 - 3 ) // 2, -v ) )
    base_path.append( (   3 + 0 * 9 * ( q // 9 - 3 ) // 2, 0 ) )
    base_path.append( (  -8 - 1 * 9 * ( q // 9 - 3 ) // 2, -v ) )
    base_path.append( (   4 + 0 * 9 * ( q // 9 - 3 ) // 2, 0 ) )
    base_path.append( ( -11 - 1 * 9 * ( q // 9 - 3 ) // 2, -v ) )
    base_path.append( (   5 + 0 * 9 * ( q // 9 - 3 ) // 2, 0 ) )
    base_path.append( ( -16 - 1 * 9 * ( q // 9 - 3 ) // 2, -v ) )
    base_path.append( (   8 + 0 * 9 * ( q // 9 - 3 ) // 2, 0 ) )
    base_path.append( ( -18 - 1 * 9 * ( q // 9 - 3 ) // 2, -v ) )
    
    base_paths.append( combined_base_path( base_path, q, n ) )

    return base_paths











# Function: base_path_with_all_but_one_nonunit
#
# Inputs: odd integer m, integer n
#         assuming m and n are relatively prime
#         element d of Z_n, unit u of Z_{mn}
#
# Output: a base path with edge lengths 
#         ( Z_m^* x {-d,d} ) U { u }

def base_path_with_all_but_one_nonunit( m, n, d, u ):
    
    base_path = []
    
    for i in range( m ):
        if( i % 2 == 0 ):
            base_path.append( ( u * i, 0 ) )
        else:
            base_path.append( ( -( i + 1 ) * u, d ) )
    base_path.append( ( 0, u ) )
    
    return combined_base_path( base_path, m, n )











# Function: base_paths_for_K_9x_8_or_10
#
# Inputs: integer n, either n=8 or n=10
#
# Output: remaining base paths needed
#         for a sufficient set, complemented
#         by the output from build_3a_by_0n2pm1

def base_paths_for_K_9x_8_or_10( n ):

    base_paths = []

    base_path = [ ( 0, 0 ) ]
    base_path.append( ( 7, 2 ) )
    base_path.append( ( 1, 0 ) )
    base_path.append( ( 8, 3 ) )
    base_path.append( ( 2, 0 ) )
    base_path.append( ( 5, 2 ) )
    base_path.append( ( 3, 0 ) )
    base_path.append( ( 6, 3 ) )
    base_path.append( ( 4, 0 ) )
    base_path.append( ( 0, 3 ) )
    
    base_paths.append( combined_base_path( base_path, 9, n ) )
    
    base_paths.append( combined_base_path( [ (0,0), (1,2), (5,4), ( 6,7) ], 9, n ) )
    base_paths.append( combined_base_path( [ (0,0), (1,-2), (5,-4), ( 6,-7) ], 9, n ) )
    
    if( n == 10 ):
        base_paths.append( base_path_with_all_but_one_nonunit( 9, 10, 4, 13 ) )
    
    return base_paths











# Function: new_build_pa_by_n
#
# Inputs: prime p, exponent a, integer n
#         assuming that p does not divide n
#         assuming that n is bounded appropriately
#         in terms of phi(n)
#
# Output: a sufficient set of base paths for 
#         X( Z_{p^a n}; p^a Z_{p^a n} )

def new_build_pa_by_n( p, a, n ):

    base_paths = []

    m = p ** a
    
    # First, we use edge lengths from 
    # Z_m^* x { 0, n/2, +/-1 } to build base baths
    # which use all nonunit edge lengths from this set

    if( n % 2 == 0 ):
        base_paths = base_paths + new_build_pa_by_four( m, n )
    else:
        base_paths = base_paths + new_build_pa_by_three( m, n )

    if( n < 5 ):
        return base_paths

    if( m == 9 and ( n == 8 or n == 10 ) ):
        base_paths = base_paths + base_paths_for_K_9x_8_or_10( n )
        return base_paths

    # First split everything from 
    # 2 through (n-1)/2 if n is odd and
    # 2 through (n-2)/2 if n is even
    # into a set of units and nonunits modulo n.
    #
    # unused_small_units_of_Zn should have length phi(n)/2
    # unused_small_nonunits_of_Zn should have length 
    # ( n - phi(n) - 1 ) / 2 if n is odd, and
    # ( n - phi(n) - 2 ) / 2 if n is even.
    # as 1 will be 

    small_units_of_Zn = []
    small_nonunits_of_Zn = []

    for i in range( 2, ( n + 1 ) // 2 ):
        if( gcd( i, n ) == 1 ):
            small_units_of_Zn.append( i )
        else: 
            small_nonunits_of_Zn.append( i )

    Q = len( small_units_of_Zn ) // 2
    R = len( small_units_of_Zn ) % 2
    


    # First, we use edge lengths from 
    # Z_m^* x +/-{u,v}  to build base baths
    # which use all nonunit edge lengths from this set
    
    for i in range( Q ):
        base_paths = base_paths + base_path_with_four_units( p, a, n, small_units_of_Zn[2*i], small_units_of_Zn[2*i+1] )

    # If there is a unit pair of Z_n leftover, namely when R = 1, 
    # then its corresponding edge lengths will be handled in the
    # same way the nonunit pairs of Z_n will be handled.

    if( R == 1 ):
        small_nonunits_of_Zn.append( small_units_of_Zn[2*Q] )

    # We need to identify which edge lengths have been used
    # and which edge lengths have not been used in currently
    # constructed base paths.

    differences = [0] * (m*n)
    
    for P in base_paths:
        for i in range( len( P ) - 1 ):
            differences[ ( P[i]-P[i+1] ) % (m*n) ] += 1
            differences[ ( P[i+1]-P[i] ) % (m*n) ] += 1

    # We need to identify which unit edge length pair which are unused,
    # and if R = 1, do not reduce to either of the leftover unit residues
    # modulo n.

    usable_units = []
    counter = 0
    i = 0

    while counter <  len( small_nonunits_of_Zn ) and i < ( m * n + 1) // 2:
        if( gcd( i, m * n ) == 1 ):
            if( not( R == 1 ) or ( i % n != small_units_of_Zn[2*Q] and i % n != n - small_units_of_Zn[2*Q] ) ):
                if differences[i] == 0:
                    usable_units.append( i )
                    counter += 1
        i += 1

    # Now we build a base path for each "nonunit" residue pair modulo n-1
    
    for d in small_nonunits_of_Zn:
        base_paths.append( base_path_with_all_but_one_nonunit( m, n, d, usable_units.pop() ) )
    
    return base_paths











# Function: improved_build_pa_by_pb
#
# Inputs: odd prime p and two positive integers a and b
#
# Output: a sufficient set of base paths for 
#         X(Z_{p^(a+b)} ;Z_{p^(a+b)}\ p^a Z_{p^(a+b)}).

def improved_build_pa_by_pb( p, a, b ):
    if( a == 1 ):
        return []
        
    q = p**a
    r = p**b
    
    base_paths = []

    for j in range( r // p ):
        base_path = [ 0 ]

        for i in range( 1, q ):
            if( p == 3 and a % 2 == 0 and i >= q - 8 ):
                break
            if( i % 2 == 0 ):
                base_path.append( i // 2 )
            elif( i <  q - p ):
                base_path.append( ( ( 1 - q ) * ( i - 1 ) // 2 - j * p * q - p + ( q - 2 ) * p * ( ( i - 1 ) // ( 2 * p ) ) ) % ( q * r ) )
            else:
                base_path.append( ( - ( i + 1 ) // 2 - j * p * q ) % ( q * r ) )
    
        if( p == 3 and a % 2 == 0 ):
            ell = ( q - 9 ) // 2
            base_path.append( ( ell + 6 + 1 * q + j * 3 * q ) % ( q * r ) )
            base_path.append( ( ell + 1 + 0 * q ) % ( q * r ) )
            base_path.append( ( ell + 7 + 2 * q + j * 3 * q ) % ( q * r ) )
            base_path.append( ( ell + 5 + 0 * q ) % ( q * r ) )
            base_path.append( ( ell + 4 - 2 * q - j * 3 * q ) % ( q * r ) )
            base_path.append( ( ell + 3 - 3 * q - j * 6 * q ) % ( q * r ) )
            base_path.append( ( ell + 8 - 1 * q - j * 3 * q ) % ( q * r ) )
            base_path.append( ( ell + 2 - 1 * q - j * 6 * q ) % ( q * r ) )
            base_path.append( ( ( 1 - j * 3 ) * q ) % ( q * r ) )
        else:
           base_path.append( ( ( 1 + j * p ) * q ) % ( q * r ) )

        base_paths.append( base_path )
            
    return base_paths











# Function: build_pa_by_2pb
#
# Inputs: odd prime p and two positive integers a and b
#
# Output: a sufficient set of base paths for 
#         X(Z_{2p^(a+b)} ;Z_{2p^(a+b)}\ p^a Z_{2p^(a+b)}).

def build_pa_by_2pb( p, a, b ):

    q = p**a
    r = p**b
    
    base_paths = []

    if( a == 1 ):
        good_endpoints = []
        base_path = []
        
        k = 0
        counter = 0
        while counter < ( r + 1 ) // 2:
            k += 1
            if( k % p > 0  and k != ( r + 1 ) // 2 ):
                counter += 1
                good_endpoints.append( ( k*q, 1 ) )

        for j in range( ( r - 1 ) // 2 ):
            base_path = []

            for i in range( q ):
                if( i % 2 == 0 ):
                    base_path.append( ( i // 2, 0 ) )
                else:
                    base_path.append( ( q * r - ( i + 1 ) // 2 - j * q, 0 ) )
        
            base_path.append( good_endpoints.pop() )
            
            base_paths.append( combined_base_path( base_path, q*r, 2 ) )
        
        base_path = []
        
        for i in range( q ):
            if( i % 2 == 0 ):
                base_path.append( ( i // 2, 0 ) )
            elif( i > ( q - 1 ) // 2 ):
                base_path.append( ( q * r - ( i + 1 ) // 2 - ( r - 1 ) * q // 2, 1 ) )
            else:
                base_path.append( ( q * r - ( i + 1 ) // 2 - ( r - 1 ) * q // 2, 0 ) )
    
        base_path.append( good_endpoints.pop() )
        
        base_paths.append( combined_base_path( base_path, q*r, 2 ) )
        
    else:
        simple_base_paths = improved_build_pa_by_pb( p, a, b )

        for s in simple_base_paths:
            base_path = []
            for i in range( len( s ) ):
                base_path.append( ( s[i], i % 2 ) )
            base_paths.append( combined_base_path( base_path, q*r, 2 ) )

        
        if( p != 3 ):
            good_endpoints = []
            k = 0
            counter = 0
            while counter < ( r + 1 ) // 2:
                k += 1
                if( k % p > 1  and ( p % 4 == 1 or k != ( r + 1 ) // 2 ) ):
                    counter += 1
                    good_endpoints.append( ( k*q, 1 ) )
            
            for j in range( ( r - 1 ) // 2 ):
                base_path = []

                for i in range( q ):
                    if( i % 2 == 0 ):
                        base_path.append( ( i // 2, 0 ) )
                    else:
                        base_path.append( ( q * r - ( i + 1 ) // 2 - j * q, 0 ) )
            
                base_path.append( good_endpoints.pop() )
                
                base_paths.append( combined_base_path( base_path, q*r, 2 ) )
            
            base_path = []
            
            if p % 4 == 1:
                for i in range( q ):
                    if i % 2 == 0:
                        base_path.append( ( i // 2, 0 ) )
                    elif i < ( q - 1 ) // 2:
                        base_path.append( ( q*r - ( i + 1 ) // 2 - q * ( r - 1 ) // 2, 0 ) )
                    elif i < q - ( p - 1 ) // 2:
                        base_path.append( ( q * ( 2 * i - p + 3 ) // 4 + ( i - 3 * p ) // 2 - p * ( q + 2 ) * ( ( 2 * i - p - 1 ) // ( 4 * p ) ), 1 ) )
                    else:
                        base_path.append( ( q*r - ( i + 1 ) // 2 - q * ( r - 1 ) // 2, 1 ) )
                        
            else:
                for i in range( q ):
                    if i % 2 == 0:
                        base_path.append( ( i // 2, 0 ) )
                    elif i < ( q - 1 ) // 2:
                        base_path.append( ( q*r - ( i + 1 ) // 2 - q * ( r - 1 ) // 2, 0 ) )
                    elif i < ( q + p - 2 ) // 2:
                        base_path.append( ( q*r - ( i + 1 ) // 2 - q * ( r - 1 ) // 2, 1 ) )
                    else:
                        base_path.append( ( q * ( ( ( i + 1 - p * ( ( i + 1 ) // p ) ) // 2 ) + 1 ) - p * ( ( i + 1 ) // ( 2 * p ) ) - ( p - i - 2 ) // 2 + p * ( ( p - i - 2 ) // (2 * p ) ), 1 ) )

            base_path.append( good_endpoints.pop() )
            base_paths.append( combined_base_path( base_path, q*r, 2 ) )

        else:
            for s in simple_base_paths:

                base_path = []
                for i in range( len( s ) - 1 ):
                    base_path.append( ( s[i], 0 ) )
                base_path.append( ( s[len(s)-1] + q, 1 ) )
                base_paths.append( combined_base_path( base_path, q*r, 2 ) )

            for j in range( r // p ):

                base_path = [ ( 0, 0 ) ]
                base_path.append( ( 2 + j * p * q, 0 ) )
                base_path.append( ( 7 + 2 * j * p * q, 0 ) )
                base_path.append( ( 6 + j * p * q, 1 ) )
                base_paths.append( combined_base_path( base_path, q*r, 2 ) )

                base_path = [ ( 0, 0 ) ]
                base_path.append( ( q + 2 + j * p * q, 0 ) )
                base_path.append( ( q + 7 + 2 * j * p * q, 1 ) )
                base_path.append( ( q + 6 + j * p * q, 1 ) )
                base_paths.append( combined_base_path( base_path, q*r, 2 ) )

                if( q > 9 ):
                    for k in range( ( q - 9 ) // 12 ):
                        c = 7 + 6 * k
                        base_path = [ ( 0, 0 ) ]
                        base_path.append( ( 1 * c + 0 * q + 1 * j * p * q, 0 ) )
                        base_path.append( ( 2 * c + 1 * q + 2 * j * p * q, 0 ) )
                        base_path.append( ( 3 * c + 3 * q + 3 * j * p * q, 0 ) )
                        base_path.append( ( 4 * c + 3 * q + 4 * j * p * q, 1 ) )
                        base_path.append( ( 5 * c + 4 * q + 5 * j * p * q, 0 ) )
                        base_path.append( ( 6 * c + 6 * q + 6 * j * p * q, 1 ) )
                        base_path.append( ( 7 * c + 6 * q +     ( q - 9 ) // 2 + 7 * j * p * q, 1 ) )
                        base_path.append( ( 8 * c + 7 * q + 2 * ( q - 9 ) // 2 + 8 * j * p * q, 1 ) )
                        base_path.append( ( 9 * c + 9 * q + 3 * ( q - 9 ) // 2 + 9 * j * p * q, 1 ) )
                        base_paths.append( combined_base_path( base_path, q*r, 2 ) )
            
    return base_paths
