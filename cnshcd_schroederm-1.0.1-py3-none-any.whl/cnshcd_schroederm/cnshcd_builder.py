# python part_create_another.py

from .helpers import *
from .set_partition import *
from .checkers import *
from .km_builder import *
from .global_ import *
from .k15_builder import *
from .combine_paths_and_parts import *
from .k_mxn_small import *
from .pn_builder import *
from .km2_builder import *


set_type = [ 'sufficient', 'complete' ]


def print_both_sets( S, m, n, b, all_print ):
    if( b > 1 ):
        print( "     The following " + set_type[all_print] + " set of base paths for K_{%dx%d} are given using Z_{%d} x Z_{%d} as the vertex set.\n" % ( m, n, m * n // b, b ) )
        print_base_paths( S, m * n // b, b, all_print )
        print_non_units( m, n, b )
    print( "     The following " + set_type[all_print] + " set of base paths for K_{%dx%d} are given using Z_{%d} as the vertex set.\n" % ( m, n, m * n ) )
    print_base_paths( S, m * n, 1, all_print )
    print_non_units( m, n )



def buratti( m, all_print, myvb = True ):

    print( "All HCDs are 1-symmetric, and K_{%d} = K_{%dx1} has a cyclic HCD since %d is not 15 nor a composite prime power. [Buratti and Del Fra, 2004]\n" % ( m, m, m ) )
    
    S = base_paths_of_km( m )
    S = add_unit_base_paths( S, m ) 

    if( myvb ): 
        print_both_sets( S, m, 1, 1, all_print )
        # print( "     The following set of base paths for K_{%d} = K_{%dx%d} are given using Z_{%d} as the vertex set.\n" % ( m, m, 1, m ) )
        # print_base_paths( S, m, 1, all_print )
        # print_non_units( m, 1 )

    return S


def jordan_morris( m, all_print, myvb = True ):

    print( "K_{%d}-F = K_{%dx2} has a cyclic, 2-symmetric HCD as %d is not a prime power. [Jordon and Morris, 2008]\n" % ( 2 * m, m, m ) )
    S = build_km2( m )
    S = add_unit_base_paths( S, m * 2 ) 
    if( myvb ): 
        print_both_sets( S, m, 2, 2, all_print )
    return S
    
def simple_build( m, n, all_print, myvb = True ):

    if( n == 1 ):
        return buratti( m, all_print, myvb)
        
    elif( n == 2 ):
        return jordan_morris( m, all_print, myvb )
        
    elif( m == 21 and len( prime_factorization( n ) ) == 1 and n % 2 == 0 ):
        print( "Use Lemma 3.9 to build a cyclic, %d-symmetric HCD for K_{21x%d}.\n" % ( n, n ) )
        S = build_initial_base_paths( 21, n )
        if( myvb ): print_both_sets( S, 21, n, n, all_print )
        return S
 
    else:
        buratti( m, all_print, myvb )
        if( n == 3 ):
            print( "Use Lemma 3.8 to build a cyclic, 3-symmetric HCD of K_{%dx3}.\n" % m )
        else:
            print( "Use Lemma 3.7 to build a cyclic, %d-symmetric HCD of K_{%dx%d}.\n" % ( n, m, n ) )
 
        S = build_initial_base_paths( m, n )
        S = add_unit_base_paths( S, m * n )

        if( myvb): print_both_sets( S, m, n, n, all_print )
        return S

def build_up_with_partitions( C, m, n, q, p, all_print, myvb = True ):
    if( q > 1 ):
        print( "Next, use Corollary 4.4 to build a {1,%d}-unitized partition of Z_{%d}.\n" % ( p, q ) )
        if( myvb ):
            PP = set_partition_general( p, q )
            print( "     The following are the parts of size %d in a {1,%d}-unitized partition of Z_{%d}.\n" % (p, p, q) )
            counter = 0
            for i in  PP:
                if( len( i ) > 1 ):
                    print( "     Part %2d: " % counter, end = '' )
                    counter += 1
                    print( i )
            print( )
            print( "     The following are the units of a {1,%d}-unitized partition of Z_{%d}.\n" % ( p, q) )
            counter = 0
            for i in PP:
                if( len( i ) == 1 ):
                    if( counter == 0 ):
                        print( "     { ", end = '' )
                    else:
                        print( ", ", end = '' )
                    print( "%d" % i[0], end = '' )
                    counter += 1
            print( "}\n" )

        print( "Using the base paths for a cyclic, %d-symmetric HCD of K_{%dx%d} and a {1,%d}-unitized partition of Z_{%d}, we build the following cyclic, %d-symmetric HCD of K_{%dx%d} using Corollary 4.9.\n" % ( n, m, n, p, q, n*q, m, n*q ) )
                
    
    S = combine_paths_and_partition( C, m*n, p, q )

    if( q > 1 and myvb): print_both_sets( S, m, n*q, n*q, all_print )

    return S

def include_non_coprimes( C, m, n, p, a, all_print, myvb = True ):
    print( "Using the base paths for a cyclic, %d-symmetric HCD of K_{%dx%d}, we build a cyclic, %d-symmetric HCD of K_{%dx%d} using Theorem 4.11.\n" % ( n, m, n, n*p**a, m, n*p**a ) )

    S = combine_paths_with_prime_divisors( C, m, n, p, a )
    S = add_unit_base_paths( S, m * n * ( p ** a ) )
    q = largest_prime_power( m, p )
    
    if( myvb ): print_both_sets( S, m, n * ( p ** a ), p ** ( a + q ), all_print )
        
    return S
 

def print_15_p2( e, all_print, myvb = True ):
    print( "Use Lemma 3.12 to build a cyclic, %d-symmetric HCD for K_{%dx%d}.\n" % ( 2**e, 15, 2**e ) )
    S = build_k_fifteen_by_power_of_two( e )
    S = add_unit_base_paths( S, 15 * ( 2 ** e ) )
    if( myvb ): print_both_sets( S, 15, 2**e, 2**e, all_print )
    return S

def print_15_p3( e, all_print, myvb = True ):
    print( "Use Lemma 4.12 to build a cyclic, %d-symmetric HCD for K_{%dx%d}.\n" % ( 3**e, 15, 3**e ) )
    S = build_k_fifteen_by_power_of_three( e )
    S = add_unit_base_paths( S, 15 * ( 3 ** e ) )
    if( myvb ): print_both_sets( S, 15, 3**e, 3**(e+1), all_print )
    return S

def print_15_p5( e, all_print, myvb = True ):
    print( "Use Lemma 4.13 to build a cyclic, %d-symmetric HCD for K_{%dx%d}.\n" % ( 5**e, 15, 5**e ) )
    S = build_k_fifteen_by_power_of_five( e )
    S = add_unit_base_paths( S, 15 * ( 5 ** e ) )
    if( myvb ): print_both_sets( S, 15, 5**e, 5**(e+1), all_print )
    return S

def print_15_po( q, all_print, myvb = True ):
    print( "Use Lemma 3.12 to build a cyclic, %d-symmetric HCD for K_{%dx%d}.\n" % ( q, 15, q ) )
    S = build_k_fifteen_by_power_of_other_prime_power( q )
    S = add_unit_base_paths( S, 15 * q )
    if( myvb ): print_both_sets( S, 15, q, q, all_print )
    return S

def simple_prime_power_build( p, e, n, thm_name, all_print, myvb = True ):
    print( "Use " + thm_name + " to build a cyclic, %d-symmetric HCD for K_{%dx%d}.\n" % ( n, p ** e, n ) )
    S = new_build_pa_by_n( p, e, n )
    S = add_unit_base_paths( S, (p ** e ) * n )
    if( myvb ): print_both_sets( S, p ** e, n, n, all_print )
    return S

def simple_prime_build( p, n, thm_name, all_print, myvb = True ):
    print( "Use " + thm_name + " to build a cyclic, %d-symmetric HCD for K_{%dx%d}.\n" % ( n, p, n ) )
    S = build_initial_base_paths( p, n )
    S = add_unit_base_paths( S, p * n )
    if( myvb ): print_both_sets( S, p, n, n, all_print )
    return S

def print_pa2pb( p, a, b, thm_name, all_print, myvb = True ):
    print( "Use " + thm_name + " to build a cyclic, %d-symmetric HCD for K_{%dx%d}.\n" % ( 2*p**b, p**a, 2*p**b ) )
    S = build_pa_by_2pb( p, a, b )
    # S = build_initial_base_paths( p, n )
    S = add_unit_base_paths( S, 2*p**(a+b) )
    if( myvb ): print_both_sets( S, p**a, 2*p**b, 2, all_print )
    return S

def print_papb( p, a, b, thm_name, all_print, myvb = True ):
    print( "Use " + thm_name + " to build a cyclic, %d-symmetric HCD for K_{%dx%d}.\n" % ( p**b, p**a, p**b ) )
    S = improved_build_pa_by_pb( p, a, b )
    # S = build_initial_base_paths( p, n )
    S = add_unit_base_paths( S, p**(a+b) )
    if( myvb ): print_both_sets( S, p**a, p**b, 1, all_print )
    return S











# Function: cnshcd_builder
#
# Inputs: positive integers m and n
#         level of verbosity (defaulted to true)
#
# Output: a cyclic, n-symmetric HCD of K_{mxn}, if
#         the necessary numerical conditions are met.

def cnshcd_builder( m, n, all_print, vb = True ):
    M = prime_factorization( m )
    N = prime_factorization( n )
    list_of_primes_for_m = []
    list_of_primes_for_n = []
    p = smallest_factor( m )

    print() 
    
    for q in M:
        list_of_primes_for_m.append( smallest_factor( q ) )
    for q in N:
        list_of_primes_for_n.append( smallest_factor( q ) )

    if( m % 4 == 3 and n % 4 == 2 ):
        print( "K_{%dx%d} does not have an n-symmetric HCD as %d = 3 mod 4 and %d = 2 mod 4. [Schroeder 2015]\n" % ( m, n, m, n ) )
        return []
        
    if( m == 15 and n == 1 ):
        print( "K_{15} = K_{15x1} does not have a cyclic HCD. [Buratti and Del Fra, 2004]\n" )
        return []
    
    if( len( M ) == 1 and M[0] != list_of_primes_for_m[0] and n == 1 ):
        print( "K_{%d} = K_{%d x 1} does not have a cyclic HCD since %d is a composite prime power. [Buratti and Del Fra, 2004]\n" % ( m, m, m ) )
        return []
        
    if( len( M ) == 1 and n == 2 ):
        print( "K_{%d}-F = K_{%d x 2} does not have a cyclic HCD since %d is a prime power. [Jordan and Morris, 2008]\n" % ( 2 * m, m, m ) )
        return []
        
    if( n == 1 ):
        S = buratti( m, all_print, vb )
        return S
        
    if( n == 2 ):
        S = jordan_morris( m, all_print, vb )
        return S
        
    common_primes = []
    common_prime_powers = []
    common_prime_exponents = []
    
    A = 1
    B = 1
    
    
    for i in range( len( N ) ):
        if( list_of_primes_for_n[i] in list_of_primes_for_m ):
            common_primes.append( list_of_primes_for_n[i] )
            common_prime_powers.append( N[i] )
            common_prime_exponents.append( largest_prime_power( n, list_of_primes_for_n[i] ) )
        
        elif( list_of_primes_for_n[i] < p ):
            A *= N[i]
        else:
            B *= N[i]

    if( vb ): print()
    if( vb ): print( "Smallest prime of m: " + str(p) )
    if( vb ): print()
    if( vb ): print( "The factorization of n: " )
    if( vb ): print( "   A = " + str(A) )
    if( vb ): print( "   B = " + str(B) )
    
    if( len( common_primes ) == 0 ):
        if( vb ): print( "   There are no common primes." )
    for i in range( len( common_primes ) ):
        if( vb ): print( "   Common prime power: %2d^%d" % ( common_primes[i], common_prime_exponents[i] ) )

        
    if( m != 15 and not( len( M ) == 1 and M[0] != p ) and ( not( m == p ) or n % 4 != 2 ) ):
        S = simple_build( m, A, all_print, vb )
        S = build_up_with_partitions( S, m, A, B, p, all_print, vb )
        current_modulus = A * B
        for i in range( len( common_prime_powers ) ):
            S = include_non_coprimes( S, m, current_modulus, common_primes[i], common_prime_exponents[i], all_print, vb )

            # S = combine_paths_with_prime_divisors( S, m, current_modulus, common_primes[i], common_prime_exponents[i] )
            current_modulus *= common_prime_powers[i]
        
    elif( m == 15 ):
        if( A > 1 ):
            S = print_15_p2( largest_prime_power( A, 2 ), all_print, vb )
            S = build_up_with_partitions( S, m, A, B, p, all_print, vb )
            current_modulus = A * B
            for i in range( len( common_prime_powers ) ):
                # S = combine_paths_with_prime_divisors( S, m, current_modulus, common_primes[i], common_prime_exponents[i] )
                S = include_non_coprimes( S, m, current_modulus, common_primes[i], common_prime_exponents[i], all_print, vb )
                current_modulus *= common_prime_powers[i]
        elif( B > 1 ):
            r = smallest_factor( B )
            exp = largest_prime_power( B, r )
            C = B // ( r ** exp )

            S = print_15_po( r ** exp, all_print, vb )
            S = build_up_with_partitions( S, m, r ** exp, C, p, all_print, vb )
            current_modulus = A * B
            for i in range( len( common_prime_powers ) ):
                # S = combine_paths_with_prime_divisors( S, m, current_modulus, common_primes[i], common_prime_exponents[i] )
                S = include_non_coprimes( S, m, current_modulus, common_primes[i], common_prime_exponents[i], all_print, vb )
                current_modulus *= common_prime_powers[i]

            # S = build_k_fifteen_by_power_of_other_prime_power( r ** exp )
            # S = add_unit_base_paths( S, m * r ** exp )
            # S = combine_paths_and_partition( S, m*A*r**exp, p, C )
            # current_modulus = A * B
            # for i in range( len( common_prime_powers ) ):
                # S = combine_paths_with_prime_divisors( S, m, current_modulus, common_primes[i], common_prime_exponents[i] )
                # current_modulus *= common_prime_powers[i]
        elif( common_primes[0] == 3 ):
            S = print_15_p3( common_prime_exponents[0], all_print, vb )
            # S = build_k_fifteen_by_power_of_three( common_prime_exponents[0] )
            if( len( common_primes ) > 1 ):
                S = include_non_coprimes( S, m, 3 ** common_prime_exponents[0], common_primes[1], common_prime_exponents[1], all_print, vb )
                # S = combine_paths_with_prime_divisors( S, m, common_prime_powers[0], common_primes[1], common_prime_exponents[1] )
        else: 
            S = print_15_p5( common_prime_exponents[0], all_print, vb )
            # S = build_k_fifteen_by_power_of_five( common_prime_exponents[0] )
    
    elif( len( M ) == 1 and n % 4 == 2 ):
        mexp = largest_prime_power( m, p )
        if( A >= 3 ):
            if( m == p ):
                S = simple_build( m, A, all_print, vb )
                # S = build_initial_base_paths( m, A )
            else:
                S = simple_prime_power_build( p, mexp, A, 'Theorem 3.19', all_print, vb )
                # S = new_build_pa_by_n( p, mexp, A )
            # S = add_unit_base_paths( S, m * A )
            # S = combine_paths_and_partition( S, m*A, p, B )
            S = build_up_with_partitions( S, m, A, B, p, all_print, vb )
            if( len( common_primes ) > 0 ):
                S = include_non_coprimes( S, m, A*B, p, common_prime_exponents[0], all_print, vb )
                # S = combine_paths_with_prime_divisors( S, m, A * B, p, common_prime_exponents[0] )
        elif( A == 2 and B > 1 ):
            r = smallest_factor( B )
            exp = largest_prime_power( B, r )
            C = B // ( r ** exp )
            if( m == p ):
                S = simple_prime_build( m, A * r ** exp, 'Corollary 3.11', all_print, vb )
                # S = build_initial_base_paths( m, A * r ** exp )
            else:
                S = simple_prime_power_build( p, mexp, A * r ** exp, 'Corollary 3.20', all_print, vb )
                # S = new_build_pa_by_n( p, mexp, A * r ** exp )
            # S = add_unit_base_paths( S, m * A * r ** exp )
            S = build_up_with_partitions( S, m, A * r ** exp, C, p, all_print, vb )
            # S = combine_paths_and_partition( S, m * A * r ** exp, p, C )
            if( len( common_primes ) > 0 ):
                S = include_non_coprimes( S, m, A*B, p, common_prime_exponents[0], all_print, vb )
                # S = combine_paths_with_prime_divisors( S, m, A * B, p, common_prime_exponents[0] )
        else:
            if( mexp == 1 ):
                S = print_pa2pb( p, mexp, common_prime_exponents[0], 'Lemma 4.14', all_print, vb )
            elif( p == 3 ):
                S = print_pa2pb( p, mexp, common_prime_exponents[0], 'Lemma 4.18', all_print, vb )
            else:
                S = print_pa2pb( p, mexp, common_prime_exponents[0], 'Lemma 4.16', all_print, vb )
            # S = build_pa_by_2pb( p, mexp, common_prime_exponents[0] )
            
    else:
        mexp = largest_prime_power( m, p )
        if( A >= 3 ):
            S = simple_prime_power_build( p, mexp, A, 'Theorem 3.19', all_print, vb )
            # S = new_build_pa_by_n( p, mexp, A )
            # S = add_unit_base_paths( S, m * A )
            S = build_up_with_partitions( S, m, A, B, p, all_print, vb )
            # S = combine_paths_and_partition( S, m*A, p, B )
            if( len( common_primes ) > 0 ):
                S = include_non_coprimes( S, m, A*B, p, common_prime_exponents[0], all_print, vb )
                # S = combine_paths_with_prime_divisors( S, m, A * B, p, common_prime_exponents[0] )
        elif( A == 1 and B > 1 ):
            r = smallest_factor( B )
            exp = largest_prime_power( B, r )
            C = B // ( r ** exp )
            S = simple_prime_power_build( p, mexp, A * r ** exp, 'Corollary 3.20', all_print, vb )
            # S = new_build_pa_by_n( p, mexp, A * r ** exp )
            # S = add_unit_base_paths( S, m * A * r ** exp )
            S = build_up_with_partitions( S, m, A * r ** exp, C, p, all_print, vb )
            # S = combine_paths_and_partition( S, m * A * r ** exp, p, C )
            if( len( common_primes ) > 0 ):
                S = include_non_coprimes( S, m, A*B, p, common_prime_exponents[0], all_print, vb )
                # S = combine_paths_with_prime_divisors( S, m, A * B, p, common_prime_exponents[0] )
        elif( p == 3 and mexp % 2 == 0 ):
            S = print_papb( p, mexp, common_prime_exponents[0], 'Lemma 4.17', all_print, vb )
        else:
            S = print_papb( p, mexp, common_prime_exponents[0], 'Lemma 4.15', all_print, vb )
            # S = improved_build_pa_by_pb( p, mexp, common_prime_exponents[0] )
            
    return S
            
                







"""
# Function: interface
#
# Inputs: none
#
# Output: an interactive program for soliciting
#         cyclic, symmetric HCDs for balanced 
#         complete multipartite graphs.

def interface():

    while True:

        print()
        print( "With this program, you may produce a cyclic, symmetric HCD of K_{m x n} for a particular m and n." )

        print()
        m = input( "Enter the value of m: " )
        n = input( "Enter the value of n: " )

        if( m == '' or n == '' ):
            print()
            return
            
        m = int( m )
        n = int( n )
        
        if( m % 2 == 0 ):
            print()
            print( "This program only builds decompositions when m is odd." )
        else:
            S = cnshcd_builder( m, n )
            check_base_paths( S, m, n )
            print()
            question = input( "Print the base paths -- complete, sufficient, or neither (c/s/n): " )
            print()

            if( question == 'c' ):
                question = input( "Would you like vertices printed as ordered pairs (y/n): ")
                if( question == 'y' ):
                    print()
                    first  = int( input( "First  ordinate modulus: " ) )
                    second = int( input( "Second ordinate modulus: " ) )
                    print( "Complete set of base paths for K_{%d x %d}: " % ( m, n ) )
                    print()
                    for i in range( len( S ) ):
                        print( "    Path %3d: " % i + str(ordered_pair_path(S[i],first, second)) )
                else:
                    print()
                    print( "Complete set of base paths for K_{%d x %d}: " % ( m, n ) )
                    print()
                    for i in range( len( S ) ):
                        print( "    Path %3d: " % i + str(S[i]) )
            elif( question == 's' ):
                question = input( "Would you like vertices printed as ordered pairs (y/n): ")
                if( question == 'y' ):
                    print()
                    first  = int( input( "First  ordinate modulus: " ) )
                    second = int( input( "Second ordinate modulus: " ) )
                    print( "Sufficient set of base paths for K_{%d x %d}: " % ( m, n ) )
                    print()
                    counter = 0
                    for i in range( len( S ) ):
                        if( len( S[i] ) > 2 ):
                            print( "    Path %3d: " % counter + str(ordered_pair_path(S[i],first, second)) )
                            counter += 1
                else:
                    print()
                    print( "Sufficient set of base paths for K_{%d x %d}: " % ( m, n ) )
                    print()
                    counter = 0
                    for i in range( len( S ) ):
                        if( len( S[i] ) > 2 ):
                            print( "    Path %3d (%3d): " % ( counter, i ) + str(S[i]) )
                            counter += 1
                
                displayDiffChart = True
                while( displayDiffChart ):
                    print()
                    question = input( "For which path would you like to see the edge length chart? " )
                    if( question == "" ):
                        displayDiffChart = False
                    else:
                        print()
                        check_diff_grid( [S[min(len(S)-1,int(question))]], m, n )
            
#Function Entrypoint
def entrypoint( m, n, question ):

   # while True:

        print()
        print( "With this program, you may produce a cyclic, symmetric HCD of K_{m x n} for a particular m and n." )

        print()
       # m = input( "Enter the value of m: " )
       # n = input( "Enter the value of n: " )

        if( m == '' or n == '' ):
            print()
            return
            
        m = int( m )
        n = int( n )
        
        if( m % 2 == 0 ):
            print()
            print( "This program only builds decompositions when m is odd." )
        else:
            S = cnshcd_builder( m, n )
            check_base_paths( S, m, n )
            print()
            # question = input( "Print the base paths -- complete, sufficient, or neither (c/s/n): " )
            print()

            if( question == 'c' ):
                question='n'
                # question = input( "Would you like vertices printed as ordered pairs (y/n): ")
                if( question == 'y' ):
                    print()
                    first  = int( input( "First  ordinate modulus: " ) )
                    second = int( input( "Second ordinate modulus: " ) )
                    print( "Complete set of base paths for K_{%d x %d}: " % ( m, n ) )
                    print()
                    for i in range( len( S ) ):
                        print( "    Path %3d: " % i + str(ordered_pair_path(S[i],first, second)) )
                else:
                    print()
                    print( "Complete set of base paths for K_{%d x %d}: " % ( m, n ) )
                    print()
                    for i in range( len( S ) ):
                        print( "    Path %3d: " % i + str(S[i]) )
            elif( question == 's' ):
                question='n'
                # question = input( "Would you like vertices printed as ordered pairs (y/n): ")
                if( question == 'y' ):
                    print()
                    first  = int( input( "First  ordinate modulus: " ) )
                    second = int( input( "Second ordinate modulus: " ) )
                    print( "Sufficient set of base paths for K_{%d x %d}: " % ( m, n ) )
                    print()
                    counter = 0
                    for i in range( len( S ) ):
                        if( len( S[i] ) > 2 ):
                            print( "    Path %3d: " % counter + str(ordered_pair_path(S[i],first, second)) )
                            counter += 1
                else:
                    print()
                    print( "Sufficient set of base paths for K_{%d x %d}: " % ( m, n ) )
                    print()
                    counter = 0
                    for i in range( len( S ) ):
                        if( len( S[i] ) > 2 ):
                            print( "    Path %3d (%3d): " % ( counter, i ) + str(S[i]) )
                            counter += 1

                print("For which path would you like to see the edge length chart?")


def displayChart(m, n, answer, S):
                # displayDiffChart=True
                # while( displayDiffChart ):
                    question=answer
                    print("Displaying edge length for Path["+question+"]:")
                    m=int(m)
                    n=int(n)
                    # question = input( "For which path would you like to see the edge length chart? " )
                   # if( question == "" ):
                       # displayDiffChart = False
                   # else:
                       # print()
                    check_diff_grid( [S[min(len(S)-1,int(question))]], m, n )

# This line executes the interface.
#interface( )           

# m=7
# n=19

# S = cnshcd_builder( m, n )
# check_base_paths( S, m, n )

# for s in S:
    # print( s )

# check_diff_grid( S, m, n )

# m = 49
# n = 49*2

# S = cnshcd_builder( m, n )

# for s in S:
    # print( s )
    
# check_diffs( [S[-1]], m, n )

m = int(sys.argv[1])
n = int(sys.argv[2])
print_all = int( sys.argv[3] )
print_paths = int( sys.argv[4] )

S = cnshcd_builder( m, n, print_all, print_paths )
