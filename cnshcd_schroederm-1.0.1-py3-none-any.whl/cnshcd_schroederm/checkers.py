from .helpers import *
from .global_ import *
    









# Function: check_diffs
#
# Inputs: base paths S
#         integers m and n
#
# Output: This routine will build a grid to 
#         check the edge lengths which are 
#         used by the set of base paths in S.
#         These base paths are assumed to
#         belong in K_{m x n}, and the grid places
#         the occurrence of edge length jm+i in the
#         (i,j) entry.

def check_diffs( S, m, n ):
        
    checkArray = [[0 for x in range(n)] for y in range(m)]
    for i in range( len( S ) ):
        for j in range( 1, len( S[i] ) ):
            checkArray[(S[i][j]-S[i][j-1])%m][(S[i][j]-S[i][j-1])//m] += 1
            checkArray[(S[i][j-1]-S[i][j])%m][(S[i][j-1]-S[i][j])//m] += 1
            
    for i in range(m):
        print( "%3d: " % i, end='' )
        for j in range(n):
            if( checkArray[i][j] == 1 ):
                print( "1", end='')
            elif( checkArray[i][j] > 1 ):
                print( "#", end='')
            else:
                print(".", end='')
        print()
    









# Function: check_diff_grid
#
# Inputs: base paths S
#         integers m and n
#
# Output: This routine will build a grid to 
#         check the edge lengths which are 
#         used by the set of base paths in S.
#         These base paths are assumed to
#         belong in K_{m x n}, and the grid places
#         the occurrence of edge length whose
#         residue modulo m and n is i and j in the
#         (i,j) entry.

def check_diff_grid( S, m, n ):
        
    checkArray = [[0 for x in range(n)] for y in range(m)]
    for i in range( len( S ) ):
        for j in range( 1, len( S[i] ) ):
            checkArray[(S[i][j]-S[i][j-1])%m][(S[i][j]-S[i][j-1])%n] += 1
            checkArray[(S[i][j-1]-S[i][j])%m][(S[i][j-1]-S[i][j])%n] += 1
            
    for i in range(m):
        print( "%5d: " % i, end='' )
        for j in range(n):
            if( checkArray[i][j] == 1 ):
                print( "1", end='')
            elif( checkArray[i][j] > 1 ):
                print( "#", end='')
            else:
                print(".", end='')
        print()
    









# Function: check_base_paths
#
# Inputs: base paths S
#         integers m and n
#
# Output: This routine will determine if 
#         a set of paths are, in fact, 
#         base paths, whether the set of 
#         base paths is valid (no overlapping
#         edge lengths), and if every nonunit
#         edge length present in K_{m x n} is 
#         accounted for in some base path in S.

def check_base_paths( S, m, n ):

    # First, check to see that each path is a base path
    
    if( m % 4 == 3 and n % 4 == 2 ):
        print( "The graph K_{%d x %d} cannot have a sufficient set of base paths." % ( m, n ) )
        return
        
    if( m == 15 and n == 1 ):
        print( "The graph K_{%d x %d} cannot have a sufficient set of base paths." % ( m, n ) )
        return
        
    P = prime_factorization( m )
    p = smallest_factor( m )
    
    if( len( P ) == 1 and m != p and n == 1 ):
        print( "The graph K_{%d x %d} cannot have a sufficient set of base paths." % ( m, n ) )
        return

    if( len( P ) == 1 and n == 2 ):
        print( "The graph K_{%d x %d} cannot have a sufficient set of base paths." % ( m, n ) )
        return

    mn = m*n
    usedDifferences = [0] * (mn)
    whereUsedDifferences = [-1] * (mn)
    areAllBasePaths = 1
    
    for i in range( len( S ) ):
        
        d = len( S[i] ) - 1
        
        # To determine if S[i] is a base path, first
        # check the residue of each vertex modulo d
        # to see if they are each distinct.

        checkedModuli = [0] * d
        for j in range( 1, d + 1 ):
            checkedModuli[S[i][j] % d] += 1
        correctModuli = 1
        
        if( verbose == 1 ):
            print( checkedModuli )
        for j in range( d ):
            if( checkedModuli[j] == 0 ):
                correctModuli = 0
        
        if( verbose == 1 ):
            if( correctModuli == 1 ):
                print( "Base path "+str(i)+" has the correct moduli for its vertices.")
            else:
                print( "Base path "+str(i)+" DOES NOT have the correct moduli for its vertices.")
                
        # Next, check the differences of the edges used 
        # in S[i] to be sure they are distinct
        
        differences = []
        distinctDifferences = 1

        for j in range( d ):
            if( whereUsedDifferences[( S[i][j] - S[i][j+1] ) % mn] == i ):
                distinctDifferences = 0

            whereUsedDifferences[( S[i][j] - S[i][j+1] ) % mn] = i
            whereUsedDifferences[( S[i][j+1] - S[i][j] ) % mn] = i
            usedDifferences[( S[i][j] - S[i][j+1] ) % mn] += 1
            usedDifferences[( S[i][j+1] - S[i][j] ) % mn] += 1

        if( verbose == 1 ):
            if( distinctDifferences == 1 ):
                print( "Base path "+str(i)+" has distinct edge lengths.")
            else:
                print( "Base path "+str(i)+" DOES NOT have distinct edge lengths.")
            
        # Last, check that the order of the final vertex
        # in S[i] has order mn/d; this is confirmed by 
        # checking that its gcd with mn is d.
        
        if( gcd( mn, S[i][d] ) == d ):
            if( verbose == 1 ): 
                print( "Base path "+str(i)+" has correct final vertex order.")
            correctOrder = 1
        else:
            if( verbose == 1 ):
                print( "Base path "+str(i)+" DOES NOT have correct final vertex order.")
            correctOrder = 0
            
        if( not( correctModuli == 1 and distinctDifferences == 1 and correctOrder == 1 ) ):
            print( "Base path " + str(i) + " is NOT a base path." )
            areAllBasePaths = 0
        else:
            if( verbose == 1 ): print( "Base path " + str(i) + " is     a base path." )
        
    
    # Next, check to see that all base paths have distinct edge lengths
    
    # print( "Checking that all base paths have distinct edge lengths." )
    
    distinctDifferences = 1
    for i in range( mn ):
        if( usedDifferences[i] > 1 ):
            print( "Repeated Difference " + str(i) + " or " + str( ordered_pair( i, m, n ) ) + " where m = " + str(m) + " and n = " + str(n) + ": occured " + str(usedDifferences[i]) + " times." )
            distinctDifferences = 0
  
    # Last, confirm that all non-unit edge lengths are used

    # print( "Checking that all non-unit edge lengths are used." )

    allNonunitsUsed = 1
    for i in range( ( mn + 1 ) // 2 ):
        if( not( gcd( i, mn ) == 1 or i % m == 0  ) ):
            if( usedDifferences[i] == 0 ):
                allNonunitsUsed = 0

    if( areAllBasePaths == 1 and distinctDifferences == 1 and allNonunitsUsed == 1 ):
        print()
        print( "There is a sufficient set of base paths for K_{" + str(m) + " x " + str(n) + "}." )
    else:
        print( "This set of base paths is NOT valid for K_{" + str(m) + " x " + str(n) + "}." )
        print( "areAllBasePaths = " + str(areAllBasePaths) )
        print( "distinctDifferences = " + str(distinctDifferences) )
        print( "allNonunitsUsed = " + str(allNonunitsUsed) )
        

def print_non_units( m, n, b = 1 ):

    counter =  0
    if( b == 1 ):
        print( "     The set of small non-units of Z_{%d}\\%dZ_{%d}, is given by the list below.\n" % ( m * n, m, m * n ) )
        for i in range( 1, m * n // 2 + 1 ):
            if( gcd( i, m * n ) > 1 and not i % m == 0 ):
                if( counter == 0 ):
                    print( "     { ", end = '' )
                    counter = 1
                else:
                    print( ", ", end = '' )
                print( "%d" % i, end = '' )
    else:
        a = m * n // b
        print( "     The set of small non-units of Z_{%d}\\%dZ_{%d}, rendered in Z_{%d} x Z_{%d}, is given by the list below.\n" % ( m * n, m, m * n, a, b ) )
        g = gcd( a, m )
        h = gcd( b, m )
        for i in range( 1, m // 2 + 1 ):
            for j in range( n ):
                if( not( i % g == 0 and j % h == 0 ) ):
                    if( gcd( i, m ) > 1 or gcd( j, m ) > 1 ):
                        if( counter == 0 ):
                            print( "     { ", end = '' )
                            counter = 1
                        else:
                            print( ", ", end = '' )
                        print( "(%d,%d)" % ( i, j ), end = '' )


    if( counter == 0 ):
        print( "     { }\n" )
    else:
        print( " }\n" )







# Function: print_base_paths
#
# Inputs: base paths S
#         integers m and n
#
# Output: This routine will print the 
#         base paths as created by other
#         routines. If n=1, then they will be
#         given with the vertex set Z_m, otherwise
#         it will use ordered pairs from Z_m x Z_n.


def print_base_paths( S, m, n, p ):

    myLen = len( S )
    counter = 0
    # print( )
    if( n == 1 ):
        for i in range( len( S ) ):
            if( p == 1 or len( S[i] ) > 2 ):
                print( "     Path %3d: " % counter + str(S[i]) )
                counter += 1
    else:
        for i in range( len( S ) ):
            if( p == 1 or len( S[i] ) > 2 ):
                print( "     Path %3d: " % counter + str(ordered_pair_path(S[i],m,n)) )
                counter += 1
    print( )

    counter = 0
    if( n == 1 ):
        for i in range( len( S ) ):
            if( p == 1 or len( S[i] ) > 2 ):
                print( "     Small Edge lengths - Path %3d: {" % counter, end='' )
                for j in range( len( S[i] ) - 2 ):
                    print( " %d," % min( ( S[i][j+1] - S[i][j] ) % m, ( S[i][j] - S[i][j+1] ) % m ), end='' )
                print( " %d }" % min( ( S[i][-1] - S[i][-2] ) % m, ( S[i][-2] - S[i][-1] ) % m ) )
                counter += 1
    else:
        for i in range( len( S ) ):
            if( p == 1 or len( S[i] ) > 2 ):
                print( "     Small Edge lengths - Path %3d: {" % counter, end='' )
                for j in range( len( S[i] ) - 1 ):
                    x_coord = ( S[i][j+1] - S[i][j] ) % m
                    y_coord = ( S[i][j+1] - S[i][j] ) % n
                    if( y_coord == 0 ):
                        print( " (%d,0)" % min( x_coord, ( m - x_coord ) % m ), end='' )
                    elif( x_coord < ( m - x_coord ) & m ):
                        print( " (%d,%d)" % ( x_coord, y_coord ), end='' )
                    else:
                        print( " (%d,%d)" % ( ( m - x_coord ) % m, ( m - y_coord ) % n ), end='' )
                    if( j == len( S[i] ) - 2 ):
                        print( " }" )
                    else:
                        print( ",", end='' )
                counter += 1
    print( )
    









