from .helpers import *
from .global_ import *
            
                








# Function: set_partition
#
# Inputs: prime integers p, r
#         nonnegative integer a
#         assumption that p > r^a
#
# Output: A partition of Z_{r^a} such that each part
#         has cardinality 1 or p, and for each part x
#         in the partition, the sum of all elements of 
#         x yields a unit of Z_{r^a}.

def set_partition( p, r, a ):

    parts = []

    # For simplicity, we define q as the prime power r^a

    q = r**a
    
    isUsed = [0] * q

    # The number of nonunits in Z_q is q/r = r^{a-1}.
    # One non-unit is 0, while the others may be paired 
    # with their additive inverse modulo q.
    
    # We group together (p-1)/2 of these pairs into Q 
    # sets with a remainder of R sets:

    num_non_units = q // r
    
    Q = ( ( num_non_units - 1 ) // 2 ) // ( ( p - 1 ) // 2 )

    R = ( ( num_non_units - 1 ) // 2 ) % ( ( p - 1 ) // 2 )

    # We include 0 in a partition with 1 and a unit x of 
    # Z_q which, when added to 1 is also a unit in Z_q.

    if( r == 3 ):
        x = 4
    else:
        x = 2
        
    if( Q == 0 ):

        # First, we create space for the partition
        # of size p in the partition.
        
        parts.append( [] )
        
        # In this case, all non-units will be grouped
        # in one set of size p.
       
        for i in range( num_non_units ):
            parts[0].append( i * r )
            isUsed[i*r] = 1
            
        # Next, we add pairs of additive inverses 
        # of units, as well as 1 to the part.
        
        parts[0].append( 1 )
        parts[0].append( x )
        isUsed[1] = 1
        isUsed[x] = 1
        
        i = 2
        counter = 0
        while counter < ( p - 2*R - 3 ) / 2: 
            i += 1
            if( not( i % r == 0 ) and not( i == x ) ):
                parts[0].append( i )
                parts[0].append( q - i )

                isUsed[i] = 1
                isUsed[q-i] = 1
                
                counter += 1
    
        # Now, we insert each remaining unit into
        # its own part.
        
        for j in range( q ):
            if isUsed[j] == 0:
                parts.append( [j] )
                
        

    else:
        
        # In this case, we first create Q+1 parts
        # in the partition
        
        for i in range( Q + 1 ):
            parts.append( [] )
        
        # Next, we place the nonunits in the first
        # Q parts (p-1)/2 at a time; the remaining
        # nonunits will be placed in the final part
        
        counter = 1
        for i in range( Q ):
            for j in range( ( p - 1 ) // 2 ):
                parts[i].append( counter * r )
                parts[i].append( q - counter * r )
                isUsed[counter*r] = 1
                isUsed[q - counter*r] = 1
                counter += 1
        
        while( counter <= ( num_non_units - 1 ) // 2 ):
            parts[Q].append( counter * r )
            parts[Q].append( q - counter * r )
            isUsed[counter*r] = 1
            isUsed[q - counter*r] = 1
            counter += 1

        # The final part will include 0, 1 and x
        
        parts[Q].append( 0 )
        parts[Q].append( 1 )
        parts[Q].append( x )
        isUsed[0] = 1
        isUsed[1] = 1
        isUsed[x] = 1
        
        # The final part will also include pairs 
        # of additive inverses of units in Z_q
        
        i = 1
        counter = 0
        while counter < ( p - 2*R - 3 ) // 2: 
            i += 1
            if( not( i % r == 0 ) and not( i == x ) ):
                parts[Q].append( i )
                parts[Q].append( q - i )
                isUsed[i] = 1
                isUsed[q-i] = 1
                counter += 1
            
        # last_used_unit = i    
            
        # At this point, the units between 
        # i and q-i, not inclusive, remain unused.
        # The first Q parts will have one unused
        # unit included, completing the part.
        
        counter = 0
        i = 0
        while counter < Q:
            if( isUsed[i] == 0 ):
                parts[counter].append( i )
                isUsed[i] = 1
                counter += 1
            i += 1
            
        for j in range( q ):
            if isUsed[j] == 0:
                parts.append( [j] )
                
        # for i in range(q):
            # if( isUsed[i] == 
        # while counter < Q:
            # i += 1
            # if( not( i % r == 0 ) and not( i == x ) ):
                # parts[counter].append( i )
                # counter += 1
        
        # The remaining unused units will be given
        # their own part.
        
        # i += 1
        # for j in range( i, q - last_used_unit + 1 ):
            # if( not( j % r == 0 ) and not( j == x ) ):
                # parts.append( [j] )
    
    return parts
            
                








# Function: combine_two_partitions
#
# Inputs: prime integer p
#         integers m and n
#         m, n, and p are pairwise coprime
#         M is a partition of Z_m
#         N is a partition of Z_n
#         each part in the partitions have 
#         cardinality 1 or p, each summing
#         to a unit in their respective ring
#
# Output: A partition of Z_{mn} such that each part
#         has cardinality 1 or p, and for each part x
#         in the partition, the sum of all elements of 
#         x yields a unit of Z_{mn}.

def combine_two_partitions( p, m, M, n, N ):
    
    new_parts = []
    
    mn = m * n
    
    for P in M:
        for Q in N:

            if( len( P ) == p and len( Q ) == p ):

                for i in range( p ):

                    new_part = []
                    for j in range( p ):
                        new_part.append( ( P[j], Q[(i+j)%p] ) )
                    new_parts.append( combined_base_path( new_part, m, n ) )
            
            elif( len( P ) == 1 and len( Q ) == p ):

                new_part = []
                for j in range( p ):
                    new_part.append( ( P[0], Q[j] ) )
                new_parts.append( combined_base_path( new_part, m, n ) )

            elif( len( P ) == p and len( Q ) == 1 ):

                new_part = []
                for j in range( p ):
                    new_part.append( ( P[j], Q[0] ) )
                new_parts.append( combined_base_path( new_part, m, n ) )

            else:

                new_parts.append( combined_base_path( [ ( P[0], Q[0] ) ], m, n ) )

    return new_parts
            
                








# Function: set_partition_general
#
# Inputs: prime integer p
#         integer n whose prime divisors are 
#         each larger than p
#
# Output: A partition of Z_{n} such that each part
#         has cardinality 1 or p, and for each part x
#         in the partition, the sum of all elements of 
#         x yields a unit of Z_{n}.

def set_partition_general( p, n ):

    P = prime_factorization( n )
    
    primes = []
    exponents = []
    current_modulus = 1
    
    for i in range( len( P ) ):
        primes.append( smallest_factor( P[i] ) )
        exponents.append( largest_prime_power( P[i], primes[i] ) )
        
    combined_parts = set_partition( p, primes[0], exponents[0] )
    current_modulus = P[0]
    
    for i in range( 1, len( P ) ):
        combined_parts = combine_two_partitions( p, current_modulus, combined_parts, P[i], set_partition( p, primes[i], exponents[i] ) )
        current_modulus *= P[i]
    
    return combined_parts
    


