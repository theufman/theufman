from .global_ import *
from .helpers import *
            
                








# Function: first_base_path_of_km
#
# Inputs: prime power q
#         integer r which is coprime to q
#
# Output: This routine builds the base path
#         outlined in Lemma 2.1 of Buratti's
#         paper, which is used at the outset
#         of the proof of Theorem 1.1 in 
#         Section 3.

def first_base_path_of_km( q, r ):

    if( q == 3 ):
        new_path = [ (0,0), (1,0), (2,1) ]
        P = prime_factorization( r )
        P.sort()
        p = smallest_factor( P[-1] )
        # if( p == 1 ):
            # p = P[-1]
        if( len( P ) == 1 ):
            if( verbose == 1 ):
                print( "p = " + str(p) )
            if( P[-1] % 4 == 3 ):
            # if( p % 4 == 3 ):
                new_path.append( (0, r - 1 ) )
            else:
                new_path.append( (0, 3 ) )
        else:
            last_vertex = [2] * ( len( P ) - 1 )

            if( p % 4 == 3 ):
                last_vertex.append( P[-1] - 1 )
            else:
                last_vertex.append( 3 )

            new_path.append( (0, combined_tuple( tuple( last_vertex ), P ) ) )
        return new_path

    p = smallest_factor( q )
    a = largest_prime_power( q, p )
    
    new_path = []

    for h in range( (q+1) // 2 ):
        if( h % 2 == 0 ):
            new_path.append( ( h // 2, 0 ) )
        else: 
            new_path.append( ( q - (h+1) // 2, 0 ) )
    
    if( p % 4 == 1 ):
        for h in range( (q+1) // 2, q ):
            if( h % 2 == 0 ):
                new_path.append( ( h // 2, 0 ) )
            elif( (h + p) % (2*p) == 0 ):
                new_path.append( ( q - ( h + p ) // 2, 1 ) )
            else:
                if( ( h // p ) % 2 == 0 ):
                    new_path.append( ( q - ( h + 1 ) // 2, r - 1 ) )
                else: 
                    new_path.append( ( q - ( h - 1 ) // 2, r - 1 ) )
        new_path.append( ( 0, r - 1 ) )

    elif( p % 4 == 3 and a % 2 == 1 ):
        for h in range( (q+1) // 2, q - 2 ):
            if( h % 2 == 0 ):
                new_path.append( ( h // 2, 1 ) )
            elif( (h + p) % (2*p) == 0 ):
                new_path.append( ( q - ( h + p ) // 2, 2 ) )
            else: 
                if( ( h // p ) % 2 == 0 ):
                    new_path.append( ( q - ( h + 1 ) // 2, 0 ) )
                else: 
                    new_path.append( ( q - ( h - 1 ) // 2, 0 ) )
        new_path.append( ( ( 1 + q ) // 2, 2 ) )
        new_path.append( ( ( q - 1 ) // 2, 3 ) )
        new_path.append( ( 0, 2 ) )
    
    else:
        for h in range( (q+1) // 2, q - 2 ):
            if( h % 2 == 1 ):
                new_path.append( ( q - ( h + 1 ) // 2, 1 ) )
            elif( (h + p + 1) % (2*p) == 0 ):
                new_path.append( ( ( h + 1 - p ) // 2, 2 ) )
            else:
                if( ( h // p ) % 2 == 0 ):
                    new_path.append( ( 1 + h // 2, 0 ) )
                else:
                    new_path.append( ( h // 2, 0 ) )
        new_path.append( ( ( q - p ) // 2, 1 ) )
        new_path.append( ( ( q + 1 ) // 2, 0 ) )
        new_path.append( ( 0, r-1 ) )
        
    return new_path
            
                








# Function: base_paths_of_km
#
# Inputs: odd integer m, m != 15, 
#         m not a composite prime power
#
# Output: This routine uses the construction
#         outlined in the proof of Theorem 1.1
#         in Buratti's paper to construct a 
#         sufficient set of base paths for K_m

def base_paths_of_km( m ):
    
    P = prime_factorization( m )
    P.sort()
    
    n = len( P )

    base_paths = []
    
    if( n == 1 ):
        # for i in range( 1, ( m - 1 ) // 2 ):
            # base_paths.append( [ 0, i ] )
        return base_paths
    
    for i in range( n ):
        base_paths.append( combined_base_path( first_base_path_of_km( P[i], m // P[i] ), P[i], m // P[i] ) )
        
    if( verbose == 1 ): 
        print( base_paths )
        print( ordered_tuple_paths( base_paths , P ) )
    
    if( n == 2 ):
        if( verbose == 1 ): print( "Only two prime powers in the factorization." )
        used_differences = [0] * (m)
        for j in range( 2 ):
            for i in range( len( base_paths[j] ) - 1 ):
                used_differences[ ( base_paths[j][i] - base_paths[j][i+1] ) % m ] += 1
                used_differences[ ( base_paths[j][i+1] - base_paths[j][i] ) % m ] += 1

        double_edge = 0
        if( verbose == 1 ): print( used_differences )
        for i in range( m - 1 ):
            if( used_differences[i] > 1 ):
                double_edge = 1

        if( double_edge == 1 ):
            if( verbose == 1 ): print( "Needed to negate." )
            coord_path = ordered_pair_path( base_paths[1], P[1], P[0] )
            negated_path = []
            for i in range( len( coord_path ) ):
                # negated_path.append( ( P[1] - coord_path[i][0], coord_path[i][1] ) )
                negated_path.append( ( coord_path[i][0], P[0] - coord_path[i][1] ) )
            base_paths[1] = combined_base_path( negated_path, P[1], m // P[1] )



        for z in range( 1, ( P[1] + 1 ) // 2 ):
            if( gcd( z, P[1] ) > 1 ):
                base_path = [(0,0)]
                p = smallest_factor( P[0] )
                # if( p == 1 ): 
                    # p = P[0]
                for h in range( 1, P[0] ):
                    if( h % 2 == 0 ):
                        base_path.append( ( P[0] - h // 2, 0 ) )
                    elif( ( h + p ) % (2*p) == 0 ):
                        base_path.append( ( ( h + p ) // 2, z + 1 ) )
                    else: 
                        if( ( h // p ) % 2 == 0 ):
                            base_path.append( ( ( h + 1 ) // 2, z ) )
                        else:
                            base_path.append( ( ( h - 1 ) // 2, z ) )
                base_path.append( ( 0, z - 1 ) )
                combined_path = combined_tuple_path( base_path, P )
                base_paths.append( combined_path )

    else:
        for u in range( m // (P[-2] * P[-1]) ):
            for z in range( 1, ( P[-1] + 1 ) // 2 ):
                if( gcd( u, m // (P[-2] * P[-1]) ) == 1 ):
                    if( gcd( z, P[-1] ) > 1 ):
                        # print( "u = " + str(u) + "; z = " + str(z) ) 
                        base_path = [(0,0,0)]
                        p = smallest_factor( P[-2] )
                        # if( p == 1 ): 
                            # p = P[-2]
                        for h in range( 1, P[-2] ):
                            # print( base_path )
                            # print( h, p, ( h + p ) % (2*p) )
                            if( h % 2 == 0 ):
                                # print( "1111" )
                                base_path.append( ( 0, P[-2] - h // 2, 0 ) )
                            elif( ( h + p ) % (2*p) == 0 ):
                                # print( "2222 " + str(z) )
                                base_path.append( ( u, ( h + p ) // 2, z + 1 ) )
                            else: 
                                if( ( h // p ) % 2 == 0 ):
                                    # print( "3333" )
                                    base_path.append( ( u, ( h + 1 ) // 2, z ) )
                                else:
                                    # print( "4444" )
                                    base_path.append( ( u, ( h - 1 ) // 2, z ) )
                        base_path.append( ( u, 0, z - 1 ) )
                        # print( "Combined path: " + str( base_path ) )
                        combined_path = combined_tuple_path( base_path, [m // (P[-2] * P[-1]), P[-2], P[-1] ] )
                        # print( "Combined path: " + str( combined_path ) )
                        base_paths.append( combined_path )

    used_differences = [0] * m
    
    for i in range( len( base_paths ) ):
        for j in range( 1, len( base_paths[i] ) ):
            used_differences[ ( base_paths[i][j] - base_paths[i][j-1] ) % m ] += 1
            used_differences[ ( base_paths[i][j-1] - base_paths[i][j] ) % m ] += 1
    
    # print( used_differences )
    
    unused_units = []
    for i in range( ( m + 1 ) // 2 ):
        if( gcd( i, m ) == 1 and used_differences[i] == 0 ):
            unused_units.append( i )
    
    # print( unused_units )
    
    U = [ [] for i in range( n + 1 ) ]
    X = [ [] for i in range( n + 1 ) ]
    
    Q = [1]
    for i in range( n ):
        Q.append( P[i] * Q[i] )
    # print( "P = " + str(P) )
    # print( "Q = " + str(Q) )
        
    for i in range( 2, n ):
       for j in range( 1, (Q[i-1] + 1) // 2 ):
            X[i].append( j )
            U[i].append( unused_units.pop() )
    # print( "U = " + str(U) )
    # print( "X = " + str(X) )

    if( verbose == 1 ):
        print( "Q[n-1] = " + str(Q[n-1]) )

    for i in range( 1, (Q[n-1]+1) // 2 ):
        if( gcd( i, Q[n-1] ) > 1 ):
            X[n].append( i )
            U[n].append( unused_units.pop() )
        
    if( verbose == 1 ):
        print( "U = " + str(U) )
        print( "X = " + str(X) )
        for i in range( len( U ) ):
            print( U[i] )
            
        for i in range( len( U ) ):
            print( X[i] )
            
        print( "Unused units: "+  str(unused_units ) )
    
    for i in range( 2, n ):
        for j in range( len( U[i] ) ):
            # print( i, j )
            r = U[i][j] % Q[i-1]
            s = U[i][j] % P[i-1]
            t = U[i][j] % ( m // Q[i] )
            
            base_path = [(0,0,0)]
            
            for k in range( 1, ( P[i-1] + 1) // 2 ):
                base_path.append( ( X[i][j], (2 * k * s) % P[i-1], 0 ) )
                base_path.append( ( 0, (-2 * k * s) % P[i-1], 0 ) )
            base_path.append( ( Q[i-1] - r, 0, ( m // Q[i] ) - t ) )
            # print( "Base path: " + str(base_path) )
            base_paths.append( combined_tuple_path( base_path, [ Q[i-1], P[i-1], ( m // Q[i] ) ] ) )
        
    for j in range( len( U[n] ) ):
        r = U[n][j] % Q[n-1]
        s = U[n][j] % P[n-1]
    
        base_path = [(0,0)]
    
        for k in range( 1, ( P[n-1] + 1) // 2 ):
            base_path.append( ( X[n][j], (2 * k * s) % P[n-1] ) )
            base_path.append( ( 0, (-2 * k * s) % P[n-1] ) )
        base_path.append( ( Q[n-1] - r, 0 ) )
        # print( "base path: " + str(base_path) )
        base_paths.append( combined_tuple_path( base_path, [ Q[n-1], P[n-1] ] ) )
    
    return base_paths
    

