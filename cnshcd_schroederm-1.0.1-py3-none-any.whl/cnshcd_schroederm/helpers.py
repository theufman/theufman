import math
    









# Function: gcd
#
# Inputs: integers a, b
#
# Output: the GCD of a and b, computed recursively

def gcd( a , b ):
    if( a % b == 0 ):
        return b
    else:
        return gcd( b, a % b )
    









# Function: egcd
#
# Inputs: integers a, b
#
# Output: the GCD of a and b and multipliers d and e 
#         so that a*d + b*e = GCD(a,b), computed recursively

def egcd( a , b ):
    if( a == 0 ):
        return b, 0, 1
    else:
        b_div_a, b_mod_a = divmod( b, a )
        g, x, y = egcd( b_mod_a, a )
        return g, y-b_div_a * x, x 
    









# Function: lcm
#
# Inputs: integers a, b
#
# Output: the LCM of a and b, using the GCD

def lcm( a , b ):
    return ( a // gcd( a, b ) ) * b
    









# Function: inverse
#
# Inputs: integers x and a
#
# Output: assuming that x and a are relatively prime,
#         this computes the integer y such that 
#         0 <= y < a and xy = 1 modulo a.

def inverse( x, a ):
    
    _, e, _ = egcd( x, a )
    
    return e % a
    









# Function: ordered_pair
#
# Inputs: integers x, a, b
#
# Output: the ordered pair with x reduced
#         modulo a and b. In practice, it 
#         is expected that a and b are 
#         relatively prime.

def ordered_pair( x, a, b ):
    return ( x % a, x % b )
    









# Function: ordered_pair_path
#
# Inputs: integers x[], a, b
#
# Output: the ordered pairs with elements
#         of x reduced modulo a and b. 

def ordered_pair_path( x, a, b ):
    new_path = []
    for i in range( len( x ) ):
        new_path.append( ordered_pair( x[i], a, b ) )
    return new_path
    









# Function: ordered_pair_paths
#
# Inputs: integers x[][], a, b
#
# Output: the ordered pair with elements
#         of x reduced modulo a and b. 

def ordered_pair_paths( S, a, b ):
    new_paths = []
    for x in range( len( S ) ):
        new_paths.append( ordered_pair_path( S[x], a, b ) )
    return new_paths
    









# Function: ordered_tuple
#
# Inputs: integers x, a[]
#
# Output: the ordered pair with x reduced
#         modulo a[]. In practice, it 
#         is expected that a[] are relatively prime.

def ordered_tuple( x, a ):
    my_tuple = []
    for i in range( len( a ) ):
        my_tuple.append( x % a[i] )
    return tuple( my_tuple )
    









# Function: ordered_tuple_path
#
# Inputs: integers x[], a, b
#
# Output: the ordered pairs with elements
#         of x reduced modulo a and b. 

def ordered_tuple_path( x, a ):
    new_path = []
    for i in range( len( x ) ):
        new_path.append( ordered_tuple( x[i], a ) )
    return new_path
    









# Function: ordered_tuple_paths
#
# Inputs: integers x[][], a, b
#
# Output: the ordered pair with elements
#         of x reduced modulo a and b. 

def ordered_tuple_paths( S, a ):
    new_paths = []
    for x in range( len( S ) ):
        new_paths.append( ordered_tuple_path( S[x], a ) )
    return new_paths
    









# Function: combined_int
#
# Inputs: integers x[2], a, b
#
# Output: Finds the integer y such that
#         0 <= y < ab, 
#         y = x[0] mod a, and 
#         y = x[1] mod b.

def combined_int( x, a, b ):
    ainv = inverse( a, b )
    binv = inverse( b, a )
    return (a*ainv*x[1] + b*binv*x[0]) % (a*b)
    









# Function: combined_base_path
#
# Inputs: integers x[][2], a, b
#
# Output: Finds the integers y[] such that
#         0 <= y[i] < ab, 
#         y[i] = x[i][0] mod a, and 
#         y[i] = x[i][1] mod b.

# def combined_base_path( x, a, b ):
    # new_path = []
    # for i in range( len( x ) ):
        # new_path.append( combined_int( x[i], a, b ) )
    # return new_path

def combined_base_path( x, a, b ):
    new_path = []
    ainv = inverse( a, b )
    binv = inverse( b, a )
    for i in range( len( x ) ):
        new_path.append( (a*ainv*x[i][1] + b*binv*x[i][0]) % (a*b) )
    return new_path
    









# Function: combined_base_paths
#
# Inputs: integers x[][][2], a, b
#
# Output: Finds the integers y[][] such that
#         0 <= y[i][j] < ab, 
#         y[i][j] = x[i][j][0] mod a, and 
#         y[i][j] = x[i][j][1] mod b.

def combined_base_paths( x, a, b ):
    new_paths = []
    for i in range( len( x ) ):
        new_paths.append( combined_base_path( x[i], a, b ) )
    return new_paths
    









# Function: combined_tuple
#
# Inputs: integers x[n], a[n]
#
# Output: Finds the integer y such that
#         0 <= y < a[0]*a[1]*...*a[n-1], 
#         y = x[i] mod a[i] for each i.

def combined_tuple( x, a ):
    if( len( a ) == 2 ):
        return combined_int( x, a[0], a[1] )
    
    y = combined_int( [ x[-2], x[-1] ], a[-2], a[-1] )
    new_mod = a[-2]*a[-1]
    
    z = []
    b = []
    for i in range( len( x ) - 2 ):
        z.append( x[i] )
        b.append( a[i] )
    
    z.append( y )
    b.append( new_mod )
    return combined_tuple( z, b )
    









# Function: combined_tuple_path
#
# Inputs: integers x[][n], a[n]
#
# Output: Finds the integers y[] such that
#         0 <= y[] < a[0]*a[1]*...*a[n-1], 
#         y[] = x[][i] mod a[i] for each i.

def combined_tuple_path( x, a ):
    new_path = []
    for i in range( len( x ) ):
        new_path.append( combined_tuple( x[i], a ) )
    return new_path
    









# Function: combined_tuple_paths
#
# Inputs: integers x[][][n], a[n]
#
# Output: Finds the integers y[] such that
#         0 <= y[] < a[0]*a[1]*...*a[n-1], 
#         y[] = x[][i] mod a[i] for each i.

def combined_tuple_paths( x, a ):
    new_paths = []
    for i in range( len( x ) ):
        new_paths.append( combined_tuple_path( x[i], a ) )
    return new_paths
    









# Function: largest_prime_power
#
# Inputs: integers m, p
#
# Output: This routine finds the largest exponent
#         a such that p^a divides m but p^{a+1} does not.

def largest_prime_power( m, p ):

    if( m % p == 0 ):
        return 1 + largest_prime_power( m // p, p )
    else:
        return 0
    









# Function: smallest_factor
#
# Inputs: integer n
#
# Output: This routine finds the largest exponent
#         a such that p^a divides m but p^{a+1} does not.

def smallest_factor( n ):
    for i in range( 2, 1 + int( math.sqrt( n ) ) ):
        if( n % i == 0 ):
            return i
    return n
    









# Function: largest_prime_power
#
# Inputs: integers m, p
#
# Output: This routine finds the largest exponent
#         a such that p^a divides m but p^{a+1} does not.

def prime_factorization( n ):
    if( n == 1 ):
        return []

    p = smallest_factor( n )
    # if( p == 1 ):
        # return [ n ]

    a = largest_prime_power( n, p )
    
    P = prime_factorization( n // (p**a) )
    
    P.insert(0, p**a )
    
    return P
    









# Function: add_unit_base_paths
#
# Inputs: base paths S in K_{mxn}
#         (assumes all non-unit edge lengths used)
#         integers m, n
#
# Output: This routine determines the unit edge lengths
#         which are not used by the paths in S, then
#         adds base paths of length 1 to S so as to 
#         produce a set of valid base paths for K_{m x n}
#         which uses every edge length.

def add_unit_base_paths( S, m ):

    new_unit_paths = S
    
    used_differences = [0] * m
    
    for i in range( len( S ) ):
        for j in range( 1, len( S[i] ) ):
            used_differences[ ( S[i][j] - S[i][j-1] ) % (m) ] += 1
            used_differences[ ( S[i][j-1] - S[i][j] ) % (m) ] += 1

    for i in range( (m+1) // 2 ):
        if( gcd( i, m ) == 1 and used_differences[i] == 0 ):
            new_unit_paths.append( [ 0, i ] )
            
    return new_unit_paths
    









# Function: phi
#
# Input:  a positive integer n
#
# Output: the Euler totient function of n

def phi( n ):
    if( n == 1 ):
        return 1
    p = smallest_factor( n )
    a = largest_prime_power( n, p )
    return p**(a-1) * ( p - 1 ) * phi( n // (p**a) )
    









# Function: psi
#
# Input:  a positive integer m, at least 3
#         m != 15, m not a composite prime power
#
# Output: the number of units needed in Z_m to 
#         produce a cyclic HCD of K_m, as defined
#         in Buratti's paper

def psi( m ):
    temp = prime_factorization( m )
    k = len( temp )
    
    if( k == 1 and m == smallest_factor( m ) ): 
        return 0;

    q = [1]
    for x in temp:
        q.append( x )
    p = [ smallest_factor( r ) for r in q ]
    Q = [1]
    for i in range( 1, len( q ) ):
        Q.append( Q[i-1] * q[i] )
        
    sum = 1
    for i in range( 1, k + 1 ):
        sum += q[i]
    
    for i in range( 1, k ):
        sum += Q[i]
        
    sum += phi( Q[k-2] ) * ( q[k-1] // p[k-1] ) * ( ( q[k] // p[k] ) - 1 ) - phi( Q[k-1] )
    
    return sum
