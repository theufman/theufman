# python part_create_another.py

from .helpers import *
from .set_partition import *
from .checkers import *
from .km_builder import *
from .global_ import *
from .k15_builder import *
from .combine_paths_and_parts import *
from .k_mxn_small import *
from .pn_builder import *
from .km2_builder import *







# Function: cnshcd_builder
#
# Inputs: positive integers m and n
#         level of verbosity (defaulted to true)
#
# Output: a cyclic, n-symmetric HCD of K_{mxn}, if
#         the necessary numerical conditions are met.

def cnshcd_builder( m, n, vb = True ):
    M = prime_factorization( m )
    N = prime_factorization( n )
    list_of_primes_for_m = []
    list_of_primes_for_n = []
    p = smallest_factor( m )

    if( vb ): print() 
    
    for q in M:
        list_of_primes_for_m.append( smallest_factor( q ) )
    for q in N:
        list_of_primes_for_n.append( smallest_factor( q ) )

    if( m % 4 == 3 and n % 4 == 2 ):
        if( vb ): print( "m and n do not satisfy the congruence conditions." )
        return []
        
    if( m == 15 and n == 1 ):
        if( vb ): print( "K_15 = K_{15x1} does not have a cyclic HCD." )
        return []
    
    if( len( M ) == 1 and M[0] != list_of_primes_for_m[0] and n == 1 ):
        if( vb ): print( "K_q = K_{q x 1} does not have a cyclic HCD for a composite prime power q." )
        return []
        
    if( len( M ) == 1 and n == 2 ):
        if( vb ): print( "K_{q x 2} does not have a cyclic HCD for a prime power q." )
        return []
        
    if( n == 1 ):
        if( vb ): print( "The Buratti construction provides a cyclic decomposition for K_{%d}." % m )
        return base_paths_of_km( m )
        
    if( n == 2 ):
        if( vb ): print( "The Jordon-Morris construction provides a cyclic decomposition for K_{%dx2}." % m )
        return build_km2( m )
        
    if( vb ): print( "The necessary conditions are met for the existence of such a decomposition." )
    
    common_primes = []
    common_prime_powers = []
    common_prime_exponents = []
    
    A = 1
    B = 1
    
    
    for i in range( len( N ) ):
        if( list_of_primes_for_n[i] in list_of_primes_for_m ):
            common_primes.append( list_of_primes_for_n[i] )
            common_prime_powers.append( N[i] )
            common_prime_exponents.append( largest_prime_power( n, list_of_primes_for_n[i] ) )
        
        elif( list_of_primes_for_n[i] < p ):
            A *= N[i]
        else:
            B *= N[i]

    if( vb ): print()
    if( vb ): print( "Smallest prime of m: " + str(p) )
    if( vb ): print()
    if( vb ): print( "The factorization of n: " )
    if( vb ): print( "   A = " + str(A) )
    if( vb ): print( "   B = " + str(B) )
    
    if( len( common_primes ) == 0 ):
        if( vb ): print( "   There are no common primes." )
    for i in range( len( common_primes ) ):
        if( vb ): print( "   Common prime power: %2d^%d" % ( common_primes[i], common_prime_exponents[i] ) )

        
    if( m != 15 and not( len( M ) == 1 and M[0] != p ) and ( not( m == p ) or n % 4 != 2 ) ):
        S = build_initial_base_paths( m, A )
        S = add_unit_base_paths( S, m*A )
        S = combine_paths_and_partition( S, m*A, p, B )
        current_modulus = A * B
        for i in range( len( common_prime_powers ) ):
            S = combine_paths_with_prime_divisors( S, m, current_modulus, common_primes[i], common_prime_exponents[i] )
            current_modulus *= common_prime_powers[i]
        
    elif( m == 15 ):
        if( A > 1 ):
            S = build_k_fifteen_by_power_of_two( largest_prime_power( A, 2 ) )
            S = add_unit_base_paths( S, m*A )
            S = combine_paths_and_partition( S, m*A, p, B )
            current_modulus = A * B
            for i in range( len( common_prime_powers ) ):
                S = combine_paths_with_prime_divisors( S, m, current_modulus, common_primes[i], common_prime_exponents[i] )
                current_modulus *= common_prime_powers[i]
        elif( B > 1 ):
            r = smallest_factor( B )
            exp = largest_prime_power( B, r )
            C = B // ( r ** exp )
            S = build_k_fifteen_by_power_of_other_prime_power( r ** exp )
            S = add_unit_base_paths( S, m * r ** exp )
            S = combine_paths_and_partition( S, m*A*r**exp, p, C )
            current_modulus = A * B
            for i in range( len( common_prime_powers ) ):
                S = combine_paths_with_prime_divisors( S, m, current_modulus, common_primes[i], common_prime_exponents[i] )
                current_modulus *= common_prime_powers[i]
        elif( common_primes[0] == 3 ):
            S = build_k_fifteen_by_power_of_three( common_prime_exponents[0] )
            if( len( common_primes ) > 1 ):
                S = combine_paths_with_prime_divisors( S, m, common_prime_powers[0], common_primes[1], common_prime_exponents[1] )
        else: 
            S = build_k_fifteen_by_power_of_five( common_prime_exponents[0] )
    
    elif( len( M ) == 1 and n % 4 == 2 ):
        mexp = largest_prime_power( m, p )
        if( A >= 3 ):
            if( m == p ):
                S = build_initial_base_paths( m, A )
            else:
                S = new_build_pa_by_n( p, mexp, A )
            S = add_unit_base_paths( S, m * A )
            S = combine_paths_and_partition( S, m*A, p, B )
            if( len( common_primes ) > 0 ):
                S = combine_paths_with_prime_divisors( S, m, A * B, p, common_prime_exponents[0] )
        elif( A == 2 and B > 1 ):
            r = smallest_factor( B )
            exp = largest_prime_power( B, r )
            C = B // ( r ** exp )
            if( m == p ):
                S = build_initial_base_paths( m, A * r ** exp )
            else:
                S = new_build_pa_by_n( p, mexp, A * r ** exp )
            S = add_unit_base_paths( S, m * A * r ** exp )
            S = combine_paths_and_partition( S, m * A * r ** exp, p, C )
            if( len( common_primes ) > 0 ):
                    S = combine_paths_with_prime_divisors( S, m, A * B, p, common_prime_exponents[0] )
        else:
            S = build_pa_by_2pb( p, mexp, common_prime_exponents[0] )
            
    else:
        mexp = largest_prime_power( m, p )
        if( A >= 3 ):
            S = new_build_pa_by_n( p, mexp, A )
            S = add_unit_base_paths( S, m * A )
            S = combine_paths_and_partition( S, m*A, p, B )
            if( len( common_primes ) > 0 ):
                S = combine_paths_with_prime_divisors( S, m, A * B, p, common_prime_exponents[0] )
        elif( A == 1 and B > 1 ):
            r = smallest_factor( B )
            exp = largest_prime_power( B, r )
            C = B // ( r ** exp )
            S = new_build_pa_by_n( p, mexp, A * r ** exp )
            S = add_unit_base_paths( S, m * A * r ** exp )
            S = combine_paths_and_partition( S, m * A * r ** exp, p, C )
            if( len( common_primes ) > 0 ):
                    S = combine_paths_with_prime_divisors( S, m, A * B, p, common_prime_exponents[0] )
        else:
            S = improved_build_pa_by_pb( p, mexp, common_prime_exponents[0] )
            
    return S
            
                








# Function: interface
#
# Inputs: none
#
# Output: an interactive program for soliciting
#         cyclic, symmetric HCDs for balanced 
#         complete multipartite graphs.

def interface():

    while True:

        print()
        print( "With this program, you may produce a cyclic, symmetric HCD of K_{m x n} for a particular m and n." )

        print()
        m = input( "Enter the value of m: " )
        n = input( "Enter the value of n: " )

        if( m == '' or n == '' ):
            print()
            return
            
        m = int( m )
        n = int( n )
        
        if( m % 2 == 0 ):
            print()
            print( "This program only builds decompositions when m is odd." )
        else:
            S = cnshcd_builder( m, n )
            check_base_paths( S, m, n )
            print()
            question = input( "Print the base paths -- complete, sufficient, or neither (c/s/n): " )
            print()

            if( question == 'c' ):
                question = input( "Would you like vertices printed as ordered pairs (y/n): ")
                if( question == 'y' ):
                    print()
                    first  = int( input( "First  ordinate modulus: " ) )
                    second = int( input( "Second ordinate modulus: " ) )
                    print( "Complete set of base paths for K_{%d x %d}: " % ( m, n ) )
                    print()
                    for i in range( len( S ) ):
                        print( "    Path %3d: " % i + str(ordered_pair_path(S[i],first, second)) )
                else:
                    print()
                    print( "Complete set of base paths for K_{%d x %d}: " % ( m, n ) )
                    print()
                    for i in range( len( S ) ):
                        print( "    Path %3d: " % i + str(S[i]) )
            elif( question == 's' ):
                question = input( "Would you like vertices printed as ordered pairs (y/n): ")
                if( question == 'y' ):
                    print()
                    first  = int( input( "First  ordinate modulus: " ) )
                    second = int( input( "Second ordinate modulus: " ) )
                    print( "Sufficient set of base paths for K_{%d x %d}: " % ( m, n ) )
                    print()
                    counter = 0
                    for i in range( len( S ) ):
                        if( len( S[i] ) > 2 ):
                            print( "    Path %3d: " % counter + str(ordered_pair_path(S[i],first, second)) )
                            counter += 1
                else:
                    print()
                    print( "Sufficient set of base paths for K_{%d x %d}: " % ( m, n ) )
                    print()
                    counter = 0
                    for i in range( len( S ) ):
                        if( len( S[i] ) > 2 ):
                            print( "    Path %3d (%3d): " % ( counter, i ) + str(S[i]) )
                            counter += 1
                
                displayDiffChart = True
                while( displayDiffChart ):
                    print()
                    question = input( "For which path would you like to see the edge length chart? " )
                    if( question == "" ):
                        displayDiffChart = False
                    else:
                        print()
                        check_diff_grid( [S[min(len(S)-1,int(question))]], m, n )
            
#Function Entrypoint
def entrypoint( m, n, question ):

   # while True:

        print()
        print( "With this program, you may produce a cyclic, symmetric HCD of K_{m x n} for a particular m and n." )

        print()
       # m = input( "Enter the value of m: " )
       # n = input( "Enter the value of n: " )

        if( m == '' or n == '' ):
            print()
            return
            
        m = int( m )
        n = int( n )
        
        if( m % 2 == 0 ):
            print()
            print( "This program only builds decompositions when m is odd." )
        else:
            S = cnshcd_builder( m, n )
            check_base_paths( S, m, n )
            print()
            # question = input( "Print the base paths -- complete, sufficient, or neither (c/s/n): " )
            print()

            if( question == 'c' ):
                question='n'
                # question = input( "Would you like vertices printed as ordered pairs (y/n): ")
                if( question == 'y' ):
                    print()
                    first  = int( input( "First  ordinate modulus: " ) )
                    second = int( input( "Second ordinate modulus: " ) )
                    print( "Complete set of base paths for K_{%d x %d}: " % ( m, n ) )
                    print()
                    for i in range( len( S ) ):
                        print( "    Path %3d: " % i + str(ordered_pair_path(S[i],first, second)) )
                else:
                    print()
                    print( "Complete set of base paths for K_{%d x %d}: " % ( m, n ) )
                    print()
                    for i in range( len( S ) ):
                        print( "    Path %3d: " % i + str(S[i]) )
            elif( question == 's' ):
                question='n'
                # question = input( "Would you like vertices printed as ordered pairs (y/n): ")
                if( question == 'y' ):
                    print()
                    first  = int( input( "First  ordinate modulus: " ) )
                    second = int( input( "Second ordinate modulus: " ) )
                    print( "Sufficient set of base paths for K_{%d x %d}: " % ( m, n ) )
                    print()
                    counter = 0
                    for i in range( len( S ) ):
                        if( len( S[i] ) > 2 ):
                            print( "    Path %3d: " % counter + str(ordered_pair_path(S[i],first, second)) )
                            counter += 1
                else:
                    print()
                    print( "Sufficient set of base paths for K_{%d x %d}: " % ( m, n ) )
                    print()
                    counter = 0
                    for i in range( len( S ) ):
                        if( len( S[i] ) > 2 ):
                            print( "    Path %3d (%3d): " % ( counter, i ) + str(S[i]) )
                            counter += 1

                print("For which path would you like to see the edge length chart?")


def displayChart(m, n, answer, S):
                #displayDiffChart=True
                #while( displayDiffChart ):
                    question=answer
                    print("Displaying edge length for Path["+question+"]:")
                    m=int(m)
                    n=int(n)
                    #question = input( "For which path would you like to see the edge length chart? " )
                 #   if( question == "" ):
                  #      displayDiffChart = False
                   # else:
                    #    print()
                    check_diff_grid( [S[min(len(S)-1,int(question))]], m, n )

# This line executes the interface.
#interface( )           

# m=7
# n=19

# S = cnshcd_builder( m, n )
# check_base_paths( S, m, n )

# for s in S:
    # print( s )

# check_diff_grid( S, m, n )

# m = 49
# n = 49*2

# S = cnshcd_builder( m, n )

# for s in S:
    # print( s )
    
# check_diffs( [S[-1]], m, n )
