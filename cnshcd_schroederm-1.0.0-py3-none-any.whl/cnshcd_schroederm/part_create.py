from .helpers import *
from .set_partition import *






# Function: check_diff_grid
#
# Inputs: base paths S
#         integers m and n
#
# Output: This routine will build a grid to 
#         check the edge lengths which are 
#         used by the set of base paths in S.
#         These base paths are assumed to
#         belong in K_{m x n}.

def check_diff_grid( S, m, n ):
        
    checkArray = [[0 for x in range(n)] for y in range(m)]
    for i in range( len( S ) ):
        for j in range( 1, len( S[i] ) ):
            checkArray[(S[i][j]-S[i][j-1])%m][(S[i][j]-S[i][j-1])%n] += 1
            checkArray[(S[i][j-1]-S[i][j])%m][(S[i][j-1]-S[i][j])%n] += 1
            
    for i in range(m):
        for j in range(n):
            if( checkArray[i][j] == 1 ):
                print( "1", end='')
            elif( checkArray[i][j] > 1 ):
                print( "#", end='')
            else:
                print(".", end='')
        print()







# Function: check_base_paths
#
# Inputs: base paths S
#         integers m and n
#
# Output: This routine will determine if 
#         a set of paths are, in fact, 
#         base paths, whether the set of 
#         base paths is valid (no overlapping
#         edge lengths), and if every nonunit
#         edge length present in K_{m x n} is 
#         accounted for in some base path in S.

def check_base_paths( S, m, n ):

    # First, check to see that each path is a base path
    mn = m*n
    usedDifferences = [0] * (mn)
    areAllBasePaths = 1
    
    for i in range( len( S ) ):
        d = len( S[i] ) - 1
        
        # To determine if S[i] is a base path, first
        # check the residue of each vertex modulo d
        # to see if they are each distinct.

        checkedModuli = [0] * d
        for j in range( 1, d + 1 ):
            checkedModuli[S[i][j] % d] += 1
        correctModuli = 1
        
        if( verbose == 1 ):
            print( checkedModuli )
        for j in range( d ):
            if( checkedModuli[j] == 0 ):
                correctModuli = 0
        
        if( verbose == 1 ):
            if( correctModuli == 1 ):
                print( "Base path "+str(i)+" has the correct moduli for its vertices.")
            else:
                print( "Base path "+str(i)+" DOES NOT have the correct moduli for its vertices.")
                
        # Next, check the differences of the edges used 
        # in S[i] to be sure they are distinct
        
        differences = []
        distinctDifferences = 1
        for j in range( d ):
            usedDifferences[( S[i][j] - S[i][j+1] ) % mn] += 1
            usedDifferences[( S[i][j+1] - S[i][j] ) % mn] += 1
            for k in range( j - 1 ):
                if( ( S[i][k] - S[i][k+1] - S[i][j] + S[i][j+1] ) % mn == 0 or ( S[i][k] - S[i][k+1] + S[i][j] - S[i][j+1] ) % mn == 0 ):
                    distinctDifferences = 0
        
        if( verbose == 1 ):
            if( distinctDifferences == 1 ):
                print( "Base path "+str(i)+" has distinct edge lengths.")
            else:
                print( "Base path "+str(i)+" DOES NOT have distinct edge lengths.")
            
        # Last, check that the order of the final vertex
        # in S[i] has order mn/d; this is confirmed by 
        # checking that its gcd with mn is d.
        
        if( gcd( mn, S[i][d] ) == d ):
            if( verbose == 1 ): 
                print( "Base path "+str(i)+" has correct final vertex order.")
            correctOrder = 1
        else:
            if( verbose == 1 ):
                print( "Base path "+str(i)+" DOES NOT have correct final vertex order.")
            correctOrder = 0
            
        if( not( correctModuli == 1 and distinctDifferences == 1 and correctOrder == 1 ) ):
            print( "Base path " + str(i) + " is NOT base path." )
            areAllBasePaths = 0
    
    # Next, check to see that all base paths have distinct edge lengths
    
    distinctDifferences = 1
    for i in range( mn ):
        if( usedDifferences[i] > 1 ):
            print( "Repeated Difference " + str(i) + " or " + str( ordered_pair( i, m, n ) ) + " where m = " + str(m) + " and n = " + str(n) + ": occured " + str(usedDifferences[i]) + " times." )
            distinctDifferences = 0
  
    # Last, confirm that all non-unit edge lengths are used
    
    allNonunitsUsed = 1
    for i in range( mn ):
        if( not( gcd( i, mn ) == 1 or i % m == 0  ) ):
            # print( "GCD("+str(i)+","+str(mn)+") = "+str(gcd( i, mn )) + " and "+str(i)+" % " + str(m) + " = " + str(i%m) )
            if( usedDifferences[i] == 0 ):
                allNonunitsUsed = 0

    if( areAllBasePaths == 1 and distinctDifferences == 1 and allNonunitsUsed == 1 ):
        print( "This set of base paths is valid for K_{" + str(m) + " x " + str(n) + "}." )
    else:
        print( "This set of base paths is NOT valid for K_{" + str(m) + " x " + str(n) + "}." )
        print( "areAllBasePaths = " + str(areAllBasePaths) )
        print( "distinctDifferences = " + str(distinctDifferences) )
        print( "allNonunitsUsed = " + str(allNonunitsUsed) )
        









# Function: alpha
#
# Inputs: integers d, p
#
# Output: This is a helper function used in 
#         the function build_initial_base_paths.
#         It defines a balanced function from 
#         a set of consecutive integers into the 
#         set of units of Z_p. 
#         
#         In practice, this requires the set of 
#         small non-units to be indexed, then 
#         the inputs to this function are the
#         indices of those non-units.

def alpha( d, p ):
    return 1 + ( d % (p-1) )
    






# Function: build_initial_base_paths
#
# Inputs: integers p, n
#         p is a prime integer
#         n is a positive integer such that
#         p phi(n) >= n + 2p - 3.
#
# Output: This routine builds a valid set of 
#         base paths for the graph K_{p x n} 
#         which uses all non-unit edge lengths,
#         which when coupled with an appropriate
#         set of base paths of length 1 gives
#         rise to a cyclic, n-symmetric
#         Hamilton cycle decomposition of K_{pxn}.

def build_initial_base_paths( p, n ):
    
    base_paths = []
    
    k = p // 4
    ell = p // 2
    
    small_non_units = []
    small_units = []
    
    for i in range( 2, (n+1) // 2 ):
        if( gcd( i, n ) > 1 ):
            small_non_units.append(i)
        else:
            small_units.append(i)
            
    m = len( small_non_units )
    
    for i in range( m ):
        base_paths.append( [(0,0)] )
        for j in range( 1, ell + 1 ):
            base_paths[i].append( (  j * alpha(i,p) % p, small_non_units[i] ) )
            base_paths[i].append( ( -j * alpha(i,p) % p, 0 ) )
        base_paths[i].append( (0, small_units[i // (p-1)] ) )
        
    base_paths.append( [(0,0)] )
    
    if( p % 4 == 1 ):
        for i in range( 1, k + 1 ):
            base_paths[m].append( (i,0) )
            base_paths[m].append( (p-i,0) )
        for i in range( k + 1, 2*k + 1 ):
            base_paths[m].append( (i,1) )
            base_paths[m].append( (p-i,0) )
        base_paths[m].append( (0,1) )
        
    if( p % 4 == 3 ):
        for i in range( 1, k + 1 ):
            base_paths[m].append( (i,0) )
            base_paths[m].append( (p-i,0) )
        base_paths[m].append( (k+1,0) )
        base_paths[m].append( (p-k-1,n-1) )
        for i in range( k + 2, 2*k + 2 ):
            base_paths[m].append( (i,0) )
            base_paths[m].append( (p-i,1) )
        base_paths[m].append( (0,2) )
    
    return combined_base_paths( base_paths, p, n )







# Function: combine_path_and_part_divisible
#
# Inputs: base path S in K_{m}
#         integer m
#         part in a partition of Z_n
#         integer n
#
# Output: This routine constructs a set of 
#         base paths which belong to K_{m x n}

def combine_path_and_part_divisible( S, m, P, n ): 
    new_paths = []
    
    d = len( S ) - 1
    
    if( verbose == 1 ): print( "d = " + str(d) )
    
    p = len( P )
    
    if( verbose == 1 ): print( "p = " + str(p) )
    
    Z = [[0 for x in range(p)] for y in range(p)]
    
    for k in range( p ):
        Z[0][k] = P[k]
        for i in range( 1,p ):
            Z[i][k] = Z[i-1][k] + P[( i + k ) % p]
            
    if( verbose == 1 ): 
        for i in range( p ):
            print( Z[i] )

    for k in range( p ):
        new_path = [(0,0)]
        for i in range( 1, d + 1 ):
            new_path.append( ( S[i], Z[i-1][k] ) )
            
        new_paths.append( new_path )
    
    return new_paths







# Function: combine_path_and_part_relatively_prime
#
# Inputs: base path S in K_{m}
#         integer m
#         part in a partition of Z_n
#         integer n
#
# Output: This routine constructs a  
#         base path which belongs to K_{m x n}

def combine_path_and_part_relatively_prime( S, m, P, n ): 
    new_path = [(0,0)]
    
    d = len( S ) - 1
    
    p = len( P )
    
    Z = [0] * p
    
    Z[0] = P[0]
    
    if( verbose == 1 ): print( "d = " + str(d) + " : p = " + str(p) )
    
    for i in range( 1, p ):
        Z[i] = Z[i-1] + P[i]

    q  = [0] * (p*d + 1 )
    r  = [0] * (p*d + 1 )
    qp = [0] * (p*d + 1 )
    rp = [0] * (p*d + 1 )

    for k in range( p*d + 1 ):
        q[k] = (k-1) // d
        r[k] = ( ( k - 1) % d ) + 1 
        qp[k] = (k-1) // p
        rp[k] = ( ( k - 1) % p ) + 1 
        
    for k in range( 1, p*d + 1 ):
        if( verbose == 1 ): print(k)
        if( verbose == 1 ): print( k, q[k], r[k], qp[k], rp[k], S, Z )
        new_path.append( ( ( S[r[k]] + q[k] * S[d] ) % m, ( Z[rp[k-1]%p] + qp[k] * Z[p-1] ) % n ) )
        if( verbose == 1 ): print( k, q[k], r[k], qp[k], rp[k] )
    
    return new_path
    






# Function: combine_path_and_unit
#
# Inputs: base path S in K_{m}
#         integer m
#         a unit of Z_n
#         integer n
#
# Output: This routine constructs a  
#         base path which belongs to K_{m x n}

def combine_path_and_unit( S, m, u, n ): 
    new_path = []
    
    for i in range( len(S) ):
        new_path.append( ( S[i], ( i * u ) % n ) )
    
    return new_path
 






# Function: combine_paths_and_partition
#
# Inputs: base paths S in K_{m}
#         integer m
#         a partition P of Z_n
#         integer n
#
# Output: This routine builds a valid set of base paths 
#         for a decomposition of K_{m x n} from a set of 
#         base paths of K_m and a partition of Z_n.

def combine_paths_and_partition( S, m, P, n ):
    new_paths = []
    
    for i in range( len( S ) ):
        for j in range( len( P ) ):
            if( len( P[j] ) > 1 ):
                if( verbose == 1 ): print( str(len(S[i])) + " : " + str(len( P[j])) )
                if( len( S[i] ) % len( P[j] ) == 1 ):
                    if( verbose == 1 ): print( "Inside: " + str(len(S[i])) + " : " + str(len( P[j])) )
                    temp = combine_path_and_part_divisible( S[i], m, P[j], n )
                    for k in range( len( temp ) ):
                        new_paths.append( temp[k] )
                else:
                    new_paths.append( combine_path_and_part_relatively_prime( S[i], m, P[j], n ) )
            else:
                new_paths.append( combine_path_and_unit( S[i], m, P[j][0], n ) )
                
    return combined_base_paths( new_paths, m, n )






# Function: add_unit_base_paths
#
# Inputs: base paths S in K_{mxn}
#         (assumes all non-unit edge lengths used)
#         integers m, n
#
# Output: This routine determines the unit edge lengths
#         which are not used by the paths in S, then
#         adds base paths of length 1 to S so as to 
#         produce a set of valid base paths for K_{m x n}
#         which uses every edge length.

def add_unit_base_paths( S, m, n ):

    new_unit_paths = S
    
    used_differences = [0] * (m*n)
    
    for i in range( len( S ) ):
        for j in range( 1, len( S[i] ) ):
            used_differences[ ( S[i][j] - S[i][j-1] ) % (m*n) ] += 1
            used_differences[ ( S[i][j-1] - S[i][j] ) % (m*n) ] += 1

    for i in range( (m*n+1) // 2 ):
        if( gcd( i, m*n ) == 1 and used_differences[i] == 0 ):
            new_unit_paths.append( [ 0, i ] )
            
    return new_unit_paths
    












# Function: combine_paths_with_prime_divisors
#
# Inputs: base paths S in K_{m x n}
#         (assumes all appropriate edge lengths used)
#         integer m
#         prime divisor p of m
#         integer exponent a
#         assume that p does not divide n
#
# Output: This routine builds the base paths for 
#         K_{m x np^a}

def combine_paths_with_prime_divisors( S, m, n, p, t ):

    new_paths = []

    a = largest_prime_power( m, p )
    
    oS = ordered_pair_paths( S, p**a, (m*n) // (p**a) )

    for i in range( len( oS ) ):

        # We only need to worry about non-unit edge lengths, so 
        # We just need to focus on base baths with length at least 2
        d = len( oS[i] ) - 1
        if( len( oS[i] ) > 2 ):
            if( d % (p**a) == 0 ):
                for j in range( p**t ):
                    new_path = []
                    for k in range( len( oS[i] ) ):
                        new_path.append( oS[i][k] )
                        
                    for k in range( 1, d ):
                        tempx = new_path[k][0] + j * k * p**a
                        new_path[k] = ( tempx, new_path[k][1] )
                    new_path[d] = ( p**a, new_path[d][1] )

                    new_paths.append( new_path )

            elif( d % p == 0 ):
                for j in range( p**t ):
                    new_path = []
                    for k in range( len( oS[i] ) ):
                        new_path.append( oS[i][k] )
                        
                    for k in range( 1, d+1 ):
                        tempx = new_path[k][0] + j * k * p**a
                        new_path[k] = ( tempx, new_path[k][1] )

                    new_paths.append( new_path )

            else:
                for j in range( p**(t-1) ):
                    edge_lengths = []
                    
                    for ell in range( p ):
                        for k in range( d ):
                            edge_lengths.append( ordered_pair( S[i][k+1] - S[i][k], p**a, (m*n) // (p**a) ) )

                    for ell in range( p ):
                        for k in range( d ):
                            edge_lengths[d*ell+k] = ( edge_lengths[d*ell+k][0] + ell * p**(a+t-1) + j * p, edge_lengths[d*ell+k][1] )

                    new_path = [(0,0)]
                    
                    for k in range( p*d ):
                        new_path.append( ( new_path[-1][0] + edge_lengths[k][0], new_path[-1][1] + edge_lengths[k][1] ) )
                        
                    # for k in range( 1, p*d + 1 ):
                        # new_path.append( oS[i][((k-1)%d)+1] )
                    
                    # for k in range( 1, p*d + 1 ):
                        # tempx = new_path[k][0] + new_path[((k-1)//d)*d][0] % (p**a)
                        # tempy = new_path[k][1] + new_path[((k-1)//d)*d][1] % ((m*n) // (p**a))
                        # new_path[k] = ( tempx, tempy )

                    # for k in range( 1, p*d ):
                        # tempx = new_path[k][0] + j * k * p**a + ( ( (k-1) % d ) + 1 ) * ( (k-1) // d ) * p**(a+t-1)
                        # new_path[k] = ( tempx, new_path[k][1] )
                        
                    # new_path[p*d] = ( p*d, new_path[p*d][1] )

                    new_paths.append( new_path )
                        # new_path.append( ( (oS[i][((k-1)%d) + 1][0] + new_path[((k-1)//d)*d][0])% (p**a), (oS[i][((k-1)%d) + 1][1] + new_path[k//d][1])% ((m*n) // (p**a)) ) ) 

    return combined_base_paths( new_paths, p**(a+t), (m*n) // (p**a) )

                # Now, add something to each vertex to make the edge lengths be distinct
                # If the path is of length d, then adding a multiples of p^a should suffice
                # If the path is of length pd, then adding multiples of p^a, then multiples of p^{a+t-1}


                # new_path = [(0,0)] * ell
                # for k in range( ell // d ):
                    # new_path[k*d] = ( (oS[i][d]*k) % (p**a), 
                
                # if( len( oS[i] ) % p == 1 ):
                    # for k in range( len( oS[i] ) - 1 ):
                        # new_path.append( ( (oS[i][k][0] + k * j * p**a ) % (p**(a+t)), oS[i][k][1] ) )
                    # new_path.append( (p, oS[i][len(oS[i])-1][1] ) )
                # else:
                    # for k in range( len( oS[i] ) - 1 ):
                        # new_path.append( ( (oS[i][k][0] + k * j * p**a ) % (p**(a+t)), oS[i][k][1] ) )
                    # new_path.append( (p, oS[i][len(oS[i])-1][1] ) )
                # new_paths.append( new_path )
    
    # return combined_base_paths( new_paths, p**(a+t), (m*n) // (p**a) )

def first_base_path_of_km( q, r ):

    if( q == 3 ):
        new_path = [ (0,0), (1,0), (2,1) ]
        P = prime_factorization( r )
        P.sort()
        p = smallest_factor( P[-1] )
        # if( p == 1 ):
            # p = P[-1]
        if( len( P ) == 1 ):
            if( verbose == 1 ):
                print( "p = " + str(p) )
            if( P[-1] % 4 == 3 ):
            # if( p % 4 == 3 ):
                new_path.append( (0, r - 1 ) )
            else:
                new_path.append( (0, 3 ) )
        else:
            last_vertex = [2] * ( len( P ) - 1 )

            if( p % 4 == 3 ):
                last_vertex.append( P[-1] - 1 )
            else:
                last_vertex.append( 3 )

            new_path.append( (0, combined_tuple( tuple( last_vertex ), P ) ) )
        return new_path

    p = smallest_factor( q )
    a = largest_prime_power( q, p )
    
    new_path = []

    for h in range( (q+1) // 2 ):
        if( h % 2 == 0 ):
            new_path.append( ( h // 2, 0 ) )
        else: 
            new_path.append( ( q - (h+1) // 2, 0 ) )
    
    if( p % 4 == 1 ):
        for h in range( (q+1) // 2, q ):
            if( h % 2 == 0 ):
                new_path.append( ( h // 2, 0 ) )
            elif( (h + p) % (2*p) == 0 ):
                new_path.append( ( q - ( h + p ) // 2, 1 ) )
            else:
                if( ( h // p ) % 2 == 0 ):
                    new_path.append( ( q - ( h + 1 ) // 2, r - 1 ) )
                else: 
                    new_path.append( ( q - ( h - 1 ) // 2, r - 1 ) )
        new_path.append( ( 0, r - 1 ) )

    elif( p % 4 == 3 and a % 2 == 1 ):
        for h in range( (q+1) // 2, q - 2 ):
            if( h % 2 == 0 ):
                new_path.append( ( h // 2, 1 ) )
            elif( (h + p) % (2*p) == 0 ):
                new_path.append( ( q - ( h + p ) // 2, 2 ) )
            else: 
                if( ( h // p ) % 2 == 0 ):
                    new_path.append( ( q - ( h + 1 ) // 2, 0 ) )
                else: 
                    new_path.append( ( q - ( h - 1 ) // 2, 0 ) )
        new_path.append( ( ( 1 + q ) // 2, 2 ) )
        new_path.append( ( ( q - 1 ) // 2, 3 ) )
        new_path.append( ( 0, 2 ) )
    
    else:
        for h in range( (q+1) // 2, q - 2 ):
            if( h % 2 == 1 ):
                new_path.append( ( q - ( h + 1 ) // 2, 1 ) )
            elif( (h + p + 1) % (2*p) == 0 ):
                new_path.append( ( ( h + 1 - p ) // 2, 2 ) )
            else:
                if( ( h // p ) % 2 == 0 ):
                    new_path.append( ( 1 + h // 2, 0 ) )
                else:
                    new_path.append( ( h // 2, 0 ) )
        new_path.append( ( ( q - p ) // 2, 1 ) )
        new_path.append( ( ( q + 1 ) // 2, 0 ) )
        new_path.append( ( 0, r-1 ) )
        
    return new_path

def base_paths_of_km( m ):
    
    P = prime_factorization( m )
    P.sort()
    
    n = len( P )

    base_paths = []
    
    if( n == 1 ):
        # for i in range( 1, ( m - 1 ) // 2 ):
            # base_paths.append( [ 0, i ] )
        return base_paths
    
    for i in range( n ):
        base_paths.append( combined_base_path( first_base_path_of_km( P[i], m // P[i] ), P[i], m // P[i] ) )
        
    if( verbose == 1 ): 
        print( base_paths )
        print( ordered_tuple_paths( base_paths , P ) )
    
    if( n == 2 ):
        if( verbose == 1 ): print( "Only two prime powers in the factorization." )
        used_differences = [0] * (m)
        for j in range( 2 ):
            for i in range( len( base_paths[j] ) - 1 ):
                used_differences[ ( base_paths[j][i] - base_paths[j][i+1] ) % m ] += 1
                used_differences[ ( base_paths[j][i+1] - base_paths[j][i] ) % m ] += 1

        double_edge = 0
        if( verbose == 1 ): print( used_differences )
        for i in range( m - 1 ):
            if( used_differences[i] > 1 ):
                double_edge = 1

        if( double_edge == 1 ):
            if( verbose == 1 ): print( "Needed to negate." )
            coord_path = ordered_pair_path( base_paths[1], P[1], P[0] )
            negated_path = []
            for i in range( len( coord_path ) ):
                # negated_path.append( ( P[1] - coord_path[i][0], coord_path[i][1] ) )
                negated_path.append( ( coord_path[i][0], P[0] - coord_path[i][1] ) )
            base_paths[1] = combined_base_path( negated_path, P[1], m // P[1] )



        for z in range( 1, ( P[1] + 1 ) // 2 ):
            if( gcd( z, P[1] ) > 1 ):
                base_path = [(0,0)]
                p = smallest_factor( P[0] )
                # if( p == 1 ): 
                    # p = P[0]
                for h in range( 1, P[0] ):
                    if( h % 2 == 0 ):
                        base_path.append( ( P[0] - h // 2, 0 ) )
                    elif( ( h + p ) % (2*p) == 0 ):
                        base_path.append( ( ( h + p ) // 2, z + 1 ) )
                    else: 
                        if( ( h // p ) % 2 == 0 ):
                            base_path.append( ( ( h + 1 ) // 2, z ) )
                        else:
                            base_path.append( ( ( h - 1 ) // 2, z ) )
                base_path.append( ( 0, z - 1 ) )
                combined_path = combined_tuple_path( base_path, P )
                base_paths.append( combined_path )

    else:
        for u in range( m // (P[-2] * P[-1]) ):
            for z in range( 1, ( P[-1] + 1 ) // 2 ):
                if( gcd( u, m // (P[-2] * P[-1]) ) == 1 ):
                    if( gcd( z, P[-1] ) > 1 ):
                        # print( "u = " + str(u) + "; z = " + str(z) ) 
                        base_path = [(0,0,0)]
                        p = smallest_factor( P[-2] )
                        # if( p == 1 ): 
                            # p = P[-2]
                        for h in range( 1, P[-2] ):
                            # print( base_path )
                            # print( h, p, ( h + p ) % (2*p) )
                            if( h % 2 == 0 ):
                                # print( "1111" )
                                base_path.append( ( 0, P[-2] - h // 2, 0 ) )
                            elif( ( h + p ) % (2*p) == 0 ):
                                # print( "2222 " + str(z) )
                                base_path.append( ( u, ( h + p ) // 2, z + 1 ) )
                            else: 
                                if( ( h // p ) % 2 == 0 ):
                                    # print( "3333" )
                                    base_path.append( ( u, ( h + 1 ) // 2, z ) )
                                else:
                                    # print( "4444" )
                                    base_path.append( ( u, ( h - 1 ) // 2, z ) )
                        base_path.append( ( u, 0, z - 1 ) )
                        # print( "Combined path: " + str( base_path ) )
                        combined_path = combined_tuple_path( base_path, [m // (P[-2] * P[-1]), P[-2], P[-1] ] )
                        # print( "Combined path: " + str( combined_path ) )
                        base_paths.append( combined_path )

    used_differences = [0] * m
    
    for i in range( len( base_paths ) ):
        for j in range( 1, len( base_paths[i] ) ):
            used_differences[ ( base_paths[i][j] - base_paths[i][j-1] ) % m ] += 1
            used_differences[ ( base_paths[i][j-1] - base_paths[i][j] ) % m ] += 1
    
    # print( used_differences )
    
    unused_units = []
    for i in range( ( m + 1 ) // 2 ):
        if( gcd( i, m ) == 1 and used_differences[i] == 0 ):
            unused_units.append( i )
    
    # print( unused_units )
    
    U = [ [] for i in range( n + 1 ) ]
    X = [ [] for i in range( n + 1 ) ]
    
    Q = [1]
    for i in range( n ):
        Q.append( P[i] * Q[i] )
    # print( "P = " + str(P) )
    # print( "Q = " + str(Q) )
        
    for i in range( 2, n ):
       for j in range( 1, (Q[i-1] + 1) // 2 ):
            X[i].append( j )
            U[i].append( unused_units.pop() )
    # print( "U = " + str(U) )
    # print( "X = " + str(X) )

    if( verbose == 1 ):
        print( "Q[n-1] = " + str(Q[n-1]) )

    for i in range( 1, (Q[n-1]+1) // 2 ):
        if( gcd( i, Q[n-1] ) > 1 ):
            X[n].append( i )
            U[n].append( unused_units.pop() )
        
    if( verbose == 1 ):
        print( "U = " + str(U) )
        print( "X = " + str(X) )
        for i in range( len( U ) ):
            print( U[i] )
            
        for i in range( len( U ) ):
            print( X[i] )
            
        print( "Unused units: "+  str(unused_units ) )
    
    for i in range( 2, n ):
        for j in range( len( U[i] ) ):
            # print( i, j )
            r = U[i][j] % Q[i-1]
            s = U[i][j] % P[i-1]
            t = U[i][j] % ( m // Q[i] )
            
            base_path = [(0,0,0)]
            
            for k in range( 1, ( P[i-1] + 1) // 2 ):
                base_path.append( ( X[i][j], (2 * k * s) % P[i-1], 0 ) )
                base_path.append( ( 0, (-2 * k * s) % P[i-1], 0 ) )
            base_path.append( ( Q[i-1] - r, 0, ( m // Q[i] ) - t ) )
            # print( "Base path: " + str(base_path) )
            base_paths.append( combined_tuple_path( base_path, [ Q[i-1], P[i-1], ( m // Q[i] ) ] ) )
        
    for j in range( len( U[n] ) ):
        r = U[n][j] % Q[n-1]
        s = U[n][j] % P[n-1]
    
        base_path = [(0,0)]
    
        for k in range( 1, ( P[n-1] + 1) // 2 ):
            base_path.append( ( X[n][j], (2 * k * s) % P[n-1] ) )
            base_path.append( ( 0, (-2 * k * s) % P[n-1] ) )
        base_path.append( ( Q[n-1] - r, 0 ) )
        # print( "base path: " + str(base_path) )
        base_paths.append( combined_tuple_path( base_path, [ Q[n-1], P[n-1] ] ) )
    
    return base_paths
    
def build_k_fifteen_base_paths( n ):
    P = prime_factorization( n )
    Q.sort()
    Q = []
    base_paths = []
    current_number_of_vertices = 15
    
    is_multiple_of_three = 0
    is_multiple_of_five = 0
    is_even = 0
    
    for i in range( len( P ) ):
        if( P[i] % 3 == 0 ):
            is_multiple_of_three = largest_prime_power( P[i], 3 )
        elif( P[i] % 5 == 0 ):
            is_multiple_of_five = largest_prime_power( P[i], 5 )
        elif( P[i] % 2 == 0 ):
            is_even = largest_prime_power( P[i], 2 )
        else:
            Q.append( P[i] )
    
    base_made = 0
    
    if( is_even > 0 ):
        ## build K_{15 x 2^t} base paths
        current_number_of_vertices = 15 * ( 2 ** is_even )
        base_made = 1
        
    for i in range( len( Q ) ):
        if( base_made == 0 ):
            ## build K_{15 x p^t}
            current_number_of_vertices = 15 * Q[i]
            base_made = 1
        else:
            p = smallest_factor( Q[i] )
            large_partition = set_partition( 3, p, largest_prime_power( Q[i], p ) )
            base_paths = combine_paths_and_partition( base_paths, current_number_of_vertices, large_partition, Q[i] )
            current_number_of_vertices *= Q[i]
    
    if( is_multiple_of_three > 0 ):
        if( base_made == 0 ):
            ## build K_{15 x 3^t}
            base_made = 1
        else:
            base_paths = combine_paths_with_prime_divisors( S, 15, current_number_of_vertices // 15, 3, is_multiple_of_three )
    
    if( is_multiple_of_five > 0 ):
        if( base_made == 0 ):
            ## build K_{15 x 5^t}
            base_made = 1
        else:
            base_paths = combine_paths_with_prime_divisors( S, 15, current_number_of_vertices // 15, 5, is_multiple_of_five )

    return base_paths
    
def build_base_paths( m, n ):
    





verbose = 0
for m in range( 21, 2000, 2 ):
# for m in [39,51,75,87,111,123]:
# for m in [45, 63, 75, 135, 147, 175, 189, 225, 245]:
# for m in [45, 63, 75]:
# for m in [735, 1617, 1815, 1911]:
# for m in [3*7*7, 3*11*11, 3*19*19, 3*23*23]:
# for m in [5*5*7*7]:
    if( len( prime_factorization( m ) ) > 1 ):
        B = base_paths_of_km( m )

        # for i in range( len( B ) ):
            # print( B[i] )
        
        # print()
        # print()
        P = prime_factorization( m )
        P.sort()
        # for i in range( len( B ) ):
            # print( ordered_tuple_path( B[i], P ) )

        # print()
        # print()
        check_base_paths( B, m, 1 )

        # print()
        # print()
        # print()
        # print()

